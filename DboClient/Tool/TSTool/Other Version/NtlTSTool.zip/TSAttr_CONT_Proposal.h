#pragma once


#include "TSAttr_Page.h"


// CTSAttr_CONT_Proposal ��ȭ �����Դϴ�.

class CTSAttr_CONT_Proposal : public CTSAttr_Page
{
	DECLARE_SERIAL(CTSAttr_CONT_Proposal)

public:
	CTSAttr_CONT_Proposal();
	virtual ~CTSAttr_CONT_Proposal();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_TS_CONT_PROPOSAL_ATTR_DIAG };

protected:
	virtual CString	CollectAttrDataFromDlgItems( void );
	virtual void	SettingAttrDataToDlgItems( CString& strKey, CString& strValue );

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.
	virtual BOOL OnInitDialog();

	DECLARE_MESSAGE_MAP()

public:
	DWORD m_tcID;
	DWORD m_uiTitle;
	DWORD m_uiArea;
	DWORD m_uiGoal;
	DWORD m_uiGrade;
	CComboBox m_ctrGradeType;
	DWORD m_uiSort;
	DWORD m_uiContents;
	DWORD m_tcRewardID;
};
