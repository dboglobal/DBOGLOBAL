#pragma once


class CTSGroup;


class CTSShape : public CObject
{

	DECLARE_SERIAL( CTSShape )


// Member variables
protected:

	CTSGroup*							m_pParent;

	CPoint								m_ptOrigin;

	bool								m_bDragging;
	CPoint								m_ptDragPoint;
	CPoint								m_ptLastPoint;

	HHANDLER							m_hDragHandler;

	bool								m_bZombie;


// Constructions and Destructions
protected:

	CTSShape( void );


public:

	CTSShape( CTSGroup* pParent );

	virtual ~CTSShape( void )			{ return; }


// Methods
public:

	// Parent

	CTSGroup*							GetParent( void ) const { return m_pParent; }

	// Position

	const CPoint&						GetOrigin( void ) const { return m_ptOrigin; }
	void								SetOrigin( const CPoint& ptOrigin ) { m_ptOrigin = ptOrigin; }

	// Region

	virtual CRect						GetBoundBox( void ) const { return CRect(); }
	virtual CSize						GetMinSize( void ) const { return CSize( 50, 50 ); }
	virtual CSize						GetMaxSize( void ) const { return CSize( 5000, 5000 ); }
	virtual CSize						GetIdealSize( void ) const { return CSize( 150, 50 ); }


	// Zombie

	virtual bool						IsZombie( void ) const { return m_bZombie; }
	virtual void						MakeZombie( bool bTrue = true ) { m_bZombie = bTrue; }


	// Handler

	virtual int							GetHandlerCount( void ) const { return 0; }
	virtual HHANDLER					GetHandlerAt( const CPoint &ptPos ) const;
	virtual CPoint						GetHandlerPos( HHANDLER hHandler ) const;
	virtual HCURSOR						GetHandlerCursor( HHANDLER hHandler ) const;


	// Linker

	virtual int							GetLinkerCount( void ) const { return 0; }
	virtual HLINKER						GetLinkerAt( const CPoint &ptPos ) const;
	virtual HLINKER						GetLinkerHandleFromLinkerType( eLINKER_TYPE eLinkerType ) const;
	virtual CPoint						GetLinkerPos( HLINKER hHandler ) const;
	virtual CPoint						GetLinkerPosFromLinkerType( eLINKER_TYPE eLinkerType ) const;
	virtual CPoint						GetLinkerPosFromLinkerInfo( void* pLinkerInfo ) const;
	virtual eLINKER_TYPE				GetLinkerType( HLINKER hHandler ) const;
	virtual void*						GetLinkerInfo( HLINKER hHandler ) const;
	virtual HCURSOR						GetLinkerCursor( HLINKER hHandler ) const;


	// Intersection

	virtual bool						Intersects( const CPoint &ptPos ) const;
	virtual bool						Intersects( const CRect &rect ) const { return false; }


	// Activate

	virtual void						Activate( const CPoint &ptPos, bool bLBtn ) { return; }


	// Update

	virtual void						Update( void ) { return; }


	// Drag

	virtual void						BeginDrag( const CPoint &ptPos, HHANDLER hHandler = eHHANDLER_INVALID );
	virtual void						Drag( const CPoint &ptPos );
	virtual void						EndDrag( void );


	// Render

	virtual void						RenderShape( CDC* pDC ) const { return; }
	virtual void						RenderHandler( CDC* pDC ) const;
	virtual void						RenderLinker( CDC* pDC ) const;


	// Mouse event

	virtual void						OnMouseEnter( const CPoint &ptPos, UINT nFlags ) { return; }
	virtual void						OnMouseLeave( const CPoint &ptPos, UINT nFlags ) { return; }
	virtual HCURSOR						OnMouseMove( const CPoint &ptPos, UINT nFlags );


	// Serialize

	virtual void						Serialize( CArchive &ar );


// Implementations
protected:

	void								ClearAll( void );

	void								Save( CArchive& ar );

	bool								Load_Trig_Ver_00000000( CArchive& ar );
	bool								Load_Trig_Ver_00000001( CArchive& ar );

};


typedef CTypedPtrList< CObList, CTSShape* > TSShapeList;
