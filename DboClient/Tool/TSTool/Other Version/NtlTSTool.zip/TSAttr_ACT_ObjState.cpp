// TSAttr_ACT_ObjState.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "NtlTSTool.h"
#include "TSAttr_ACT_ObjState.h"


// CTSAttr_ACT_ObjState ��ȭ �����Դϴ�.

IMPLEMENT_SERIAL(CTSAttr_ACT_ObjState, CTSAttr_Page, 1)

CTSAttr_ACT_ObjState::CTSAttr_ACT_ObjState()
	: CTSAttr_Page(CTSAttr_ACT_ObjState::IDD)
	, m_taID(NTL_TS_TA_ID_INVALID)
	, m_dwWorldIdx(0xffffffff)
	, m_dwObjectIdx(0xffffffff)
{

}

CTSAttr_ACT_ObjState::~CTSAttr_ACT_ObjState()
{
}

CString CTSAttr_ACT_ObjState::CollectAttrDataFromDlgItems( void )
{
	CTSAttr_Page::CollectAttrDataFromDlgItems();

	CString strData;

	strData += MakeAttrData( _T("taid"), m_taID );
	strData += MakeAttrData( _T("widx"), m_dwWorldIdx );
	strData += MakeAttrData( _T("oidx"), m_dwObjectIdx );
	strData += MakeAttrData( _T("mstate"), (int)m_ctrMainState.GetItemData( m_ctrMainState.GetCurSel() ) );
	strData += MakeAttrData( _T("osh"), (int)m_ctrObjShowHide.GetItemData( m_ctrObjShowHide.GetCurSel() ) );

	return strData;
}

void CTSAttr_ACT_ObjState::SettingAttrDataToDlgItems( CString& strKey, CString& strValue )
{
	if ( _T("taid") == strKey )
	{
		m_taID = atoi( strValue.GetBuffer() );
	}
	else if ( _T("widx") == strKey )
	{
		m_dwWorldIdx = atoi( strValue.GetBuffer() );
	}
	else if ( _T("oidx") == strKey )
	{
		m_dwObjectIdx = atoi( strValue.GetBuffer() );
	}
	else if ( _T("mstate") == strKey )
	{
		int nValue = atoi( strValue.GetBuffer() );

		int nCnt = m_ctrMainState.GetCount();
		for ( int i = 0; i < nCnt; ++i )
		{
			if ( m_ctrMainState.GetItemData( i ) == nValue )
			{
				m_ctrMainState.SetCurSel( i );
				break;
			}
		}
	}
	else if ( _T("osh") == strKey )
	{
		int nValue = atoi( strValue.GetBuffer() );

		int nCnt = m_ctrObjShowHide.GetCount();
		for ( int i = 0; i < nCnt; ++i )
		{
			if ( m_ctrObjShowHide.GetItemData( i ) == nValue )
			{
				m_ctrObjShowHide.SetCurSel( i );
				break;
			}
		}
	}
}

void CTSAttr_ACT_ObjState::DoDataExchange(CDataExchange* pDX)
{
	CTSAttr_Page::DoDataExchange(pDX);

	DDX_Text(pDX, IDC_TS_ACT_ATTR_OBJSTATE_ID_EDITOR, m_taID);
	DDV_MinMaxUInt(pDX, m_taID, 0, NTL_TS_TA_ID_INVALID);
	DDX_Text(pDX, IDC_TS_ACT_ATTR_OBJSTATE_WORLD_ID_EDITOR, m_dwWorldIdx);
	DDX_Text(pDX, IDC_TS_ACT_ATTR_OBJSTATE_OBJECT_ID_EDITOR, m_dwObjectIdx);
	DDX_Control(pDX, IDC_TS_ACT_ATTR_OBJSTATE_MAIN_STATE_COMBO, m_ctrMainState);
	DDX_Control(pDX, IDC_TS_ACT_ATTR_OBJSTATE_OBJECT_SHOW_HIDE_COMBO, m_ctrObjShowHide);
}

BOOL CTSAttr_ACT_ObjState::OnInitDialog()
{
	CTSAttr_Page::OnInitDialog();

	// TODO:  ���⿡ �߰� �ʱ�ȭ �۾��� �߰��մϴ�.

	int nIdx = m_ctrMainState.AddString( _T("Ignore") );
	m_ctrMainState.SetItemData( nIdx, CDboTSActObjState::eMAIN_STATE_IGNORE );
	m_ctrMainState.SetItemData( m_ctrMainState.AddString( _T("0") ), CDboTSActObjState::eMAIN_STATE_0 );
	m_ctrMainState.SetItemData( m_ctrMainState.AddString( _T("1") ), CDboTSActObjState::eMAIN_STATE_1 );
	m_ctrMainState.SetItemData( m_ctrMainState.AddString( _T("2") ), CDboTSActObjState::eMAIN_STATE_2 );
	m_ctrMainState.SetItemData( m_ctrMainState.AddString( _T("3") ), CDboTSActObjState::eMAIN_STATE_3 );
	m_ctrMainState.SetItemData( m_ctrMainState.AddString( _T("4") ), CDboTSActObjState::eMAIN_STATE_4 );
	m_ctrMainState.SetItemData( m_ctrMainState.AddString( _T("5") ), CDboTSActObjState::eMAIN_STATE_5 );
	m_ctrMainState.SetItemData( m_ctrMainState.AddString( _T("6") ), CDboTSActObjState::eMAIN_STATE_6 );
	m_ctrMainState.SetItemData( m_ctrMainState.AddString( _T("7") ), CDboTSActObjState::eMAIN_STATE_7 );
	m_ctrMainState.SetItemData( m_ctrMainState.AddString( _T("8") ), CDboTSActObjState::eMAIN_STATE_8 );
	m_ctrMainState.SetItemData( m_ctrMainState.AddString( _T("9") ), CDboTSActObjState::eMAIN_STATE_9 );
	m_ctrMainState.SetCurSel( nIdx );

	nIdx = m_ctrObjShowHide.AddString( _T("Ignore") );
	m_ctrObjShowHide.SetItemData( nIdx, CDboTSActObjState::SUB_STATE_OBJECT_IGNORE );
	m_ctrObjShowHide.SetItemData( m_ctrObjShowHide.AddString( _T("Hide") ), CDboTSActObjState::SUB_STATE_OBJECT_HIDE );
	m_ctrObjShowHide.SetItemData( m_ctrObjShowHide.AddString( _T("Show") ), CDboTSActObjState::SUB_STATE_OBJECT_SHOW );
	m_ctrObjShowHide.SetCurSel( nIdx );

	if ( m_strAllAttrData.GetLength() > 0 )
	{
		CTSAttr_Page::SettingAttrDataToDlgItems( m_strAllAttrData );
	}

	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}


BEGIN_MESSAGE_MAP(CTSAttr_ACT_ObjState, CTSAttr_Page)
END_MESSAGE_MAP()


// CTSAttr_ACT_ObjState �޽��� ó�����Դϴ�.
