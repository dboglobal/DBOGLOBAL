#pragma once


#include "TSShapeBoxCtrl.h"


class CSCtrl_Start : public CTSShapeBoxCtrl
{

	// Constructions and Destructions
public:

	CSCtrl_Start( CNtlTSToolView* pParent );
	virtual ~CSCtrl_Start( void );


	// Methods
public:

	virtual CTSShapeBox*				New( const CPoint& ptPos );
};
