// GroupIDInputBox.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "NtlTSTool.h"
#include "GroupIDInputBox.h"


// CGroupIDInputBox ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CGroupIDInputBox, CDialog)

CGroupIDInputBox::CGroupIDInputBox(CWnd* pParent /*=NULL*/)
	: CDialog(CGroupIDInputBox::IDD, pParent)
	, m_byGroupID(0xff)
{

}

CGroupIDInputBox::~CGroupIDInputBox()
{
}

void CGroupIDInputBox::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, m_byGroupID);
}


BEGIN_MESSAGE_MAP(CGroupIDInputBox, CDialog)
END_MESSAGE_MAP()


// CGroupIDInputBox �޽��� ó�����Դϴ�.
