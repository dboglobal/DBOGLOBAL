// TSAttr_ACT_ObjConv.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "NtlTSTool.h"
#include "TSAttr_ACT_ObjConv.h"


// CTSAttr_ACT_ObjConv ��ȭ �����Դϴ�.

IMPLEMENT_SERIAL(CTSAttr_ACT_ObjConv, CTSAttr_Page, 1)

CTSAttr_ACT_ObjConv::CTSAttr_ACT_ObjConv()
	: CTSAttr_Page(CTSAttr_ACT_ObjConv::IDD)
	, m_taID(NTL_TS_TA_ID_INVALID)
	, m_dwWorldIdx(0xffffffff)
	, m_dwObjIdx(0xffffffff)
	, m_uiConv(0xffffffff)
{

}

CTSAttr_ACT_ObjConv::~CTSAttr_ACT_ObjConv()
{
}

CString CTSAttr_ACT_ObjConv::CollectAttrDataFromDlgItems( void )
{
	CTSAttr_Page::CollectAttrDataFromDlgItems();

	CString strData;

	strData += MakeAttrData( _T("taid"), m_taID );
	strData += MakeAttrData( _T("ctype"), (int)m_ctrConvType.GetItemData( m_ctrConvType.GetCurSel() ) );
	strData += MakeAttrData( _T("widx"), m_dwWorldIdx );
	strData += MakeAttrData( _T("idx"), m_dwObjIdx );
	strData += MakeAttrData( _T("conv"), m_uiConv );

	return strData;
}

void CTSAttr_ACT_ObjConv::SettingAttrDataToDlgItems( CString& strKey, CString& strValue )
{
	if ( _T("taid") == strKey )
	{
		m_taID = atoi( strValue.GetBuffer() );
	}
	else if ( _T("ctype") == strKey )
	{
		int nValue = atoi( strValue.GetBuffer() );

		int nCnt = m_ctrConvType.GetCount();
		for ( int i = 0; i < nCnt; ++i )
		{
			if ( m_ctrConvType.GetItemData( i ) == nValue )
			{
				m_ctrConvType.SetCurSel( i );
				break;
			}
		}
	}
	else if ( _T("widx") == strKey )
	{
		m_dwWorldIdx = atoi( strValue.GetBuffer() );
	}
	else if ( _T("idx") == strKey )
	{
		m_dwObjIdx = atoi( strValue.GetBuffer() );
	}
	else if ( _T("conv") == strKey )
	{
		m_uiConv = atoi( strValue.GetBuffer() );
	}
}

void CTSAttr_ACT_ObjConv::DoDataExchange(CDataExchange* pDX)
{
	CTSAttr_Page::DoDataExchange(pDX);

	DDX_Text(pDX, IDC_TS_ACT_ATTR_OBJCONV_ID_EDITOR, m_taID);
	DDV_MinMaxUInt(pDX, m_taID, 0, NTL_TS_TA_ID_INVALID);
	DDX_Control(pDX, IDC_TS_ACT_ATTR_OBJCONV_OBJCONV_TYPE_COMBO, m_ctrConvType);
	DDX_Text(pDX, IDC_TS_ACT_ATTR_WORLD_INDEX_EDITOR, m_dwWorldIdx);
	DDX_Text(pDX, IDC_TS_ACT_ATTR_OBJCONV_INDEX_EDITOR, m_dwObjIdx);
	DDX_Text(pDX, IDC_TS_ACT_ATTR_OBJCONV_CONV_EDITOR, m_uiConv);
	DDV_MinMaxUInt(pDX, m_uiConv, 0, 0xffffffff);
}

BOOL CTSAttr_ACT_ObjConv::OnInitDialog()
{
	CTSAttr_Page::OnInitDialog();

	// TODO:  ���⿡ �߰� �ʱ�ȭ �۾��� �߰��մϴ�.
	m_ctrConvType.SetItemData( m_ctrConvType.AddString( _T("Dialog") ), eOBJCONV_TYPE_DIALOGBOX );
	m_ctrConvType.SetItemData( m_ctrConvType.AddString( _T("Tool tip") ), eOBJCONV_TYPE_TOOLTIP );
	int nIdx = m_ctrConvType.AddString( _T("Invalid") );
	m_ctrConvType.SetItemData( nIdx, eOBJCONV_TYPE_INVALID );
	m_ctrConvType.SetCurSel( nIdx );

	if ( m_strAllAttrData.GetLength() > 0 )
	{
		CTSAttr_Page::SettingAttrDataToDlgItems( m_strAllAttrData );
	}

	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}


BEGIN_MESSAGE_MAP(CTSAttr_ACT_ObjConv, CTSAttr_Page)
END_MESSAGE_MAP()


// CTSAttr_ACT_ObjConv �޽��� ó�����Դϴ�.
