#pragma once


#include "TSShapeBoxCtrl.h"


class CSCtrl_Narration : public CTSShapeBoxCtrl
{

	// Constructions and Destructions
public:

	CSCtrl_Narration( CNtlTSToolView* pParent );
	virtual ~CSCtrl_Narration( void );


	// Methods
public:

	virtual CTSShapeBox*				New( const CPoint& ptPos );
};
