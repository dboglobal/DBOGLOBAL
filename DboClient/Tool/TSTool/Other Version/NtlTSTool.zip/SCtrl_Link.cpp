#include "StdAfx.h"
#include "SCtrl_Link.h"


#include "NtlTSToolDoc.h"
#include "NtlTSToolView.h"

#include "Shape_Link.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#endif


CSCtrl_Link::CSCtrl_Link( CNtlTSToolView* pParent )
: CTSShapeCtrl( pParent )
{
	m_eLinkerType = eLINKER_TYPE_INVALID;
	m_pSrcShape = NULL;
	m_pLinkerInfo = NULL;
	m_pShapeLink = NULL;
}


CSCtrl_Link::~CSCtrl_Link( void )
{
}


void CSCtrl_Link::OnMouseLButtonDown( const CPoint& ptPos, UINT nFlags, eLINKER_TYPE eLinkerType, CTSShape* pSrcShape, void* pLinkerInfo )
{
	CTSShapeCtrl::OnMouseLButtonDown( ptPos, nFlags );

	m_eLinkerType = eLinkerType;
	m_pSrcShape = pSrcShape;
	m_pLinkerInfo = pLinkerInfo;

	m_pShapeLink = New( ptPos );

	GetParent()->GetDocument()->AddShape( m_pShapeLink );
	GetParent()->GetDocument()->SelectShape( m_pShapeLink, false );
}


void CSCtrl_Link::OnMouseLButtonUp( const CPoint& ptPos, UINT nFlags )
{
	CTSShapeCtrl::OnMouseLButtonUp( ptPos, nFlags );

	if ( m_pShapeLink )
	{
		CTSShape* pDestShape = m_pParent->GetDocument()->GetShapeAt( ptPos );

		if ( NULL == pDestShape )
		{
			m_pParent->GetDocument()->RemoveShape( m_pShapeLink );

			m_eLinkerType = eLINKER_TYPE_INVALID;
			m_pSrcShape = NULL;
			m_pShapeLink = NULL;
			m_pLinkerInfo = NULL;

			return;
		}

		m_pShapeLink->Finish( ptPos, pDestShape );

		m_pShapeLink->BeginDrag( m_pShapeLink->GetHandlerPos( 0 ), 0 );
		m_pShapeLink->Drag( m_pParent->Align2Grid( m_pShapeLink->GetHandlerPos( 0 ) ) );
		m_pShapeLink->EndDrag();

		m_pShapeLink->BeginDrag( m_pShapeLink->GetHandlerPos( 1 ), 1 );
		m_pShapeLink->Drag( m_pParent->Align2Grid( m_pShapeLink->GetHandlerPos( 1 ) ) );
		m_pShapeLink->EndDrag();

		m_pShapeLink = NULL;
	}
}


void CSCtrl_Link::OnMouseLButtonDoubleClick( const CPoint& ptPos, UINT nFlags )
{
	CTSShapeCtrl::OnMouseLButtonDoubleClick( ptPos, nFlags );
}


void CSCtrl_Link::OnMouseMove( const CPoint& ptPos, UINT nFlags )
{
	CTSShapeCtrl::OnMouseMove( ptPos, nFlags );

	if ( m_pShapeLink )
	{
		m_pShapeLink->DragTemp( ptPos );
		m_pParent->Invalidate();
	}
}


void CSCtrl_Link::OnContextMenu( const CPoint& ptPos )
{
	CTSShapeCtrl::OnContextMenu( ptPos );
}


void CSCtrl_Link::OnDeactivate( void )
{
	CTSShapeCtrl::OnDeactivate();

	if ( m_pShapeLink )
	{
		m_pParent->GetDocument()->RemoveShape( m_pShapeLink );

		m_eLinkerType = eLINKER_TYPE_INVALID;
		m_pSrcShape = NULL;
		m_pShapeLink = NULL;
		m_pLinkerInfo = NULL;
	}
}


CShape_Link* CSCtrl_Link::New( const CPoint& ptPos )
{
	CTSGroup* pGroup = m_pParent->GetDocument()->GetSelGroup();

	if ( NULL == pGroup )
	{
		ASSERT( !_T("A group must be selected.") );
		return NULL;
	}

	switch ( m_eLinkerType )
	{
	case eLINKER_TYPE_YES:
		return new CShape_Link( ptPos, pGroup, m_pSrcShape, m_eLinkerType, m_pLinkerInfo );

	case eLINKER_TYPE_NO:
		return new CShape_Link( ptPos, pGroup, m_pSrcShape, m_eLinkerType, m_pLinkerInfo );

	case eLINKER_TYPE_NEXT:
		return new CShape_Link( ptPos, pGroup, m_pSrcShape, m_eLinkerType, m_pLinkerInfo );

	case eLINKER_TYPE_CANCEL:
		return new CShape_Link( ptPos, pGroup, m_pSrcShape, m_eLinkerType, m_pLinkerInfo );

	case eLINKER_TYPE_ERROR:
		return new CShape_Link( ptPos, pGroup, m_pSrcShape, m_eLinkerType, m_pLinkerInfo );

	case eLINKER_TYPE_BRANCH:
		return new CShape_Link( ptPos, pGroup, m_pSrcShape, m_eLinkerType, m_pLinkerInfo );

	case eLINKER_TYPE_SWITCH:
		return new CShape_Link( ptPos, pGroup, m_pSrcShape, m_eLinkerType, m_pLinkerInfo );

	default:
		ASSERT( !_T("Not supported linker type.") );
		return NULL;
	}

	return NULL;
}


