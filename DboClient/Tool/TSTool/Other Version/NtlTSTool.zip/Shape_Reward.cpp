#include "stdafx.h"
#include "NtlTSTool.h"
#include "Shape_Reward.h"

#include "TSProjectEntity.h"

#include "NtlTSToolDoc.h"
#include "MainFrm.h"
#include "TSProject.h"
#include "OptionListBox.h"
#include "TSAttr_Page_Mng.h"
#include "TSAttr_CONT_Reward.h"


IMPLEMENT_SERIAL( CShape_Reward, CTSShapeBox, 1 )


CShape_Reward::CShape_Reward( void )
{
}


CShape_Reward::CShape_Reward( const CPoint& ptPos, CTSGroup* pParent )
: CTSShapeBox( ptPos, pParent )
{
	// Name

	sSHAPE_NAME sName;	sName.strShapeType = _T("cont_reward");
	SetShapeName( sName );

	// Container attributes

	AddShapeAttr( _T("desc"), CString(_T("-1")) );

	// Linker 

	int nHeight = g_pTSTheme->GetLinkerRadius() + 20;
	AddLinker( eLINKER_TYPE_NEXT, nHeight );

	nHeight += g_pTSTheme->GetLinkerRadius() * 2 + 2;
	AddLinker( eLINKER_TYPE_CANCEL, nHeight );

	// Group

	AddShapeGroup();
}


CShape_Reward::~CShape_Reward( void )
{
}


void CShape_Reward::Serialize( CArchive &ar )
{
	CTSShapeBox::Serialize( ar );

	if ( ar.IsStoring() )
	{
		Save( ar );
	}
	else
	{
		// Name

		sSHAPE_NAME sName;	sName.strShapeType = _T("cont_reward");
		SetShapeName( sName );

		// Linker 

		int nHeight = g_pTSTheme->GetLinkerRadius() + 20;
		AddLinker( eLINKER_TYPE_NEXT, nHeight );

		nHeight += g_pTSTheme->GetLinkerRadius() * 2 + 2;
		AddLinker( eLINKER_TYPE_CANCEL, nHeight );

		switch ( m_pParent->GetParent()->GetParent()->GetProjectEntityVersion() )
		{
		case 0:
			if ( !Load_Trig_Ver_00000000( ar ) )
			{
				return;
			}
			break;

		case 1:
			if ( !Load_Trig_Ver_00000001( ar ) )
			{
				return;
			}
			break;

		default:
			ASSERT( !_T("The version of its project entity file is wrong.") );
			return;
		}
	}
}


void CShape_Reward::ShowContainerAttributeEditDlg( void )
{
	CTSAttr_CONT_Reward AttrPage;
	AttrPage.AddAttr( _T("cid"), m_sShapeID.strShapeID );
	AttrPage.AddAttr( _T("desc"), GetShapeAttrValue( _T("desc") ) );

	if ( GetShapeAttrValue( _T("d0") ).GetLength() > 0 ) AttrPage.AddAttr( GetShapeAttrValue( _T("d0") ) );
	if ( GetShapeAttrValue( _T("d1") ).GetLength() > 0 ) AttrPage.AddAttr( GetShapeAttrValue( _T("d1") ) );
	if ( GetShapeAttrValue( _T("d2") ).GetLength() > 0 ) AttrPage.AddAttr( GetShapeAttrValue( _T("d2") ) );
	if ( GetShapeAttrValue( _T("d3") ).GetLength() > 0 ) AttrPage.AddAttr( GetShapeAttrValue( _T("d3") ) );

	if ( GetShapeAttrValue( _T("s0") ).GetLength() > 0 ) AttrPage.AddAttr( GetShapeAttrValue( _T("s0") ) );
	if ( GetShapeAttrValue( _T("s1") ).GetLength() > 0 ) AttrPage.AddAttr( GetShapeAttrValue( _T("s1") ) );
	if ( GetShapeAttrValue( _T("s2") ).GetLength() > 0 ) AttrPage.AddAttr( GetShapeAttrValue( _T("s2") ) );
	if ( GetShapeAttrValue( _T("s3") ).GetLength() > 0 ) AttrPage.AddAttr( GetShapeAttrValue( _T("s3") ) );

	COptionListBox clListBox;
	CTSAttr_Page_Mng clDiag;
	clDiag.SetListControl( &clListBox );

	clDiag.AddTSAttrPage( &AttrPage );

	if ( IDOK == clDiag.DoModal() && clDiag.GetActivatedPage() )
	{
		CString strValue;

		strValue = AttrPage.GetAttr( _T("cid") );
		if ( strValue.GetLength() != 0 ) m_sShapeID.strShapeID = strValue;

		strValue = AttrPage.GetAttr( _T("desc") );
		if ( strValue.GetLength() != 0 ) SetShapeAttr( _T("desc"), strValue );

		if ( AttrPage.GetAttr( _T("dtype0") ).GetLength() > 0 )
		{
			CString strData;
			strData += CTSAttr_Page::MakeAttrData( _T("dtype0"), AttrPage.GetAttr( _T("dtype0") ) );
			strData += CTSAttr_Page::MakeAttrData( _T("didx0"), AttrPage.GetAttr( _T("didx0") ) );
			strData += CTSAttr_Page::MakeAttrData( _T("dval0"), AttrPage.GetAttr( _T("dval0") ) );

			if ( HasShapeAttrValue( _T("d0") ) )	SetShapeAttr( _T("d0"), strData );
			else									AddShapeAttr( _T("d0"), strData );
		}
		else RemoveShapeAttr( _T("d0") );

		if ( AttrPage.GetAttr( _T("dtype1") ).GetLength() > 0 )
		{
			CString strData;
			strData += CTSAttr_Page::MakeAttrData( _T("dtype1"), AttrPage.GetAttr( _T("dtype1") ) );
			strData += CTSAttr_Page::MakeAttrData( _T("didx1"), AttrPage.GetAttr( _T("didx1") ) );
			strData += CTSAttr_Page::MakeAttrData( _T("dval1"), AttrPage.GetAttr( _T("dval1") ) );

			if ( HasShapeAttrValue( _T("d1") ) )	SetShapeAttr( _T("d1"), strData );
			else									AddShapeAttr( _T("d1"), strData );
		}
		else RemoveShapeAttr( _T("d1") );

		if ( AttrPage.GetAttr( _T("dtype2") ).GetLength() > 0 )
		{
			CString strData;
			strData += CTSAttr_Page::MakeAttrData( _T("dtype2"), AttrPage.GetAttr( _T("dtype2") ) );
			strData += CTSAttr_Page::MakeAttrData( _T("didx2"), AttrPage.GetAttr( _T("didx2") ) );
			strData += CTSAttr_Page::MakeAttrData( _T("dval2"), AttrPage.GetAttr( _T("dval2") ) );

			if ( HasShapeAttrValue( _T("d2") ) )	SetShapeAttr( _T("d2"), strData );
			else									AddShapeAttr( _T("d2"), strData );
		}
		else RemoveShapeAttr( _T("d2") );

		if ( AttrPage.GetAttr( _T("dtype3") ).GetLength() > 0 )
		{
			CString strData;
			strData += CTSAttr_Page::MakeAttrData( _T("dtype3"), AttrPage.GetAttr( _T("dtype3") ) );
			strData += CTSAttr_Page::MakeAttrData( _T("didx3"), AttrPage.GetAttr( _T("didx3") ) );
			strData += CTSAttr_Page::MakeAttrData( _T("dval3"), AttrPage.GetAttr( _T("dval3") ) );

			if ( HasShapeAttrValue( _T("d3") ) )	SetShapeAttr( _T("d3"), strData );
			else									AddShapeAttr( _T("d3"), strData );
		}
		else RemoveShapeAttr( _T("d3") );

		if ( AttrPage.GetAttr( _T("stype0") ).GetLength() > 0 )
		{
			CString strData;
			strData += CTSAttr_Page::MakeAttrData( _T("stype0"), AttrPage.GetAttr( _T("stype0") ) );
			strData += CTSAttr_Page::MakeAttrData( _T("sidx0"), AttrPage.GetAttr( _T("sidx0") ) );
			strData += CTSAttr_Page::MakeAttrData( _T("sval0"), AttrPage.GetAttr( _T("sval0") ) );

			if ( HasShapeAttrValue( _T("s0") ) )	SetShapeAttr( _T("s0"), strData );
			else									AddShapeAttr( _T("s0"), strData );
		}
		else RemoveShapeAttr( _T("s0") );

		if ( AttrPage.GetAttr( _T("stype1") ).GetLength() > 0 )
		{
			CString strData;
			strData += CTSAttr_Page::MakeAttrData( _T("stype1"), AttrPage.GetAttr( _T("stype1") ) );
			strData += CTSAttr_Page::MakeAttrData( _T("sidx1"), AttrPage.GetAttr( _T("sidx1") ) );
			strData += CTSAttr_Page::MakeAttrData( _T("sval1"), AttrPage.GetAttr( _T("sval1") ) );

			if ( HasShapeAttrValue( _T("s1") ) )	SetShapeAttr( _T("s1"), strData );
			else									AddShapeAttr( _T("s1"), strData );
		}
		else RemoveShapeAttr( _T("s1") );

		if ( AttrPage.GetAttr( _T("stype2") ).GetLength() > 0 )
		{
			CString strData;
			strData += CTSAttr_Page::MakeAttrData( _T("stype2"), AttrPage.GetAttr( _T("stype2") ) );
			strData += CTSAttr_Page::MakeAttrData( _T("sidx2"), AttrPage.GetAttr( _T("sidx2") ) );
			strData += CTSAttr_Page::MakeAttrData( _T("sval2"), AttrPage.GetAttr( _T("sval2") ) );

			if ( HasShapeAttrValue( _T("s2") ) )	SetShapeAttr( _T("s2"), strData );
			else									AddShapeAttr( _T("s2"), strData );
		}
		else RemoveShapeAttr( _T("s2") );

		if ( AttrPage.GetAttr( _T("stype3") ).GetLength() > 0 )
		{
			CString strData;
			strData += CTSAttr_Page::MakeAttrData( _T("stype3"), AttrPage.GetAttr( _T("stype3") ) );
			strData += CTSAttr_Page::MakeAttrData( _T("sidx3"), AttrPage.GetAttr( _T("sidx3") ) );
			strData += CTSAttr_Page::MakeAttrData( _T("sval3"), AttrPage.GetAttr( _T("sval3") ) );

			if ( HasShapeAttrValue( _T("s3") ) )	SetShapeAttr( _T("s3"), strData );
			else									AddShapeAttr( _T("s3"), strData );
		}
		else RemoveShapeAttr( _T("s3") );

		UpdateHeightInfo();

		((CNtlTSToolDoc*)((CMainFrame*)AfxGetMainWnd())->GetActiveDocument())->OnShapeChange( this );
	}
}


void CShape_Reward::ShowContainerEntityAttributeAddDlg( int nGroupID )
{
	if ( NULL == ((CNtlTSToolDoc*)((CMainFrame*)AfxGetMainWnd())->GetActiveDocument())->GetSelGroup() ) return;

	DWORD dwProjMode = ((CNtlTSToolDoc*)((CMainFrame*)AfxGetMainWnd())->GetActiveDocument())->GetTSProject()->GetProjectType();
	BYTE byGroupID = ((CNtlTSToolDoc*)((CMainFrame*)AfxGetMainWnd())->GetActiveDocument())->GetSelGroup()->GetGroupID();

	std::map<CTSAttr_Page*, CString> mapPageList;
	std::map<CTSAttr_Page*, CString>::iterator itPageList;

	if ( TS_TYPE_QUEST_CS == dwProjMode )
	{
		if ( eSEL_GROUP_TYPE_MAIN == byGroupID )
		{
			mapPageList[g_pTSConverter->GetAttrPage( _T("E_ColObject") )] = _T("E_ColObject");
			mapPageList[g_pTSConverter->GetAttrPage( _T("E_ClickObject") )] = _T("E_ClickObject");
			mapPageList[g_pTSConverter->GetAttrPage( _T("E_ClickNPC") )] = _T("E_ClickNPC");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_ClrQst") )] = _T("C_ClrQst");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_Item") )] = _T("C_Item");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_Lvl") )] = _T("C_Lvl");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_PCCls") )] = _T("C_PCCls");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_PCRace") )] = _T("C_PCRace");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_QItem") )] = _T("C_QItem");
//			mapPageList[g_pTSConverter->GetAttrPage( _T("C_SSM") )] = _T("C_SSM");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_SToCEvt") )] = _T("C_SToCEvt");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_WItem") )] = _T("C_WItem");
//			mapPageList[g_pTSConverter->GetAttrPage( _T("C_ObjItem") )] = _T("C_ObjItem");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_InNPC") )] = _T("C_InNPC");
		}
		else
		{
			AfxMessageBox( _T("����� �� �ִ� ������ �����ϴ�") );
		}
	}
	else if ( TS_TYPE_PC_TRIGGER_CS == dwProjMode )
	{
		AfxMessageBox( _T("����� �� �ִ� ������ �����ϴ�") );
	}
	else if ( TS_TYPE_OBJECT_TRIGGER_S == dwProjMode )
	{
		AfxMessageBox( _T("����� �� �ִ� ������ �����ϴ�") );
	}

	if ( !mapPageList.empty() )
	{
		COptionListBox clListBox;
		CTSAttr_Page_Mng clDiag;
		clDiag.SetListControl( &clListBox );

		for ( itPageList = mapPageList.begin(); itPageList != mapPageList.end(); ++itPageList ) clDiag.AddTSAttrPage( itPageList->first );

		if ( IDOK == clDiag.DoModal() )
		{
			CTSAttr_Page* pEditedPage = clDiag.GetActivatedPage();

			itPageList = mapPageList.find( pEditedPage );
			if ( itPageList != mapPageList.end() )
			{
				AddShapeEntity( nGroupID, itPageList->second, pEditedPage->GetAllAttrData() );
			}

			UpdateHeightInfo();

			((CNtlTSToolDoc*)((CMainFrame*)AfxGetMainWnd())->GetActiveDocument())->OnShapeChange( this );
		}

		for ( itPageList = mapPageList.begin(); itPageList != mapPageList.end(); ++itPageList ) delete itPageList->first;
		mapPageList.clear();
	}
}


void CShape_Reward::Save( CArchive& ar )
{
}


bool CShape_Reward::Load_Trig_Ver_00000000( CArchive& ar )
{
	return true;
}


bool CShape_Reward::Load_Trig_Ver_00000001( CArchive& ar )
{
	return true;
}
