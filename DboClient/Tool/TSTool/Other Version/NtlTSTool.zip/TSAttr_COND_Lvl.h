#pragma once


#include "TSAttr_Page.h"


// CTSAttr_COND_Lvl ��ȭ �����Դϴ�.

class CTSAttr_COND_Lvl : public CTSAttr_Page
{
	DECLARE_SERIAL(CTSAttr_COND_Lvl)

public:
	CTSAttr_COND_Lvl();
	virtual ~CTSAttr_COND_Lvl();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_TS_COND_LVL_ATTR_DIAG };

protected:
	virtual CString	CollectAttrDataFromDlgItems( void );
	virtual void	SettingAttrDataToDlgItems( CString& strKey, CString& strValue );

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()

public:
	int m_nMinLevel;
	int m_nMaxLevel;
};
