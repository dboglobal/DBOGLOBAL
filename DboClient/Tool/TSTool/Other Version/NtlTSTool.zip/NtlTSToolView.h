// NtlTSToolView.h : interface of the CNtlTSToolView class
//


#pragma once


class CTSShapeCtrl;
class CTSShapeSelectCtrl;
class CSCtrl_Start;
class CSCtrl_End;
class CSCtrl_GAct;
class CSCtrl_GCond;
class CSCtrl_Proposal;
class CSCtrl_Narration;
class CSCtrl_Reward;
class CSCtrl_UsrSel;
class CSCtrl_Switch;


class CNtlTSToolView : public CScrollView
{
protected: // create from serialization only
	CNtlTSToolView();
	DECLARE_DYNCREATE(CNtlTSToolView)

// Attributes
public:
	CNtlTSToolDoc* GetDocument() const;

// Operations
public:

// Overrides
	public:
	virtual void OnPrepareDC(CDC* pDC, CPrintInfo* pInfo = NULL);
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);

// Implementation
public:
	virtual ~CNtlTSToolView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	static CLIPFORMAT	s_clClipFmt;

protected:

	double m_dScale;
	bool m_bGrid;
	CSize m_GridSize;

	CTSShapeCtrl*		m_pCurrentShapeCtrl;

	CTSShapeSelectCtrl* m_pShapeSelectCtrl;

	CSCtrl_Start*		m_pCtrlStart;
	CSCtrl_End*			m_pCtrlEnd;
	CSCtrl_GAct*		m_pCtrlGAct;
	CSCtrl_GCond*		m_pCtrlGCond;
	CSCtrl_Proposal*	m_pCtrlProposal;
	CSCtrl_Narration*	m_pCtrlNarration;
	CSCtrl_Reward*		m_pCtrlReward;
	CSCtrl_UsrSel*		m_pCtrlUsrSel;
	CSCtrl_Switch*		m_pCtrlSwitch;

public:

	CPoint	Device2Doc( const CPoint& p );
	CRect	Device2Doc( const CRect& r );
	CPoint	Doc2Device( const CPoint& p );
	CRect	Doc2Device( const CRect& r );

	CPoint	Align2Grid( const CPoint& p ) const;
	CRect	Align2Grid( const CRect& r ) const;

	double	GetScale( void ) const { return m_dScale; }
	void	SetScale( double dScale );


protected:

	virtual void OnInitialUpdate( void );
	virtual void OnActivateView(BOOL bActivate, CView* pActivateView, CView* pDeactiveView);


// Generated message map functions
protected:
	DECLARE_MESSAGE_MAP()

public:
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	afx_msg void OnRButtonDblClk(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg BOOL OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	afx_msg void OnCreateTSProject();
	afx_msg void OnOpenTSProject();
	afx_msg void OnCloseTSProject();

	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);

	afx_msg BOOL OnEraseBkgnd(CDC* pDC);

	afx_msg void OnContainerSelect();
	afx_msg void OnUpdateContainerSelect(CCmdUI *pCmdUI);
	afx_msg void OnContainerStartcontainer();
	afx_msg void OnUpdateContainerStartcontainer(CCmdUI *pCmdUI);
	afx_msg void OnContainerEndcontainer();
	afx_msg void OnUpdateContainerEndcontainer(CCmdUI *pCmdUI);
	afx_msg void OnContainerGactcontainer();
	afx_msg void OnUpdateContainerGactcontainer(CCmdUI *pCmdUI);
	afx_msg void OnContainerGcondcontainer();
	afx_msg void OnUpdateContainerGcondcontainer(CCmdUI *pCmdUI);
	afx_msg void OnContainerProposalcontainer();
	afx_msg void OnUpdateContainerProposalcontainer(CCmdUI *pCmdUI);
	afx_msg void OnContainerRewardcontainer();
	afx_msg void OnUpdateContainerRewardcontainer(CCmdUI *pCmdUI);
	afx_msg void OnContainerNarrationcontainer();
	afx_msg void OnUpdateContainerNarrationcontainer(CCmdUI *pCmdUI);
	afx_msg void OnContainerSwitchcontainer();
	afx_msg void OnUpdateContainerSwitchcontainer(CCmdUI *pCmdUI);
	afx_msg void OnContainerUserselectcontainer();
	afx_msg void OnUpdateContainerUserselectcontainer(CCmdUI *pCmdUI);
	afx_msg void OnContainerNotecontainer();
	afx_msg void OnUpdateContainerNotecontainer(CCmdUI *pCmdUI);

	afx_msg void OnEditCopy( void );
	afx_msg void OnUpdateEditCopy( CCmdUI *pCmdUI );
	afx_msg void OnEditPaste( void );
	afx_msg void OnUpdateEditPaste( CCmdUI *pCmdUI );
	afx_msg void OnEditCut( void );
	afx_msg void OnUpdateEditCut( CCmdUI *pCmdUI );
};

#ifndef _DEBUG  // debug version in NtlTSToolView.cpp
inline CNtlTSToolDoc* CNtlTSToolView::GetDocument() const
   { return reinterpret_cast<CNtlTSToolDoc*>(m_pDocument); }
#endif
