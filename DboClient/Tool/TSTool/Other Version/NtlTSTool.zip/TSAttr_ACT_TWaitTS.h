#pragma once


#include "afxwin.h"
#include "TSAttr_Page.h"


// CTSAttr_ACT_TWaitTS ��ȭ �����Դϴ�.

class CTSAttr_ACT_TWaitTS : public CTSAttr_Page
{
	DECLARE_SERIAL(CTSAttr_ACT_TWaitTS)

public:
	CTSAttr_ACT_TWaitTS();
	virtual ~CTSAttr_ACT_TWaitTS();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_TS_ACT_TWAITTS_ATTR_DIAG };

protected:
	virtual CString	CollectAttrDataFromDlgItems( void );
	virtual void	SettingAttrDataToDlgItems( CString& strKey, CString& strValue );

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()

public:
	DWORD m_taID;
	DWORD m_dwWTime;
};
