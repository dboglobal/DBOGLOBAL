// TSAttr_CONT_Narration.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "NtlTSTool.h"
#include "TSAttr_CONT_Narration.h"


// CTSAttr_CONT_Narration ��ȭ �����Դϴ�.

IMPLEMENT_SERIAL(CTSAttr_CONT_Narration, CTSAttr_Page, 1)

CTSAttr_CONT_Narration::CTSAttr_CONT_Narration()
	: CTSAttr_Page(CTSAttr_CONT_Narration::IDD)
	, m_tcID(NTL_TS_TC_ID_INVALID)
	, m_dwOwnerIdx(0xffffffff)
	, m_uiDialog(0xffffffff)
{
}

CTSAttr_CONT_Narration::~CTSAttr_CONT_Narration()
{
}

CString CTSAttr_CONT_Narration::CollectAttrDataFromDlgItems( void )
{
	CTSAttr_Page::CollectAttrDataFromDlgItems();

	CString strData;

	strData += MakeAttrData( _T("cid"), m_tcID );
	strData += MakeAttrData( _T("pt"), (int)m_ctlProgState.GetItemData( m_ctlProgState.GetCurSel() ) );
	strData += MakeAttrData( _T("ot"), (int)m_ctlOwnerType.GetItemData( m_ctlOwnerType.GetCurSel() ) );
	strData += MakeAttrData( _T("oi"), m_dwOwnerIdx );
	strData += MakeAttrData( _T("os"), (int)m_ctlOwnerState.GetItemData( m_ctlOwnerState.GetCurSel() ) );
	strData += MakeAttrData( _T("dt"), (int)m_ctlDiaDirType.GetItemData( m_ctlDiaDirType.GetCurSel() ) );
	strData += MakeAttrData( _T("dg"), m_uiDialog );
	strData += MakeAttrData( _T("gt"), (int)m_ctlGUIType.GetItemData( m_ctlGUIType.GetCurSel() ) );

	return strData;
}

void CTSAttr_CONT_Narration::SettingAttrDataToDlgItems( CString& strKey, CString& strValue )
{
	if ( _T("cid") == strKey )
	{
		m_tcID = atoi( strValue.GetBuffer() );
	}
	else if ( _T("pt") == strKey )
	{
		int nValue = atoi( strValue.GetBuffer() );
		int nCnt = m_ctlProgState.GetCount();
		for ( int i = 0; i < nCnt; ++i )
		{
			if ( m_ctlProgState.GetItemData( i ) == nValue )
			{
				m_ctlProgState.SetCurSel( i );
				break;
			}
		}
	}
	else if ( _T("ot") == strKey )
	{
		int nValue = atoi( strValue.GetBuffer() );
		int nCnt = m_ctlOwnerType.GetCount();
		for ( int i = 0; i < nCnt; ++i )
		{
			if ( m_ctlOwnerType.GetItemData( i ) == nValue )
			{
				m_ctlOwnerType.SetCurSel( i );
				break;
			}
		}
	}
	else if ( _T("oi") == strKey )
	{
		m_dwOwnerIdx = atoi( strValue.GetBuffer() );
	}
	else if ( _T("os") == strKey )
	{
		int nValue = atoi( strValue.GetBuffer() );
		int nCnt = m_ctlOwnerState.GetCount();
		for ( int i = 0; i < nCnt; ++i )
		{
			if ( m_ctlOwnerState.GetItemData( i ) == nValue )
			{
				m_ctlOwnerState.SetCurSel( i );
				break;
			}
		}
	}
	else if ( _T("dt") == strKey )
	{
		int nValue = atoi( strValue.GetBuffer() );
		int nCnt = m_ctlDiaDirType.GetCount();
		for ( int i = 0; i < nCnt; ++i )
		{
			if ( m_ctlDiaDirType.GetItemData( i ) == nValue )
			{
				m_ctlDiaDirType.SetCurSel( i );
				break;
			}
		}
	}
	else if ( _T("dg") == strKey )
	{
		m_uiDialog = atoi( strValue.GetBuffer() );
	}
	else if ( _T("gt") == strKey )
	{
		int nValue = atoi( strValue.GetBuffer() );
		int nCnt = m_ctlGUIType.GetCount();
		for ( int i = 0; i < nCnt; ++i )
		{
			if ( m_ctlGUIType.GetItemData( i ) == nValue )
			{
				m_ctlGUIType.SetCurSel( i );
				break;
			}
		}
	}
}

void CTSAttr_CONT_Narration::DoDataExchange(CDataExchange* pDX)
{
	CTSAttr_Page::DoDataExchange(pDX);

	DDX_Text(pDX, IDC_TS_CONT_ATTR_NARRATION_ID_EDITOR, m_tcID);
	DDV_MinMaxUInt(pDX, m_tcID, 0, NTL_TS_TC_ID_INVALID);
	DDX_Control(pDX, IDC_TS_CONT_ATTR_NARRATION_PROGRESS_TYPE_COMBO, m_ctlProgState);
	DDX_Control(pDX, IDC_TS_CONT_ATTR_NARRATION_OWNER_TYPE_COMBO, m_ctlOwnerType);
	DDX_Text(pDX, IDC_TS_CONT_ATTR_NARRATION_OWNERIDX_EDITOR, m_dwOwnerIdx);
	DDX_Control(pDX, IDC_TS_CONT_ATTR_NARRATION_OWNER_STATE_COMBO, m_ctlOwnerState);
	DDX_Control(pDX, IDC_TS_CONT_ATTR_NARRATION_DIALOG_DIR_TYPE_COMBO, m_ctlDiaDirType);
	DDX_Text(pDX, IDC_TS_CONT_ATTR_NARRATION_DIALOG_EDITOR, m_uiDialog);
	DDV_MinMaxUInt(pDX, m_uiDialog, 0, 0xffffffff);
	DDX_Control(pDX, IDC_TS_CONT_ATTR_NARRATION_GUI_TYPE_COMBO, m_ctlGUIType);
}

BOOL CTSAttr_CONT_Narration::OnInitDialog()
{
	CTSAttr_Page::OnInitDialog();

	// TODO:  ���⿡ �߰� �ʱ�ȭ �۾��� �߰��մϴ�.
	int nCurSel = 0;

	m_ctlProgState.SetItemData( m_ctlProgState.AddString( _T("Start") ), eNARRATION_PROGRESS_STATE_START );
	nCurSel = m_ctlProgState.AddString( _T("Progress") );
	m_ctlProgState.SetItemData( nCurSel, eNARRATION_PROGRESS_STATE_PROGRESS );
	m_ctlProgState.SetItemData( m_ctlProgState.AddString( _T("End") ), eNARRATION_PROGRESS_STATE_END );
	m_ctlProgState.SetCurSel( nCurSel );

	nCurSel = m_ctlOwnerType.AddString( _T("NPC") );
	m_ctlOwnerType.SetItemData( nCurSel, eNARRATION_OWNER_NPC );
	m_ctlOwnerType.SetItemData( m_ctlOwnerType.AddString( _T("Mob") ), eNARRATION_OWNER_MOB );
	m_ctlOwnerType.SetCurSel( nCurSel );

	m_ctlOwnerState.SetItemData( m_ctlOwnerState.AddString( _T("1") ), eNARRATION_OWNER_STATE_1 );
	m_ctlOwnerState.SetItemData( m_ctlOwnerState.AddString( _T("2") ), eNARRATION_OWNER_STATE_2 );
	m_ctlOwnerState.SetItemData( m_ctlOwnerState.AddString( _T("3") ), eNARRATION_OWNER_STATE_3 );
	m_ctlOwnerState.SetItemData( m_ctlOwnerState.AddString( _T("4") ), eNARRATION_OWNER_STATE_4 );
	m_ctlOwnerState.SetCurSel( 0 );

	nCurSel = m_ctlDiaDirType.AddString( _T("Normal") );
	m_ctlDiaDirType.SetItemData( nCurSel, eNARRATION_DIALOG_DIR_TYPE_NORMAL );
	m_ctlDiaDirType.SetItemData( m_ctlDiaDirType.AddString( _T("Blend") ), eNARRATION_DIALOG_DIR_TYPE_BLENDING );
	m_ctlDiaDirType.SetItemData( m_ctlDiaDirType.AddString( _T("Line") ), eNARRATION_DIALOG_DIR_TYPE_LINE );
	m_ctlDiaDirType.SetCurSel( nCurSel );

	nCurSel = m_ctlGUIType.AddString( _T("Normal") );
	m_ctlGUIType.SetItemData( nCurSel, eNARRATION_GUI_TYPE_NORMAL );
	m_ctlGUIType.SetItemData( m_ctlGUIType.AddString( _T("Bomb") ), eNARRATION_GUI_TYPE_BOMB );
	m_ctlGUIType.SetCurSel( nCurSel );

	if ( m_strAllAttrData.GetLength() > 0 )
	{
		CTSAttr_Page::SettingAttrDataToDlgItems( m_strAllAttrData );
	}

	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}


BEGIN_MESSAGE_MAP(CTSAttr_CONT_Narration, CTSAttr_Page)
END_MESSAGE_MAP()


// CTSAttr_CONT_Narration �޽��� ó�����Դϴ�.
