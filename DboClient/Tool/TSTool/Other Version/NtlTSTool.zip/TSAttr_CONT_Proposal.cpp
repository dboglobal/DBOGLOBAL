// TSAttr_CONT_Proposal.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "NtlTSTool.h"
#include "TSAttr_CONT_Proposal.h"


// CTSAttr_CONT_Proposal ��ȭ �����Դϴ�.

IMPLEMENT_SERIAL(CTSAttr_CONT_Proposal, CTSAttr_Page, 1)

CTSAttr_CONT_Proposal::CTSAttr_CONT_Proposal()
	: CTSAttr_Page(CTSAttr_CONT_Proposal::IDD)
	, m_tcID(NTL_TS_TC_ID_INVALID)
	, m_uiTitle(0xffffffff)
	, m_uiArea(0xffffffff)
	, m_uiGoal(0xffffffff)
	, m_uiGrade(0xffffffff)
	, m_uiSort(0xffffffff)
	, m_uiContents(0xffffffff)
	, m_tcRewardID(NTL_TS_TC_ID_INVALID)
{

}

CTSAttr_CONT_Proposal::~CTSAttr_CONT_Proposal()
{
}

CString CTSAttr_CONT_Proposal::CollectAttrDataFromDlgItems( void )
{
	CTSAttr_Page::CollectAttrDataFromDlgItems();

	CString strData;

	strData += MakeAttrData( _T("cid"), m_tcID );
	strData += MakeAttrData( _T("title"), m_uiTitle );
	strData += MakeAttrData( _T("area"), m_uiArea );
	strData += MakeAttrData( _T("goal"), m_uiGoal );
	strData += MakeAttrData( _T("grade"), m_uiGrade );
	strData += MakeAttrData( _T("gtype"), (int)m_ctrGradeType.GetItemData( m_ctrGradeType.GetCurSel() ) );
	strData += MakeAttrData( _T("sort"), m_uiSort );
	strData += MakeAttrData( _T("cont"), m_uiContents );
	strData += MakeAttrData( _T("rwd"), m_tcRewardID );

	return strData;
}

void CTSAttr_CONT_Proposal::SettingAttrDataToDlgItems( CString& strKey, CString& strValue )
{
	if ( _T("cid") == strKey )
	{
		m_tcID = atoi( strValue.GetBuffer() );
	}
	else if ( _T("title") == strKey )
	{
		m_uiTitle = atoi( strValue.GetBuffer() );
	}
	else if ( _T("area") == strKey )
	{
		m_uiArea = atoi( strValue.GetBuffer() );
	}
	else if ( _T("goal") == strKey )
	{
		m_uiGoal = atoi( strValue.GetBuffer() );
	}
	else if ( _T("grade") == strKey )
	{
		m_uiGrade = atoi( strValue.GetBuffer() );
	}
	else if ( _T("gtype") == strKey )
	{
		int nValue = atoi( strValue.GetBuffer() );

		int nCnt = m_ctrGradeType.GetCount();
		for ( int i = 0; i < nCnt; ++i )
		{
			if ( m_ctrGradeType.GetItemData( i ) == nValue )
			{
				m_ctrGradeType.SetCurSel( i );
				break;
			}
		}
	}
	else if ( _T("sort") == strKey )
	{
		m_uiSort = atoi( strValue.GetBuffer() );
	}
	else if ( _T("cont") == strKey )
	{
		m_uiContents = atoi( strValue.GetBuffer() );
	}
	else if ( _T("rwd") == strKey )
	{
		m_tcRewardID = atoi( strValue.GetBuffer() );
	}
}

void CTSAttr_CONT_Proposal::DoDataExchange(CDataExchange* pDX)
{
	CTSAttr_Page::DoDataExchange(pDX);

	DDX_Text(pDX, IDC_TS_CONT_ATTR_PROPOSAL_ID_EDITOR, m_tcID);
	DDV_MinMaxUInt(pDX, m_tcID, 0, NTL_TS_TC_ID_INVALID);
	DDX_Text(pDX, IDC_TS_CONT_ATTR_PROPOSAL_TITLE_EDITOR, m_uiTitle);
	DDV_MinMaxUInt(pDX, m_uiTitle, 0, 0xffffffff);
	DDX_Text(pDX, IDC_TS_CONT_ATTR_PROPOSAL_AREA_EDITOR, m_uiArea);
	DDV_MinMaxUInt(pDX, m_uiArea, 0, 0xffffffff);
	DDX_Text(pDX, IDC_TS_CONT_ATTR_PROPOSAL_GOAL_EDITOR, m_uiGoal);
	DDV_MinMaxUInt(pDX, m_uiGoal, 0, 0xffffffff);
	DDX_Text(pDX, IDC_TS_CONT_ATTR_PROPOSAL_GRADE_EDITOR, m_uiGrade);
	DDV_MinMaxUInt(pDX, m_uiGrade, 0, 0xffffffff);
	DDX_Control(pDX, IDC_TS_CONT_ATTR_PROPOSAL_GRADE_COMBO, m_ctrGradeType);
	DDX_Text(pDX, IDC_TS_CONT_ATTR_PROPOSAL_SORT_EDITOR, m_uiSort);
	DDV_MinMaxUInt(pDX, m_uiSort, 0, 0xffffffff);
	DDX_Text(pDX, IDC_TS_CONT_ATTR_PROPOSAL_CONTENTS_EDITOR, m_uiContents);
	DDV_MinMaxUInt(pDX, m_uiContents, 0, 0xffffffff);
	DDX_Text(pDX, IDC_TS_CONT_ATTR_PROPOSAL_REWARD_ID_EDITOR, m_tcRewardID);
	DDV_MinMaxUInt(pDX, m_tcRewardID, 0, NTL_TS_TC_ID_INVALID);
}


BOOL CTSAttr_CONT_Proposal::OnInitDialog()
{
	CTSAttr_Page::OnInitDialog();

	// TODO:  ���⿡ �߰� �ʱ�ȭ �۾��� �߰��մϴ�.
	m_ctrGradeType.SetItemData( m_ctrGradeType.AddString( _T("Very easy") ), eGRADE_TYPE_VERY_EASY );
	m_ctrGradeType.SetItemData( m_ctrGradeType.AddString( _T("Easy") ), eGRADE_TYPE_EASY );
	m_ctrGradeType.SetItemData( m_ctrGradeType.AddString( _T("Normal") ), eGRADE_TYPE_NORMAL );
	m_ctrGradeType.SetItemData( m_ctrGradeType.AddString( _T("Hard") ), eGRADE_TYPE_HARD );
	m_ctrGradeType.SetItemData( m_ctrGradeType.AddString( _T("Very hard") ), eGRADE_TYPE_VERY_HARD );
	m_ctrGradeType.SetItemData( m_ctrGradeType.AddString( _T("Impossible") ), eGRADE_TYPE_IMPOSSIBLE );
	int nIdx = m_ctrGradeType.AddString( _T("Invalid") );
	m_ctrGradeType.SetItemData( nIdx, eGRADE_TYPE_INVALID );
	m_ctrGradeType.SetCurSel( nIdx );

	if ( m_strAllAttrData.GetLength() > 0 )
	{
		CTSAttr_Page::SettingAttrDataToDlgItems( m_strAllAttrData );
	}

	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}

BEGIN_MESSAGE_MAP(CTSAttr_CONT_Proposal, CTSAttr_Page)
END_MESSAGE_MAP()


// CTSAttr_CONT_Proposal �޽��� ó�����Դϴ�.
