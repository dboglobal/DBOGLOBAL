// TSAttr_Link.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "NtlTSTool.h"
#include "TSAttr_Link.h"


// CTSAttr_Link ��ȭ �����Դϴ�.

IMPLEMENT_SERIAL(CTSAttr_Link, CTSAttr_Page, 1)

CTSAttr_Link::CTSAttr_Link(CWnd* pParent /*=NULL*/)
	: CTSAttr_Page(CTSAttr_Link::IDD)
	, m_uiBranchName(0xffffffff)
{

}

CTSAttr_Link::~CTSAttr_Link()
{
}

CString CTSAttr_Link::CollectAttrDataFromDlgItems( void )
{
	CTSAttr_Page::CollectAttrDataFromDlgItems();

	CString strData;

	strData += MakeAttrData( _T("branchname"), m_uiBranchName );

	return strData;
}

void CTSAttr_Link::SettingAttrDataToDlgItems( CString& strKey, CString& strValue )
{
	if ( _T("branchname") == strKey )
	{
		m_uiBranchName = atoi( strValue.GetBuffer() );
	}
}

void CTSAttr_Link::DoDataExchange(CDataExchange* pDX)
{
	CTSAttr_Page::DoDataExchange(pDX);

	DDX_Text(pDX, IDC_LINK_BRANCH_NAME, m_uiBranchName);
	DDV_MinMaxUInt(pDX, m_uiBranchName, 0, 0xffffffff);
}


BEGIN_MESSAGE_MAP(CTSAttr_Link, CTSAttr_Page)
END_MESSAGE_MAP()


// CTSAttr_Link �޽��� ó�����Դϴ�.
