#pragma once


#include "TSShape.h"


class CTSTrigger;


class CTSGroup : public CObject
{

	DECLARE_SERIAL( CTSGroup )


// Member variables
public:

	static CTSGroup*					s_pTempLoadGroup;	// Load�� ���� Shape ������ �ڽ��� �θ� ������ �� �ֵ��� �ϴ� �ӽú���
															// Serial loading�� �����ϰ��� �׻� NULL �̾�� �Ѵ�.


protected:

	CTSTrigger*							m_pParent;

	BYTE								m_byGroupID;

	TSShapeList							m_LinkLayer;
	TSShapeList							m_ContainerLayer;
	TSShapeList							m_NoteLayer;


// Constructions and Destructions
protected:

	CTSGroup( void );

public:

	~CTSGroup( void );


// Methods
public:

	CTSTrigger*							GetParent( void ) const { return m_pParent; }
	void								SetParent( CTSTrigger* pParent ) { m_pParent = pParent; }

	BYTE								GetGroupID( void ) const { return m_byGroupID; }
	void								SetGroupID( BYTE byGroupID ) { m_byGroupID = byGroupID; }

	TSShapeList&						GetLinkLayer( void ) { return m_LinkLayer; }
	TSShapeList&						GetContainerLayer( void ) { return m_ContainerLayer; }
	TSShapeList&						GetNoteLayer( void ) { return m_NoteLayer; }

	void								RaiseUp( CTSShape* pShape );

	void								ClearAll( void );

	virtual void						Serialize( CArchive& ar );


// Implementations
protected:

	void								Save( CArchive& ar );

	bool								Load_Trig_Ver_00000000( CArchive& ar );
	bool								Load_Trig_Ver_00000001( CArchive& ar );

};


class CTSProjectEntity;


class CTSTrigger : public CObject
{

	DECLARE_SERIAL( CTSTrigger )


// Member variables
protected:

	CTSProjectEntity*					m_pParent;

	CString								m_strAttr;

	CArray< CTSGroup* >					m_GroupList;


// Constructions and Destructions
protected:

	CTSTrigger( void );

public:

	~CTSTrigger( void );


// Methods
public:

	CTSProjectEntity*					GetParent( void ) const { return m_pParent; }
	void								SetParent( CTSProjectEntity* pParent ) { m_pParent = pParent; }

	CString								GetAttribute( void ) const { return m_strAttr; }
	void								SetAttribute( const CString& strAttr ) { m_strAttr = strAttr; }

	const CArray< CTSGroup* >&			GetGroupList( void ) const { return m_GroupList; }
	CTSGroup*							GetGroup( BYTE byGroupID ) const;
	CTSGroup*							CreateGroup( BYTE byGroupID );
	void								DeleteGroup( BYTE byGroupID );
	void								DeleteGroup( CTSGroup*& pGroup );
	void								DeleteAllGroup( void );

	void								ClearAll( void );

	virtual void						Serialize( CArchive& ar );


// Implementations
protected:

	void								Save( CArchive& ar );

	bool								Load_Trig_Ver_00000000( CArchive& ar );
	bool								Load_Trig_Ver_00000001( CArchive& ar );

};


class CTSProjectEntity : public CObject
{

	DECLARE_SERIAL( CTSProjectEntity )


// Member variables
protected:

	CString								m_strProjectEntityHeader;
	DWORD								m_dwProjectEntityVersion;

	CTSTrigger*							m_pTrigger;


// Constructions and Destructions
protected:

	CTSProjectEntity( void );


public:

	virtual ~CTSProjectEntity( void );


// Methods
public:

	CString								GetProjectEntityHeader( void ) const { return m_strProjectEntityHeader; }

	DWORD								GetProjectEntityVersion( void ) const { return m_dwProjectEntityVersion; }
	void								SetProjectEntityVersion( DWORD dwProjectEntityVersion ) { m_dwProjectEntityVersion = dwProjectEntityVersion; }

	CTSTrigger*							GetTrigger( void ) { return m_pTrigger; }

	void								ClearAll( void );

	virtual void						Serialize( CArchive& ar );


// Implementations
protected:

	void								Save( CArchive& ar );

	bool								Load_Trig_Ver_00000000( CArchive& ar );
	bool								Load_Trig_Ver_00000001( CArchive& ar );

};
