// TSAttr_ACT_ETimerS.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "NtlTSTool.h"
#include "TSAttr_ACT_ETimerS.h"


// CTSAttr_ACT_ETimerS ��ȭ �����Դϴ�.

IMPLEMENT_SERIAL(CTSAttr_ACT_ETimerS, CTSAttr_Page, 1)

CTSAttr_ACT_ETimerS::CTSAttr_ACT_ETimerS()
	: CTSAttr_Page(CTSAttr_ACT_ETimerS::IDD)
	, m_taID(NTL_TS_TA_ID_INVALID)
	, m_dwWaitTime(0xffffffff)
	, m_tgID(1)
{

}

CTSAttr_ACT_ETimerS::~CTSAttr_ACT_ETimerS()
{
}

CString CTSAttr_ACT_ETimerS::CollectAttrDataFromDlgItems( void )
{
	CTSAttr_Page::CollectAttrDataFromDlgItems();

	CString strData;

	strData += MakeAttrData( _T("taid"), m_taID );
	strData += MakeAttrData( _T("sort"), (int)m_ctrTimerSort.GetItemData( m_ctrTimerSort.GetCurSel() ) );
	strData += MakeAttrData( _T("time"), m_dwWaitTime * 1000 );
	strData += MakeAttrData( _T("tgid"), m_tgID );

	return strData;
}

void CTSAttr_ACT_ETimerS::SettingAttrDataToDlgItems( CString& strKey, CString& strValue )
{
	if ( _T("taid") == strKey )
	{
		m_taID = atoi( strValue.GetBuffer() );
	}
	else if ( _T("sort") == strKey )
	{
		int nValue = atoi( strValue.GetBuffer() );

		int nCnt = m_ctrTimerSort.GetCount();
		for ( int i = 0; i < nCnt; ++i )
		{
			if ( m_ctrTimerSort.GetItemData( i ) == nValue )
			{
				m_ctrTimerSort.SetCurSel( i );
				break;
			}
		}
	}
	else if ( _T("time") == strKey )
	{
		m_dwWaitTime = atoi( strValue.GetBuffer() ) / 1000;
	}
	else if ( _T("tgid") == strKey )
	{
		m_tgID = atoi( strValue.GetBuffer() );
	}
}

void CTSAttr_ACT_ETimerS::DoDataExchange(CDataExchange* pDX)
{
	CTSAttr_Page::DoDataExchange(pDX);

	DDX_Text(pDX, IDC_TS_ACT_ATTR_EXCEPTTIMER_S_ID_EDITOR, m_taID);
	DDV_MinMaxUInt(pDX, m_taID, 0, NTL_TS_TA_ID_INVALID);
	DDX_Control(pDX, IDC_TS_ACT_ATTR_EXCEPTTIMER_TIMERSORT_COMBO, m_ctrTimerSort);
	DDX_Text(pDX, IDC_TS_ACT_ATTR_EXCEPTTIMER_WTIME_EDITOR, m_dwWaitTime);
	DDX_Text(pDX, IDC_TS_ACT_ATTR_EXCEPTTIMER_GROUPID_EDITOR, m_tgID);

	if ( m_ctrTimerSort.GetSafeHwnd() )
	{
		DWORD_PTR dwData = m_ctrTimerSort.GetItemData( m_ctrTimerSort.GetCurSel() );
		switch ( dwData )
		{
		case eEXCEPT_TIMER_SORT_LIMIT_TIMER:
			{
				DDV_MinMaxUInt(pDX, m_tgID, NTL_TS_EXCEPT_TLIMT_GROUP_ID_BEGIN, NTL_TS_EXCEPT_TLIMT_GROUP_ID_END );
			}
			break;
		case eEXCEPT_TIMER_SORT_SERVER_TIMER:
			{
				DDV_MinMaxUInt(pDX, m_tgID, NTL_TS_EXCEPT_SERVER_GROUP_ID_BEGIN, NTL_TS_EXCEPT_SERVER_GROUP_ID_END );
			}
			break;
		case eEXCEPT_TIMER_SORT_CLIENT_TIMER:
			{
				DDV_MinMaxUInt(pDX, m_tgID, NTL_TS_EXCEPT_CLIENT_GROUP_ID_BEGIN, NTL_TS_EXCEPT_CLIENT_GROUP_ID_END );
			}
			break;
		default:
			{
				DDV_MinMaxUInt(pDX, m_tgID, 0, NTL_TS_TG_ID_INVALID);
			}
			break;
		}
	}
	else
	{
		DDV_MinMaxUInt(pDX, m_tgID, 0, NTL_TS_TG_ID_INVALID);
	}
}

BOOL CTSAttr_ACT_ETimerS::OnInitDialog()
{
	CTSAttr_Page::OnInitDialog();

	// TODO:  ���⿡ �߰� �ʱ�ȭ �۾��� �߰��մϴ�.

	m_ctrTimerSort.SetItemData( m_ctrTimerSort.AddString( _T("Server timer") ), eEXCEPT_TIMER_SORT_SERVER_TIMER );
	m_ctrTimerSort.SetItemData( m_ctrTimerSort.AddString( _T("Client timer") ), eEXCEPT_TIMER_SORT_CLIENT_TIMER );
	int nIdx = m_ctrTimerSort.AddString( _T("Time limit timer") );
	m_ctrTimerSort.SetItemData( nIdx, eEXCEPT_TIMER_SORT_LIMIT_TIMER );
	m_ctrTimerSort.SetCurSel( nIdx );

	if ( m_strAllAttrData.GetLength() > 0 )
	{
		CTSAttr_Page::SettingAttrDataToDlgItems( m_strAllAttrData );
	}

	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}


BEGIN_MESSAGE_MAP(CTSAttr_ACT_ETimerS, CTSAttr_Page)
END_MESSAGE_MAP()


// CTSAttr_ACT_ETimerS �޽��� ó�����Դϴ�.

