#include "StdAfx.h"
#include "TSShape.h"
#include "TSProjectEntity.h"

#include "MainFrm.h"
#include "NtlTSToolDoc.h"

#include "TSProjectEntity.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#endif


IMPLEMENT_SERIAL( CTSShape, CObject, 1 )


CTSShape::CTSShape( void )
{
	m_pParent = CTSGroup::s_pTempLoadGroup;

	ASSERT( m_pParent );

	m_bDragging = false;

	m_hDragHandler = eHHANDLER_INVALID;

	m_bZombie = false;
}


CTSShape::CTSShape( CTSGroup* pParent )
{
	m_pParent = pParent;

	ASSERT( m_pParent );

	m_bDragging = false;

	m_hDragHandler = eHHANDLER_INVALID;

	m_bZombie = false;
}


HHANDLER CTSShape::GetHandlerAt( const CPoint &ptPos ) const
{
	for ( int i = 0; i < GetHandlerCount(); ++i )
	{
		CPoint ptHanlder = GetHandlerPos( i );

		CRect rt( ptHanlder, CSize(0, 0) );
		rt.InflateRect( g_pTSTheme->GetHandlerRadius(), g_pTSTheme->GetHandlerRadius() );

		if ( rt.PtInRect( ptPos ) )
		{
			return i;
		}
	}

	return eHHANDLER_INVALID;
}


CPoint CTSShape::GetHandlerPos( HHANDLER hHandler ) const
{
	ASSERT( !"Not implemented" );
	return CPoint();
}


HCURSOR CTSShape::GetHandlerCursor( HHANDLER hHandler ) const
{
	return AfxGetApp()->LoadStandardCursor( IDC_ARROW );
}


HLINKER CTSShape::GetLinkerAt( const CPoint &ptPos ) const
{
	for ( int i = 0; i < GetLinkerCount(); ++i )
	{
		CPoint ptLinker = GetLinkerPos( i );

		CRect rt( ptLinker, CSize(0, 0) );
		rt.InflateRect( g_pTSTheme->GetLinkerRadius(), g_pTSTheme->GetLinkerRadius() );

		if ( rt.PtInRect( ptPos ) )
		{
			return i;
		}
	}

	return eHLINKER_INVALID;
}


HLINKER CTSShape::GetLinkerHandleFromLinkerType( eLINKER_TYPE eLinkerType ) const
{
	for ( int i = 0; i < GetLinkerCount(); ++i )
	{
		if ( eLinkerType == GetLinkerType( i ) )
		{
			return i;
		}
	}

	ASSERT( !"Can not find the linker handle." );

	return eHLINKER_INVALID;
}


CPoint CTSShape::GetLinkerPos( HLINKER hHandler ) const
{
	ASSERT( !"Not implemented" );
	return CPoint();
}


CPoint CTSShape::GetLinkerPosFromLinkerType( eLINKER_TYPE eLinkerType ) const
{
	for ( int i = 0; i < GetLinkerCount(); ++i )
	{
		if ( eLinkerType == GetLinkerType( i ) )
		{
			return GetLinkerPos( i );
		}
	}

	ASSERT( !"Can not find the linker type." );
	return CPoint();
}


CPoint CTSShape::GetLinkerPosFromLinkerInfo( void* pLinkerInfo ) const
{
	for ( int i = 0; i < GetLinkerCount(); ++i )
	{
		if ( pLinkerInfo == GetLinkerInfo( i ) )
		{
			return GetLinkerPos( i );
		}
	}

	ASSERT( !"Can not find the linker info." );
	return CPoint();
}


eLINKER_TYPE CTSShape::GetLinkerType( HLINKER hHandler ) const
{
	ASSERT( !"Not implemented" );
	return eLINKER_TYPE_INVALID;
}


void* CTSShape::GetLinkerInfo( HLINKER hHandler ) const
{
	ASSERT( !"Not implemented" );
	return NULL;
}


HCURSOR CTSShape::GetLinkerCursor( HLINKER hHandler ) const
{
	return AfxGetApp()->LoadStandardCursor( IDC_ARROW );
}


bool CTSShape::Intersects( const CPoint &ptPos ) const
{
	CRect rt( ptPos, CSize(0, 0) );
	rt.InflateRect( 1, 1 );
	return Intersects( rt );
}


void CTSShape::BeginDrag( const CPoint &ptPos, HHANDLER hHandler /*= eHHANDLER_INVALID*/ )
{
	ASSERT( !m_bDragging );

	m_bDragging		= true;
	m_ptDragPoint	= ptPos;
	m_ptLastPoint	= ptPos;

	m_hDragHandler	= hHandler;

	((CNtlTSToolDoc*)((CMainFrame*)AfxGetMainWnd())->GetActiveDocument())->OnShapeChange( this );
}


void CTSShape::Drag( const CPoint &ptPos )
{
	ASSERT( m_bDragging );

	if ( eHHANDLER_INVALID == m_hDragHandler )
	{
		CSize delta = ptPos - m_ptLastPoint;
		m_ptOrigin += delta;
	}

	m_ptLastPoint = ptPos;

	((CNtlTSToolDoc*)((CMainFrame*)AfxGetMainWnd())->GetActiveDocument())->OnShapeChange( this );
}


void CTSShape::EndDrag( void )
{
	ASSERT( m_bDragging );

	m_bDragging = false;

	((CNtlTSToolDoc*)((CMainFrame*)AfxGetMainWnd())->GetActiveDocument())->OnShapeChange( this );
}


void CTSShape::RenderHandler( CDC* pDC ) const
{
	CPen cHandlerPen( PS_SOLID, 0, RGB( 0, 0, 0 ) );
	CBrush cHandlerBrush( RGB( 255, 255, 255 ) );

	CPen* pcOldPen = pDC->SelectObject( &cHandlerPen );
	CBrush* pcOldBrush = pDC->SelectObject( &cHandlerBrush );

	for ( int i = 0; i < GetHandlerCount(); ++i )
	{
		CPoint ptHandler = GetHandlerPos( i );

		CRect rt( ptHandler, CSize( 0, 0 ) );
		rt.InflateRect( g_pTSTheme->GetHandlerRadius(), g_pTSTheme->GetHandlerRadius() );

		pDC->Rectangle( rt );
	}

	pDC->SelectObject( pcOldPen );
	pDC->SelectObject( pcOldBrush );
}


void CTSShape::RenderLinker( CDC* pDC ) const
{
	for ( int i = 0; i < GetLinkerCount(); ++i )
	{
		CPoint ptLinker = GetLinkerPos( i );
		eLINKER_TYPE eLinkerType = GetLinkerType( i );

		CRect rt( ptLinker, CSize( 0, 0 ) );
		rt.InflateRect( g_pTSTheme->GetLinkerRadius(), g_pTSTheme->GetLinkerRadius() );

		COLORREF cLinkerBGColor = g_pTSTheme->GetLinkerBGColor( eLinkerType );
		CFont* pLinkerStringFont = g_pTSTheme->GetLinkerStringFont();
		COLORREF cLinkerStringColor = g_pTSTheme->GetLinkerStringColor( eLinkerType );
		CString strLinkerString = g_pTSTheme->GetLinkerString( eLinkerType );

		CBrush Brush( cLinkerBGColor ), *pOldBrush;
		CPen Pen( PS_SOLID, 0, cLinkerStringColor ), *pOldPen;
		CFont *pOldFont;

		pOldBrush = pDC->SelectObject( &Brush );
		pOldPen = pDC->SelectObject( &Pen );
		pOldFont = pDC->SelectObject( pLinkerStringFont );

		pDC->SetBkMode( TRANSPARENT );

		pDC->Rectangle( rt );

		pDC->SetTextColor( cLinkerStringColor );
		pDC->DrawText( strLinkerString, rt, DT_CENTER|DT_SINGLELINE|DT_VCENTER|DT_END_ELLIPSIS|DT_NOPREFIX );

		pDC->SelectObject( pOldPen );
		pDC->SelectObject( pOldBrush );
		pDC->SelectObject( pOldFont );
	}
}


HCURSOR CTSShape::OnMouseMove( const CPoint &ptPos, UINT nFlags )
{
	return AfxGetApp()->LoadStandardCursor( IDC_ARROW );
}


void CTSShape::Serialize( CArchive &ar )
{
	CObject::Serialize( ar );

	if ( ar.IsStoring() )
	{
		Save( ar );
	}
	else
	{
		ClearAll();

		switch ( m_pParent->GetParent()->GetParent()->GetProjectEntityVersion() )
		{
		case 0:
			if ( !Load_Trig_Ver_00000000( ar ) )
			{
				return;
			}
			break;

		case 1:
			if ( !Load_Trig_Ver_00000001( ar ) )
			{
				return;
			}
			break;

		default:
			ASSERT( !_T("The version of its project entity file is wrong.") );
			return;
		}
	}
}


void CTSShape::ClearAll( void )
{
	m_bDragging = false;

	m_hDragHandler = eHHANDLER_INVALID;

	m_bZombie = false;
}


void CTSShape::Save( CArchive& ar )
{
	ar << m_ptOrigin;
}


bool CTSShape::Load_Trig_Ver_00000000( CArchive& ar )
{
	ar >> m_ptOrigin;

	return true;
}


bool CTSShape::Load_Trig_Ver_00000001( CArchive& ar )
{
	ar >> m_ptOrigin;

	return true;
}
