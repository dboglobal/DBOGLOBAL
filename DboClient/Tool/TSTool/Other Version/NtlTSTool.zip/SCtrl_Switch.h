#pragma once


#include "TSShapeBoxCtrl.h"


class CSCtrl_Switch : public CTSShapeBoxCtrl
{

	// Constructions and Destructions
public:

	CSCtrl_Switch( CNtlTSToolView* pParent );
	virtual ~CSCtrl_Switch( void );


	// Methods
public:

	virtual CTSShapeBox*				New( const CPoint& ptPos );
};
