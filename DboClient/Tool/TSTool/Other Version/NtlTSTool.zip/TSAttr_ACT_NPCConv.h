#pragma once


#include "afxwin.h"
#include "TSAttr_Page.h"


// CTSAttr_ACT_NPCConv ��ȭ �����Դϴ�.

class CTSAttr_ACT_NPCConv : public CTSAttr_Page
{
	DECLARE_SERIAL(CTSAttr_ACT_NPCConv)

public:
	CTSAttr_ACT_NPCConv();
	virtual ~CTSAttr_ACT_NPCConv();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_TS_ACT_NPCCONV_ATTR_DIAG };

protected:
	virtual CString	CollectAttrDataFromDlgItems( void );
	virtual void	SettingAttrDataToDlgItems( CString& strKey, CString& strValue );

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.
	virtual BOOL OnInitDialog();

	DECLARE_MESSAGE_MAP()

public:
	DWORD m_taID;
	CComboBox m_ctrConvType;
	DWORD m_dwNPCIdx;
	DWORD m_uiConv;
};
