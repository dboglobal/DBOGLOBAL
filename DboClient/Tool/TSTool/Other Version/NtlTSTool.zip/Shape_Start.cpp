#include "stdafx.h"
#include "NtlTSTool.h"
#include "Shape_Start.h"


#include "TSProjectEntity.h"

#include "NtlTSToolDoc.h"
#include "MainFrm.h"
#include "TSProject.h"
#include "OptionListBox.h"
#include "TSAttr_Page_Mng.h"
#include "TSAttr_Page.h"


IMPLEMENT_SERIAL( CShape_Start, CTSShapeBox, 1 )


CShape_Start::CShape_Start( void )
{
}


CShape_Start::CShape_Start( const CPoint& ptPos, CTSGroup* pParent )
: CTSShapeBox( ptPos, pParent )
{
	// Name

	sSHAPE_NAME sName;	sName.strShapeType = _T("cont_start");
	SetShapeName( sName );

	// ID

	sSHAPE_ID sID; sID.strShapeID = _T("0");
	SetShapeID( sID );

	// Container attributes

	AddShapeAttr( _T("stdiag"), CString(_T("-1")) );

	// Linker 

	int nHeight = g_pTSTheme->GetLinkerRadius() + 20;
	AddLinker( eLINKER_TYPE_YES, nHeight );

	nHeight += g_pTSTheme->GetLinkerRadius() * 2 + 2;
	AddLinker( eLINKER_TYPE_NO, nHeight );

	// Group

	AddShapeGroup();
}


CShape_Start::~CShape_Start( void )
{
}


void CShape_Start::Serialize( CArchive &ar )
{
	CTSShapeBox::Serialize( ar );

	if ( ar.IsStoring() )
	{
		Save( ar );
	}
	else
	{
		// Name

		sSHAPE_NAME sName;	sName.strShapeType = _T("cont_start");
		SetShapeName( sName );

		// Linker 

		int nHeight = g_pTSTheme->GetLinkerRadius() + 20;
		AddLinker( eLINKER_TYPE_YES, nHeight );

		nHeight += g_pTSTheme->GetLinkerRadius() * 2 + 2;
		AddLinker( eLINKER_TYPE_NO, nHeight );

		switch ( m_pParent->GetParent()->GetParent()->GetProjectEntityVersion() )
		{
		case 0:
			if ( !Load_Trig_Ver_00000000( ar ) )
			{
				return;
			}
			break;

		case 1:
			if ( !Load_Trig_Ver_00000001( ar ) )
			{
				return;
			}
			break;

		default:
			ASSERT( !_T("The version of its project entity file is wrong.") );
			return;
		}
	}
}


void CShape_Start::ShowContainerEntityAttributeAddDlg( int nGroupID )
{
	if ( NULL == ((CNtlTSToolDoc*)((CMainFrame*)AfxGetMainWnd())->GetActiveDocument())->GetSelGroup() ) return;

	DWORD dwProjMode = ((CNtlTSToolDoc*)((CMainFrame*)AfxGetMainWnd())->GetActiveDocument())->GetTSProject()->GetProjectType();
	BYTE byGroupID = ((CNtlTSToolDoc*)((CMainFrame*)AfxGetMainWnd())->GetActiveDocument())->GetSelGroup()->GetGroupID();

	std::map<CTSAttr_Page*, CString> mapPageList;
	std::map<CTSAttr_Page*, CString>::iterator itPageList;

	if ( TS_TYPE_QUEST_CS == dwProjMode )
	{
		if ( eSEL_GROUP_TYPE_MAIN == byGroupID )
		{
			mapPageList[g_pTSConverter->GetAttrPage( _T("E_ColObject") )] = _T("E_ColObject");
			mapPageList[g_pTSConverter->GetAttrPage( _T("E_ClickObject") )] = _T("E_ClickObject");
			mapPageList[g_pTSConverter->GetAttrPage( _T("E_ClickNPC") )] = _T("E_ClickNPC");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_ClrQst") )] = _T("C_ClrQst");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_Item") )] = _T("C_Item");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_Lvl") )] = _T("C_Lvl");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_PCCls") )] = _T("C_PCCls");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_PCRace") )] = _T("C_PCRace");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_QItem") )] = _T("C_QItem");
//			mapPageList[g_pTSConverter->GetAttrPage( _T("C_SSM") )] = _T("C_SSM");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_SToCEvt") )] = _T("C_SToCEvt");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_WItem") )] = _T("C_WItem");
//			mapPageList[g_pTSConverter->GetAttrPage( _T("C_ObjItem") )] = _T("C_ObjItem");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_InNPC") )] = _T("C_InNPC");
		}
		else if( 255 != byGroupID )
		{
			mapPageList[g_pTSConverter->GetAttrPage( _T("E_ColObject") )] = _T("E_ColObject");
			mapPageList[g_pTSConverter->GetAttrPage( _T("E_ClickObject") )] = _T("E_ClickObject");
			mapPageList[g_pTSConverter->GetAttrPage( _T("E_ClickNPC") )] = _T("E_ClickNPC");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_ClrQst") )] = _T("C_ClrQst");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_Item") )] = _T("C_Item");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_Lvl") )] = _T("C_Lvl");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_PCCls") )] = _T("C_PCCls");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_PCRace") )] = _T("C_PCRace");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_QItem") )] = _T("C_QItem");
//			mapPageList[g_pTSConverter->GetAttrPage( _T("C_SSM") )] = _T("C_SSM");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_SToCEvt") )] = _T("C_SToCEvt");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_WItem") )] = _T("C_WItem");
//			mapPageList[g_pTSConverter->GetAttrPage( _T("C_ObjItem") )] = _T("C_ObjItem");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_InNPC") )] = _T("C_InNPC");
		}
	}
	else if ( TS_TYPE_PC_TRIGGER_CS == dwProjMode )
	{
		if ( eSEL_GROUP_TYPE_MAIN == byGroupID )
		{
			mapPageList[g_pTSConverter->GetAttrPage( _T("E_ColObject") )] = _T("E_ColObject");
			mapPageList[g_pTSConverter->GetAttrPage( _T("E_ClickObject") )] = _T("E_ClickObject");
			mapPageList[g_pTSConverter->GetAttrPage( _T("E_ClickNPC") )] = _T("E_ClickNPC");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_ClrQst") )] = _T("C_ClrQst");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_Item") )] = _T("C_Item");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_Lvl") )] = _T("C_Lvl");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_PCCls") )] = _T("C_PCCls");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_PCRace") )] = _T("C_PCRace");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_QItem") )] = _T("C_QItem");
//			mapPageList[g_pTSConverter->GetAttrPage( _T("C_SSM") )] = _T("C_SSM");
//			mapPageList[g_pTSConverter->GetAttrPage( _T("C_SToCEvt") )] = _T("C_SToCEvt");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_WItem") )] = _T("C_WItem");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_ObjItem") )] = _T("C_ObjItem");
//			mapPageList[g_pTSConverter->GetAttrPage( _T("C_InNPC") )] = _T("C_InNPC");
		}
		else
		{
			AfxMessageBox( _T("����� �� �ִ� ������ �����ϴ�") );
		}
	}
	else if ( TS_TYPE_OBJECT_TRIGGER_S == dwProjMode )
	{
		if ( eSEL_GROUP_TYPE_MAIN == byGroupID )
		{
			mapPageList[g_pTSConverter->GetAttrPage( _T("E_ColObject") )] = _T("E_ColObject");
			mapPageList[g_pTSConverter->GetAttrPage( _T("E_ClickObject") )] = _T("E_ClickObject");
//			mapPageList[g_pTSConverter->GetAttrPage( _T("E_ClickNPC") )] = _T("E_ClickNPC");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_ClrQst") )] = _T("C_ClrQst");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_Item") )] = _T("C_Item");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_Lvl") )] = _T("C_Lvl");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_PCCls") )] = _T("C_PCCls");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_PCRace") )] = _T("C_PCRace");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_QItem") )] = _T("C_QItem");
//			mapPageList[g_pTSConverter->GetAttrPage( _T("C_SSM") )] = _T("C_SSM");
//			mapPageList[g_pTSConverter->GetAttrPage( _T("C_SToCEvt") )] = _T("C_SToCEvt");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_WItem") )] = _T("C_WItem");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_ObjItem") )] = _T("C_ObjItem");
//			mapPageList[g_pTSConverter->GetAttrPage( _T("C_InNPC") )] = _T("C_InNPC");
		}
		else if ( 255 != byGroupID )
		{
//			mapPageList[g_pTSConverter->GetAttrPage( _T("E_ColObject") )] = _T("E_ColObject");
//			mapPageList[g_pTSConverter->GetAttrPage( _T("E_ClickObject") )] = _T("E_ClickObject");
//			mapPageList[g_pTSConverter->GetAttrPage( _T("E_ClickNPC") )] = _T("E_ClickNPC");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_ClrQst") )] = _T("C_ClrQst");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_Item") )] = _T("C_Item");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_Lvl") )] = _T("C_Lvl");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_PCCls") )] = _T("C_PCCls");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_PCRace") )] = _T("C_PCRace");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_QItem") )] = _T("C_QItem");
//			mapPageList[g_pTSConverter->GetAttrPage( _T("C_SSM") )] = _T("C_SSM");
//			mapPageList[g_pTSConverter->GetAttrPage( _T("C_SToCEvt") )] = _T("C_SToCEvt");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_WItem") )] = _T("C_WItem");
//			mapPageList[g_pTSConverter->GetAttrPage( _T("C_ObjItem") )] = _T("C_ObjItem");
//			mapPageList[g_pTSConverter->GetAttrPage( _T("C_InNPC") )] = _T("C_InNPC");
		}
	}

	if ( !mapPageList.empty() )
	{
		COptionListBox clListBox;
		CTSAttr_Page_Mng clDiag;
		clDiag.SetListControl( &clListBox );

		for ( itPageList = mapPageList.begin(); itPageList != mapPageList.end(); ++itPageList ) clDiag.AddTSAttrPage( itPageList->first );

		if ( IDOK == clDiag.DoModal() )
		{
			CTSAttr_Page* pEditedPage = clDiag.GetActivatedPage();

			itPageList = mapPageList.find( pEditedPage );
			if ( itPageList != mapPageList.end() )
			{
				AddShapeEntity( nGroupID, itPageList->second, pEditedPage->GetAllAttrData() );
			}

			UpdateHeightInfo();

			((CNtlTSToolDoc*)((CMainFrame*)AfxGetMainWnd())->GetActiveDocument())->OnShapeChange( this );
		}

		for ( itPageList = mapPageList.begin(); itPageList != mapPageList.end(); ++itPageList ) delete itPageList->first;
		mapPageList.clear();
	}
}


void CShape_Start::Save( CArchive& ar )
{
}


bool CShape_Start::Load_Trig_Ver_00000000( CArchive& ar )
{
	return true;
}


bool CShape_Start::Load_Trig_Ver_00000001( CArchive& ar )
{
	return true;
}
