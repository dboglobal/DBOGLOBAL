#include "stdafx.h"
#include "NtlTSTool.h"
#include "Shape_Switch.h"

#include "TSProjectEntity.h"

#include "NtlTSToolDoc.h"
#include "MainFrm.h"
#include "TSProject.h"
#include "OptionListBox.h"
#include "TSAttr_Page_Mng.h"
#include "TSAttr_Page.h"


IMPLEMENT_SERIAL( CShape_Switch, CTSShapeBox, 1 )


CShape_Switch::CShape_Switch( void )
{
}


CShape_Switch::CShape_Switch( const CPoint& ptPos, CTSGroup* pParent )
: CTSShapeBox( ptPos, pParent )
{
	// Name

	sSHAPE_NAME sName;	sName.strShapeType = _T("cont_switch");
	SetShapeName( sName );

	// Group

	AddShapeGroup();
}


CShape_Switch::~CShape_Switch( void )
{
}


CTSShapeBox::sSHAPE_GROUP* CShape_Switch::AddShapeGroup( int nIdx /*= -1*/ )
{
	sSHAPE_GROUP* pShapeGroup = CTSShapeBox::AddShapeGroup( nIdx );
	sBOX_LINKER_INFO* pLinkerInfo = AddLinker( eLINKER_TYPE_SWITCH, 0 );

	pShapeGroup->pLinkerInfo = pLinkerInfo;
	pLinkerInfo->pShapeGroup = pShapeGroup;

	return pShapeGroup;
}


void CShape_Switch::RemoveShapeGroup( sSHAPE_GROUP*& pGroup )
{
	if ( pGroup )
	{
		if ( pGroup->pLinkerInfo )
		{
			RemoveLinker( pGroup->pLinkerInfo );
		}

		CTSShapeBox::RemoveShapeGroup( pGroup );
	}
}


void CShape_Switch::ClearAllShapeGroup( bool bShapeChange /*= true*/ )
{
	CTSShapeBox::ClearAllShapeGroup( bShapeChange );
	ClearAllLinker( bShapeChange );
}


void CShape_Switch::Serialize( CArchive &ar )
{
	CTSShapeBox::Serialize( ar );

	if ( ar.IsStoring() )
	{
		Save( ar );
	}
	else
	{
		// Name

		sSHAPE_NAME sName;	sName.strShapeType = _T("cont_switch");
		SetShapeName( sName );

		switch ( m_pParent->GetParent()->GetParent()->GetProjectEntityVersion() )
		{
		case 0:
			if ( !Load_Trig_Ver_00000000( ar ) )
			{
				return;
			}
			break;

		case 1:
			if ( !Load_Trig_Ver_00000001( ar ) )
			{
				return;
			}
			break;

		default:
			ASSERT( !_T("The version of its project entity file is wrong.") );
			return;
		}
	}
}


void CShape_Switch::ShowContainerEntityAttributeAddDlg( int nGroupID )
{
	if ( NULL == ((CNtlTSToolDoc*)((CMainFrame*)AfxGetMainWnd())->GetActiveDocument())->GetSelGroup() ) return;

	DWORD dwProjMode = ((CNtlTSToolDoc*)((CMainFrame*)AfxGetMainWnd())->GetActiveDocument())->GetTSProject()->GetProjectType();
	BYTE byGroupID = ((CNtlTSToolDoc*)((CMainFrame*)AfxGetMainWnd())->GetActiveDocument())->GetSelGroup()->GetGroupID();

	std::map<CTSAttr_Page*, CString> mapPageList;
	std::map<CTSAttr_Page*, CString>::iterator itPageList;

	if ( TS_TYPE_QUEST_CS == dwProjMode )
	{
		if ( eSEL_GROUP_TYPE_MAIN == byGroupID )
		{
			mapPageList[g_pTSConverter->GetAttrPage( _T("E_ColObject") )] = _T("E_ColObject");
			mapPageList[g_pTSConverter->GetAttrPage( _T("E_ClickObject") )] = _T("E_ClickObject");
			mapPageList[g_pTSConverter->GetAttrPage( _T("E_ClickNPC") )] = _T("E_ClickNPC");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_ClrQst") )] = _T("C_ClrQst");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_Item") )] = _T("C_Item");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_Lvl") )] = _T("C_Lvl");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_PCCls") )] = _T("C_PCCls");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_PCRace") )] = _T("C_PCRace");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_QItem") )] = _T("C_QItem");
//			mapPageList[g_pTSConverter->GetAttrPage( _T("C_SSM") )] = _T("C_SSM");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_SToCEvt") )] = _T("C_SToCEvt");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_WItem") )] = _T("C_WItem");
//			mapPageList[g_pTSConverter->GetAttrPage( _T("C_ObjItem") )] = _T("C_ObjItem");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_InNPC") )] = _T("C_InNPC");
		}
		else if( 255 != byGroupID )
		{
//			mapPageList[g_pTSConverter->GetAttrPage( _T("E_ColObject") )] = _T("E_ColObject");
//			mapPageList[g_pTSConverter->GetAttrPage( _T("E_ClickObject") )] = _T("E_ClickObject");
//			mapPageList[g_pTSConverter->GetAttrPage( _T("E_ClickNPC") )] = _T("E_ClickNPC");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_ClrQst") )] = _T("C_ClrQst");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_Item") )] = _T("C_Item");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_Lvl") )] = _T("C_Lvl");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_PCCls") )] = _T("C_PCCls");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_PCRace") )] = _T("C_PCRace");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_QItem") )] = _T("C_QItem");
//			mapPageList[g_pTSConverter->GetAttrPage( _T("C_SSM") )] = _T("C_SSM");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_SToCEvt") )] = _T("C_SToCEvt");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_WItem") )] = _T("C_WItem");
//			mapPageList[g_pTSConverter->GetAttrPage( _T("C_ObjItem") )] = _T("C_ObjItem");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_InNPC") )] = _T("C_InNPC");
		}
	}
	else if ( TS_TYPE_PC_TRIGGER_CS == dwProjMode )
	{
		if ( eSEL_GROUP_TYPE_MAIN == byGroupID )
		{
			mapPageList[g_pTSConverter->GetAttrPage( _T("E_ColObject") )] = _T("E_ColObject");
			mapPageList[g_pTSConverter->GetAttrPage( _T("E_ClickObject") )] = _T("E_ClickObject");
			mapPageList[g_pTSConverter->GetAttrPage( _T("E_ClickNPC") )] = _T("E_ClickNPC");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_ClrQst") )] = _T("C_ClrQst");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_Item") )] = _T("C_Item");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_Lvl") )] = _T("C_Lvl");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_PCCls") )] = _T("C_PCCls");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_PCRace") )] = _T("C_PCRace");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_QItem") )] = _T("C_QItem");
//			mapPageList[g_pTSConverter->GetAttrPage( _T("C_SSM") )] = _T("C_SSM");
//			mapPageList[g_pTSConverter->GetAttrPage( _T("C_SToCEvt") )] = _T("C_SToCEvt");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_WItem") )] = _T("C_WItem");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_ObjItem") )] = _T("C_ObjItem");
//			mapPageList[g_pTSConverter->GetAttrPage( _T("C_InNPC") )] = _T("C_InNPC");
		}
		else
		{
			AfxMessageBox( _T("����� �� �ִ� ������ �����ϴ�") );
		}
	}
	else if ( TS_TYPE_OBJECT_TRIGGER_S == dwProjMode )
	{
		if ( eSEL_GROUP_TYPE_MAIN == byGroupID )
		{
			mapPageList[g_pTSConverter->GetAttrPage( _T("E_ColObject") )] = _T("E_ColObject");
			mapPageList[g_pTSConverter->GetAttrPage( _T("E_ClickObject") )] = _T("E_ClickObject");
//			mapPageList[g_pTSConverter->GetAttrPage( _T("E_ClickNPC") )] = _T("E_ClickNPC");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_ClrQst") )] = _T("C_ClrQst");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_Item") )] = _T("C_Item");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_Lvl") )] = _T("C_Lvl");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_PCCls") )] = _T("C_PCCls");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_PCRace") )] = _T("C_PCRace");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_QItem") )] = _T("C_QItem");
//			mapPageList[g_pTSConverter->GetAttrPage( _T("C_SSM") )] = _T("C_SSM");
//			mapPageList[g_pTSConverter->GetAttrPage( _T("C_SToCEvt") )] = _T("C_SToCEvt");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_WItem") )] = _T("C_WItem");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_ObjItem") )] = _T("C_ObjItem");
//			mapPageList[g_pTSConverter->GetAttrPage( _T("C_InNPC") )] = _T("C_InNPC");
		}
		else if ( 255 != byGroupID )
		{
//			mapPageList[g_pTSConverter->GetAttrPage( _T("E_ColObject") )] = _T("E_ColObject");
//			mapPageList[g_pTSConverter->GetAttrPage( _T("E_ClickObject") )] = _T("E_ClickObject");
//			mapPageList[g_pTSConverter->GetAttrPage( _T("E_ClickNPC") )] = _T("E_ClickNPC");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_ClrQst") )] = _T("C_ClrQst");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_Item") )] = _T("C_Item");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_Lvl") )] = _T("C_Lvl");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_PCCls") )] = _T("C_PCCls");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_PCRace") )] = _T("C_PCRace");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_QItem") )] = _T("C_QItem");
//			mapPageList[g_pTSConverter->GetAttrPage( _T("C_SSM") )] = _T("C_SSM");
//			mapPageList[g_pTSConverter->GetAttrPage( _T("C_SToCEvt") )] = _T("C_SToCEvt");
			mapPageList[g_pTSConverter->GetAttrPage( _T("C_WItem") )] = _T("C_WItem");
//			mapPageList[g_pTSConverter->GetAttrPage( _T("C_ObjItem") )] = _T("C_ObjItem");
//			mapPageList[g_pTSConverter->GetAttrPage( _T("C_InNPC") )] = _T("C_InNPC");
		}
	}

	if ( !mapPageList.empty() )
	{
		COptionListBox clListBox;
		CTSAttr_Page_Mng clDiag;
		clDiag.SetListControl( &clListBox );

		for ( itPageList = mapPageList.begin(); itPageList != mapPageList.end(); ++itPageList ) clDiag.AddTSAttrPage( itPageList->first );

		if ( IDOK == clDiag.DoModal() )
		{
			CTSAttr_Page* pEditedPage = clDiag.GetActivatedPage();

			itPageList = mapPageList.find( pEditedPage );
			if ( itPageList != mapPageList.end() )
			{
				AddShapeEntity( nGroupID, itPageList->second, pEditedPage->GetAllAttrData() );
			}

			UpdateHeightInfo();

			((CNtlTSToolDoc*)((CMainFrame*)AfxGetMainWnd())->GetActiveDocument())->OnShapeChange( this );
		}

		for ( itPageList = mapPageList.begin(); itPageList != mapPageList.end(); ++itPageList ) delete itPageList->first;
		mapPageList.clear();
	}
}


void CShape_Switch::Save( CArchive& ar )
{
}


bool CShape_Switch::Load_Trig_Ver_00000000( CArchive& ar )
{
	return true;
}


bool CShape_Switch::Load_Trig_Ver_00000001( CArchive& ar )
{
	return true;
}
