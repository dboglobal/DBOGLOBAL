#pragma once


#include "TSShapeBoxCtrl.h"


class CSCtrl_GCond : public CTSShapeBoxCtrl
{

	// Constructions and Destructions
public:

	CSCtrl_GCond( CNtlTSToolView* pParent );
	virtual ~CSCtrl_GCond( void );


	// Methods
public:

	virtual CTSShapeBox*				New( const CPoint& ptPos );
};
