#pragma once


#include "afxwin.h"
#include "TSAttr_Page.h"


// CTSAttr_ACT_QItem ��ȭ �����Դϴ�.

class CTSAttr_ACT_QItem : public CTSAttr_Page
{
	DECLARE_SERIAL(CTSAttr_ACT_QItem)

public:
	CTSAttr_ACT_QItem();
	virtual ~CTSAttr_ACT_QItem();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_TS_ACT_QITEM_ATTR_DIAG };

protected:
	virtual CString	CollectAttrDataFromDlgItems( void );
	virtual void	SettingAttrDataToDlgItems( CString& strKey, CString& strValue );

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.
	virtual BOOL OnInitDialog();

	DECLARE_MESSAGE_MAP()

public:
	DWORD m_taID;
	CButton m_ctrCreateBtn;
	CButton m_ctrDeleteBtn;

	DWORD m_dwItemIdx0;
	int m_nItemCnt0;

	DWORD m_dwItemIdx1;
	int m_nItemCnt1;

	DWORD m_dwItemIdx2;
	int m_nItemCnt2;

public:
	afx_msg void OnBnClickedTsActAttrQitemCreateCheck();
	afx_msg void OnBnClickedTsActAttrQitemDeleteCheck();
};
