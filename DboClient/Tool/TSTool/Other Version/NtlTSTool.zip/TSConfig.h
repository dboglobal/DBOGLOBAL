// TSConfig.h : interface of the CMainFrame class
//


#pragma once


class CTSConfig
{

// Member variables
public:

	static CString						s_strToolSkinStylePath;


// Constructions and Destruction
public:

	CTSConfig( void );
	~CTSConfig( void );


// Methods
public:

	static void							Create( void );
	static void							Delete( void );
};


extern CTSConfig* g_pTSConfig;