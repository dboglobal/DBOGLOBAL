// TSAttr_COND_QItem.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "NtlTSTool.h"
#include "TSAttr_COND_QItem.h"


// CTSAttr_COND_QItem ��ȭ �����Դϴ�.

IMPLEMENT_SERIAL(CTSAttr_COND_QItem, CTSAttr_Page, 1)

CTSAttr_COND_QItem::CTSAttr_COND_QItem()
	: CTSAttr_Page(CTSAttr_COND_QItem::IDD)
	, m_dwItemIdx(0xffffffff)
	, m_nItemCnt(0)
{

}

CTSAttr_COND_QItem::~CTSAttr_COND_QItem()
{
}

CString CTSAttr_COND_QItem::CollectAttrDataFromDlgItems( void )
{
	CTSAttr_Page::CollectAttrDataFromDlgItems();

	CString strData;

	strData += MakeAttrData( _T("iidx"), m_dwItemIdx );
	strData += MakeAttrData( _T("icnt"), m_nItemCnt );

	return strData;
}

void CTSAttr_COND_QItem::SettingAttrDataToDlgItems( CString& strKey, CString& strValue )
{
	if ( _T("iidx") == strKey )
	{
		m_dwItemIdx = atoi( strValue.GetBuffer() );
	}
	else if ( _T("icnt") == strKey )
	{
		m_nItemCnt = atoi( strValue.GetBuffer() );
	}
}

void CTSAttr_COND_QItem::DoDataExchange(CDataExchange* pDX)
{
	CTSAttr_Page::DoDataExchange(pDX);

	DDX_Text(pDX, IDC_TS_COND_ATTR_QITEM_ITEMIDX_EDITOR, m_dwItemIdx);
	DDX_Text(pDX, IDC_TS_COND_ATTR_QITEM_ITEMCNT_EDITOR, m_nItemCnt);
}


BEGIN_MESSAGE_MAP(CTSAttr_COND_QItem, CTSAttr_Page)
END_MESSAGE_MAP()


// CTSAttr_COND_QItem �޽��� ó�����Դϴ�.
