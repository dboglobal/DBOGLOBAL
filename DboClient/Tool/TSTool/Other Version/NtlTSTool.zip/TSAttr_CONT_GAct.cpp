// TSAttr_CONT_GAct.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "NtlTSTool.h"
#include "TSAttr_CONT_GAct.h"


// CTSAttr_CONT_GAct ��ȭ �����Դϴ�.

IMPLEMENT_SERIAL(CTSAttr_CONT_GAct, CTSAttr_Page, 1)

CTSAttr_CONT_GAct::CTSAttr_CONT_GAct()
	: CTSAttr_Page(CTSAttr_CONT_GAct::IDD)
	, m_tcID(NTL_TS_TC_ID_INVALID)
{
}

CTSAttr_CONT_GAct::~CTSAttr_CONT_GAct()
{
}

CString CTSAttr_CONT_GAct::CollectAttrDataFromDlgItems( void )
{
	CTSAttr_Page::CollectAttrDataFromDlgItems();

	CString strData;

	strData += MakeAttrData( _T("cid"), m_tcID );

	return strData;
}

void CTSAttr_CONT_GAct::SettingAttrDataToDlgItems( CString& strKey, CString& strValue )
{
	if ( _T("cid") == strKey )
	{
		m_tcID = atoi( strValue.GetBuffer() );
	}
}

void CTSAttr_CONT_GAct::DoDataExchange(CDataExchange* pDX)
{
	CTSAttr_Page::DoDataExchange(pDX);

	DDX_Text(pDX, IDC_TS_CONT_ATTR_GACT_ID_EDITOR, m_tcID);
	DDV_MinMaxUInt(pDX, m_tcID, 0, NTL_TS_TC_ID_INVALID);
}


BEGIN_MESSAGE_MAP(CTSAttr_CONT_GAct, CTSAttr_Page)
END_MESSAGE_MAP()


// CTSAttr_CONT_GAct �޽��� ó�����Դϴ�.
