#pragma once


#include "TSShape.h"


class CShape_Link : public CTSShape
{

	DECLARE_SERIAL( CShape_Link )


// Declarations
public:

	enum
	{
		NEW_NODE = 1024
	};

	enum eOLD_BRANCH_TYPE
	{
		eBRANCH_TYPE_DEFAULT,
		eBRANCH_TYPE_YES,
		eBRANCH_TYPE_NO,
		eBRANCH_TYPE_ERROR
	};

	class CAnchor
	{
	// Declarations
	public:

		enum eANCHOR_TYPE
		{
			eANCHOR_TYPE_SRC,
			eANCHOR_TYPE_DEST
		};


	// Member variables
	public:

		CShape_Link*					m_pParent;
		eANCHOR_TYPE					m_eAnchorType;

		CTSShape*						m_pShape;
		void*							m_pLinkerInfo;

		CPoint							m_ptPosition;

		double							m_dRx;
		double							m_dRy;


	// Methods
	public:

		void							MovePoint( const CPoint &ptPos );
		void							UpdatePoint( void );
	};

	typedef CArray< CPoint, CPoint > defNODE_LIST;
	typedef CArray< int, int > defSEG_TYPE_LIST;


// Member variables
protected:

	// Create

	bool								m_bCreated;

	// Origin

	CPoint								m_ptTempEnd;

	// Linker type

	eLINKER_TYPE						m_eLinkerType;

	// Name

	bool								m_bShowName;
	CString								m_strName;
	CSize								m_NameOffset;

	// Anchor

	CAnchor								m_srcAnchor;
	CAnchor								m_destAnchor;

	// Node

	defNODE_LIST						m_defNodeList;
	defSEG_TYPE_LIST					m_defSegTypeList;


// Constructions and Destructions
protected:

	CShape_Link( void );


public:

	CShape_Link( const CPoint& ptPos, CTSGroup* pParent, CTSShape* pSrcShape, eLINKER_TYPE eLinkerType, void* pLinkerInfo );

	~CShape_Link( void );


// Methods
public:

	bool								IsCreated( void ) const { return m_bCreated; }

	eLINKER_TYPE						GetLinkerType( void ) const { return m_eLinkerType; }

	bool								IsShowName( void ) const { return m_bShowName; }
	const CString&						GetName( void ) const { return m_strName; }
	void								SetName( const CString& strName ) { m_strName = strName; }
	CRect								GetNameRect( void ) const;

	const CAnchor&						GetSrcAnchor( void ) const { return m_srcAnchor; }
	const CAnchor&						GetDestAnchor( void ) const { return m_destAnchor; }

	virtual int							GetHandlerCount( void ) const;
	virtual HHANDLER					GetHandlerAt( const CPoint& ptPos ) const;
	virtual CPoint						GetHandlerPos( HHANDLER hHandler ) const;

	virtual bool						Intersects( const CRect& rect ) const;

	virtual void						Activate( const CPoint& ptPos, bool bLBtn );

	virtual void						Update( void );

	virtual void						DragTemp( const CPoint& ptPos );
	virtual void						Finish( const CPoint& ptPos, CTSShape* pShape );

	virtual void						BeginDrag( const CPoint& ptPos, HHANDLER hHandler = eHHANDLER_INVALID );
	virtual void						Drag( const CPoint& ptPos );
	virtual void						EndDrag( void );

	virtual void						RenderShape( CDC* pDC ) const;
	virtual void						RenderHandler( CDC* pDC ) const;
	void								RenderLinkTrace( CDC* pDC ) const;

	virtual void						Serialize( CArchive& ar );


// Implementations
protected:

	void								Save( CArchive& ar );

	bool								Load_Trig_Ver_00000000( CArchive& ar );
	bool								Load_Trig_Ver_00000001( CArchive& ar );

	virtual double						GetSegLength( int nIndex ) const;
	virtual double						GetSegAngle( int nIndex ) const;
	virtual bool						IntersectsSeg( const CRect& rect, int nIndex ) const;
	virtual int							BreakSeg( int nIndex, const CPoint& ptPos );
	virtual void						RemoveSeg( int nIndex );
	bool								OptimizeSeg( void );

	virtual CPoint						GetCenterPoint( void ) const;

	virtual void						SrcTransform( CPoint p[], int nCount ) const;
	virtual void						DestTransform( CPoint p[], int nCount ) const;

	void								ClearAll( void );


	bool								ConvertLinkerType( eOLD_BRANCH_TYPE eBranchType, CTSShape* pSrcShape, eLINKER_TYPE& eLinkerType, HLINKER& hLinker );

};
