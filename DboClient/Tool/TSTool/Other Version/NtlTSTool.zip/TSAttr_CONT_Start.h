#pragma once


#include "TSAttr_Page.h"


// CTSAttr_CONT_Start ��ȭ �����Դϴ�.

class CTSAttr_CONT_Start : public CTSAttr_Page
{
	DECLARE_SERIAL(CTSAttr_CONT_Start)

public:
	CTSAttr_CONT_Start();
	virtual ~CTSAttr_CONT_Start();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_TS_CONT_START_ATTR_DIAG };

	virtual CString	CollectAttrDataFromDlgItems( void );
	virtual void	SettingAttrDataToDlgItems( CString& strKey, CString& strValue );

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()

public:
	DWORD m_tcID;
	DWORD m_dwToolTip;
};
