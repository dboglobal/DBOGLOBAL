#include "stdafx.h"
#include "NtlTSTool.h"
#include "Shape_GAct.h"

#include "TSProjectEntity.h"

#include "NtlTSToolDoc.h"
#include "MainFrm.h"
#include "TSProject.h"
#include "OptionListBox.h"
#include "TSAttr_Page_Mng.h"
#include "TSAttr_Page.h"


IMPLEMENT_SERIAL( CShape_GAct, CTSShapeBox, 1 )


CShape_GAct::CShape_GAct( void )
{
}


CShape_GAct::CShape_GAct( const CPoint& ptPos, CTSGroup* pParent )
: CTSShapeBox( ptPos, pParent )
{
	// Name

	sSHAPE_NAME sName;	sName.strShapeType = _T("cont_gact");
	SetShapeName( sName );

	// Linker 

	int nHeight = g_pTSTheme->GetLinkerRadius() + 20;
	AddLinker( eLINKER_TYPE_NEXT, nHeight );

	nHeight += g_pTSTheme->GetLinkerRadius() * 2 + 2;
	AddLinker( eLINKER_TYPE_ERROR, nHeight );

	// Group

	AddShapeGroup();
}


CShape_GAct::~CShape_GAct( void )
{
}


void CShape_GAct::Serialize( CArchive &ar )
{
	CTSShapeBox::Serialize( ar );

	if ( ar.IsStoring() )
	{
		Save( ar );
	}
	else
	{
		// Name

		sSHAPE_NAME sName;	sName.strShapeType = _T("cont_gact");
		SetShapeName( sName );

		// Linker 

		int nHeight = g_pTSTheme->GetLinkerRadius() + 20;
		AddLinker( eLINKER_TYPE_NEXT, nHeight );

		nHeight += g_pTSTheme->GetLinkerRadius() * 2 + 2;
		AddLinker( eLINKER_TYPE_ERROR, nHeight );

		switch ( m_pParent->GetParent()->GetParent()->GetProjectEntityVersion() )
		{
		case 0:
			if ( !Load_Trig_Ver_00000000( ar ) )
			{
				return;
			}
			break;

		case 1:
			if ( !Load_Trig_Ver_00000001( ar ) )
			{
				return;
			}
			break;

		default:
			ASSERT( !_T("The version of its project entity file is wrong.") );
			return;
		}
	}
}


void CShape_GAct::ShowContainerEntityAttributeAddDlg( int nGroupID )
{
	if ( NULL == ((CNtlTSToolDoc*)((CMainFrame*)AfxGetMainWnd())->GetActiveDocument())->GetSelGroup() ) return;

	DWORD dwProjMode = ((CNtlTSToolDoc*)((CMainFrame*)AfxGetMainWnd())->GetActiveDocument())->GetTSProject()->GetProjectType();
	BYTE byGroupID = ((CNtlTSToolDoc*)((CMainFrame*)AfxGetMainWnd())->GetActiveDocument())->GetSelGroup()->GetGroupID();

	std::map<CTSAttr_Page*, CString> mapPageList;
	std::map<CTSAttr_Page*, CString>::iterator itPageList;

	if ( TS_TYPE_QUEST_CS == dwProjMode )
	{
		if ( eSEL_GROUP_TYPE_MAIN == byGroupID )
		{
//			mapPageList[g_pTSConverter->GetAttrPage( _T("A_Cine") )] = _T("A_Cine");
//			mapPageList[g_pTSConverter->GetAttrPage( _T("A_Dir") )] = _T("A_Dir");
			mapPageList[g_pTSConverter->GetAttrPage( _T("A_ETimerS") )] = _T("A_ETimerS");
			mapPageList[g_pTSConverter->GetAttrPage( _T("A_ETimerE") )] = _T("A_ETimerE");
//			mapPageList[g_pTSConverter->GetAttrPage( _T("A_InSSM") )] = _T("A_InSSM");
			mapPageList[g_pTSConverter->GetAttrPage( _T("A_Item") )] =	 _T("A_Item");
			mapPageList[g_pTSConverter->GetAttrPage( _T("A_NPCConv") )] = _T("A_NPCConv");
//			mapPageList[g_pTSConverter->GetAttrPage( _T("A_OPCam") )] = _T("A_OPCam");
			mapPageList[g_pTSConverter->GetAttrPage( _T("A_QItem") )] = _T("A_QItem");
			mapPageList[g_pTSConverter->GetAttrPage( _T("A_RegQInfo") )] = _T("A_RegQInfo");
			mapPageList[g_pTSConverter->GetAttrPage( _T("A_SToCEvt") )] = _T("A_SToCEvt");
			mapPageList[g_pTSConverter->GetAttrPage( _T("A_TWaitTS") )] = _T("A_TWaitTS");
			mapPageList[g_pTSConverter->GetAttrPage( _T("A_TSState") )] = _T("A_TSState");
//			mapPageList[g_pTSConverter->GetAttrPage( _T("A_Potal") )] = _T("A_Potal");
//			mapPageList[g_pTSConverter->GetAttrPage( _T("A_ObjState") )] = _T("A_ObjState");
//			mapPageList[g_pTSConverter->GetAttrPage( _T("A_ConcCheck") )] = _T("A_ConcCheck");
		}
		else if ( NTL_TS_EXCEPT_GIVEUP_ID == byGroupID )
		{
			mapPageList[g_pTSConverter->GetAttrPage( _T("A_QItem") )] = _T("A_QItem");
			mapPageList[g_pTSConverter->GetAttrPage( _T("A_Item") )] =	 _T("A_Item");
		}
		else if ( NTL_TS_EXCEPT_TLIMT_GROUP_ID_BEGIN <= byGroupID && byGroupID < NTL_TS_EXCEPT_TLIMT_GROUP_ID_END )
		{
			mapPageList[g_pTSConverter->GetAttrPage( _T("A_TSState") )] = _T("A_TSState");
		}
		else if ( NTL_TS_EXCEPT_SERVER_GROUP_ID_BEGIN <= byGroupID && byGroupID < NTL_TS_EXCEPT_SERVER_GROUP_ID_END )
		{
			mapPageList[g_pTSConverter->GetAttrPage( _T("A_TSState") )] = _T("A_TSState");
		}
		else if ( NTL_TS_EXCEPT_CLIENT_GROUP_ID_BEGIN <= byGroupID && byGroupID < NTL_TS_EXCEPT_CLIENT_GROUP_ID_END )
		{
			mapPageList[g_pTSConverter->GetAttrPage( _T("A_NPCConv") )] = _T("A_NPCConv");
		}
	}
	else if ( TS_TYPE_PC_TRIGGER_CS == dwProjMode )
	{
		if ( eSEL_GROUP_TYPE_MAIN == byGroupID )
		{
//			mapPageList[g_pTSConverter->GetAttrPage( _T("A_Cine") )] = _T("A_Cine");
//			mapPageList[g_pTSConverter->GetAttrPage( _T("A_Dir") )] = _T("A_Dir");
//			mapPageList[g_pTSConverter->GetAttrPage( _T("A_ETimerS") )] = _T("A_ETimerS");
//			mapPageList[g_pTSConverter->GetAttrPage( _T("A_ETimerE") )] = _T("A_ETimerE");
//			mapPageList[g_pTSConverter->GetAttrPage( _T("A_InSSM") )] = _T("A_InSSM");
//			mapPageList[g_pTSConverter->GetAttrPage( _T("A_Item") )] =	 _T("A_Item");
//			mapPageList[g_pTSConverter->GetAttrPage( _T("A_NPCConv") )] = _T("A_NPCConv");
//			mapPageList[g_pTSConverter->GetAttrPage( _T("A_OPCam") )] = _T("A_OPCam");
//			mapPageList[g_pTSConverter->GetAttrPage( _T("A_QItem") )] = _T("A_QItem");
//			mapPageList[g_pTSConverter->GetAttrPage( _T("A_RegQInfo") )] = _T("A_RegQInfo");
//			mapPageList[g_pTSConverter->GetAttrPage( _T("A_SToCEvt") )] = _T("A_SToCEvt");
//			mapPageList[g_pTSConverter->GetAttrPage( _T("A_TWaitTS") )] = _T("A_TWaitTS");
//			mapPageList[g_pTSConverter->GetAttrPage( _T("A_TSState") )] = _T("A_TSState");
			mapPageList[g_pTSConverter->GetAttrPage( _T("A_Potal") )] = _T("A_Potal");
//			mapPageList[g_pTSConverter->GetAttrPage( _T("A_ObjState") )] = _T("A_ObjState");
//			mapPageList[g_pTSConverter->GetAttrPage( _T("A_ConcCheck") )] = _T("A_ConcCheck");
		}
		else
		{
			AfxMessageBox( _T("����� �� �ִ� ������ �����ϴ�") );
		}
	}
	else if ( TS_TYPE_OBJECT_TRIGGER_S == dwProjMode )
	{
		if ( eSEL_GROUP_TYPE_MAIN == byGroupID )
		{
//			mapPageList[g_pTSConverter->GetAttrPage( _T("A_Cine") )] = _T("A_Cine");
//			mapPageList[g_pTSConverter->GetAttrPage( _T("A_Dir") )] = _T("A_Dir");
			mapPageList[g_pTSConverter->GetAttrPage( _T("A_ETimerS") )] = _T("A_ETimerS");
			mapPageList[g_pTSConverter->GetAttrPage( _T("A_ETimerE") )] = _T("A_ETimerE");
//			mapPageList[g_pTSConverter->GetAttrPage( _T("A_InSSM") )] = _T("A_InSSM");
			mapPageList[g_pTSConverter->GetAttrPage( _T("A_Item") )] =	 _T("A_Item");
//			mapPageList[g_pTSConverter->GetAttrPage( _T("A_NPCConv") )] = _T("A_NPCConv");
//			mapPageList[g_pTSConverter->GetAttrPage( _T("A_OPCam") )] = _T("A_OPCam");
			mapPageList[g_pTSConverter->GetAttrPage( _T("A_QItem") )] = _T("A_QItem");
//			mapPageList[g_pTSConverter->GetAttrPage( _T("A_RegQInfo") )] = _T("A_RegQInfo");
//			mapPageList[g_pTSConverter->GetAttrPage( _T("A_SToCEvt") )] = _T("A_SToCEvt");
			mapPageList[g_pTSConverter->GetAttrPage( _T("A_TWaitTS") )] = _T("A_TWaitTS");
//			mapPageList[g_pTSConverter->GetAttrPage( _T("A_TSState") )] = _T("A_TSState");
			mapPageList[g_pTSConverter->GetAttrPage( _T("A_Potal") )] = _T("A_Potal");
			mapPageList[g_pTSConverter->GetAttrPage( _T("A_ObjState") )] = _T("A_ObjState");
			mapPageList[g_pTSConverter->GetAttrPage( _T("A_ConcCheck") )] = _T("A_ConcCheck");
		}
		else if ( NTL_TS_EXCEPT_GIVEUP_ID == byGroupID )
		{
			mapPageList[g_pTSConverter->GetAttrPage( _T("A_QItem") )] = _T("A_QItem");
			mapPageList[g_pTSConverter->GetAttrPage( _T("A_Item") )] =	 _T("A_Item");
		}
		else if ( NTL_TS_EXCEPT_TLIMT_GROUP_ID_BEGIN <= byGroupID && byGroupID < NTL_TS_EXCEPT_TLIMT_GROUP_ID_END )
		{
			mapPageList[g_pTSConverter->GetAttrPage( _T("A_TSState") )] = _T("A_TSState");
		}
		else if ( NTL_TS_EXCEPT_SERVER_GROUP_ID_BEGIN <= byGroupID && byGroupID < NTL_TS_EXCEPT_SERVER_GROUP_ID_END )
		{
			mapPageList[g_pTSConverter->GetAttrPage( _T("A_TSState") )] = _T("A_TSState");
		}
		else
		{
			AfxMessageBox( _T("����� �� �ִ� ������ �����ϴ�") );
		}
	}

	if ( !mapPageList.empty() )
	{
		COptionListBox clListBox;
		CTSAttr_Page_Mng clDiag;
		clDiag.SetListControl( &clListBox );

		for ( itPageList = mapPageList.begin(); itPageList != mapPageList.end(); ++itPageList ) clDiag.AddTSAttrPage( itPageList->first );

		if ( IDOK == clDiag.DoModal() )
		{
			CTSAttr_Page* pEditedPage = clDiag.GetActivatedPage();

			itPageList = mapPageList.find( pEditedPage );
			if ( itPageList != mapPageList.end() )
			{
				AddShapeEntity( nGroupID, itPageList->second, pEditedPage->GetAllAttrData() );
			}

			UpdateHeightInfo();

			((CNtlTSToolDoc*)((CMainFrame*)AfxGetMainWnd())->GetActiveDocument())->OnShapeChange( this );
		}

		for ( itPageList = mapPageList.begin(); itPageList != mapPageList.end(); ++itPageList ) delete itPageList->first;
		mapPageList.clear();
	}
}


void CShape_GAct::Save( CArchive& ar )
{
}


bool CShape_GAct::Load_Trig_Ver_00000000( CArchive& ar )
{
	return true;
}


bool CShape_GAct::Load_Trig_Ver_00000001( CArchive& ar )
{
	return true;
}
