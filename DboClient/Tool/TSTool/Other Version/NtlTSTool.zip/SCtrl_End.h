#pragma once


#include "TSShapeBoxCtrl.h"


class CSCtrl_End : public CTSShapeBoxCtrl
{

// Constructions and Destructions
public:

	CSCtrl_End( CNtlTSToolView* pParent );
	virtual ~CSCtrl_End( void );


// Methods
public:

	virtual CTSShapeBox*				New( const CPoint& ptPos );
};
