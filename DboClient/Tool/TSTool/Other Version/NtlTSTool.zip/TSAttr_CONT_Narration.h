#pragma once


#include "TSAttr_Page.h"
#include "afxwin.h"


// CTSAttr_CONT_Narration ��ȭ �����Դϴ�.

class CTSAttr_CONT_Narration : public CTSAttr_Page
{
	DECLARE_SERIAL(CTSAttr_CONT_Narration)

public:
	CTSAttr_CONT_Narration();
	virtual ~CTSAttr_CONT_Narration();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_TS_CONT_NARRATION_ATTR_DIAG };

protected:
	virtual CString	CollectAttrDataFromDlgItems( void );
	virtual void	SettingAttrDataToDlgItems( CString& strKey, CString& strValue );

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.
	virtual BOOL OnInitDialog();

	DECLARE_MESSAGE_MAP()
public:
	DWORD m_tcID;
	CComboBox m_ctlProgState;
	CComboBox m_ctlOwnerType;
	DWORD m_dwOwnerIdx;
	CComboBox m_ctlOwnerState;
	CComboBox m_ctlDiaDirType;
	DWORD m_uiDialog;
	CComboBox m_ctlGUIType;
};
