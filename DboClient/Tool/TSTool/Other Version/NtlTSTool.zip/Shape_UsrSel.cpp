#include "stdafx.h"
#include "Shape_UsrSel.h"

#include "TSProjectEntity.h"


IMPLEMENT_SERIAL( CShape_UsrSel, CTSShapeBox, 1 )


CShape_UsrSel::CShape_UsrSel( void )
{
}


CShape_UsrSel::CShape_UsrSel( const CPoint& ptPos, CTSGroup* pParent )
: CTSShapeBox( ptPos, pParent )
{
	// Name

	sSHAPE_NAME sName;	sName.strShapeType = _T("cont_usrsel");
	SetShapeName( sName );

	// Container attributes

	AddShapeAttr( _T("desc"), CString(_T("-1")) );

	// Linker 

	int nHeight = g_pTSTheme->GetLinkerRadius() + 20;
	AddLinker( eLINKER_TYPE_BRANCH, nHeight );

	nHeight += g_pTSTheme->GetLinkerRadius() * 2 + 2;
	AddLinker( eLINKER_TYPE_CANCEL, nHeight );
}


CShape_UsrSel::~CShape_UsrSel( void )
{
}


void CShape_UsrSel::Serialize( CArchive &ar )
{
	CTSShapeBox::Serialize( ar );

	if ( ar.IsStoring() )
	{
		Save( ar );
	}
	else
	{
		// Name

		sSHAPE_NAME sName;	sName.strShapeType = _T("cont_usrsel");
		SetShapeName( sName );

		// Linker 

		int nHeight = g_pTSTheme->GetLinkerRadius() + 20;
		AddLinker( eLINKER_TYPE_BRANCH, nHeight );

		nHeight += g_pTSTheme->GetLinkerRadius() * 2 + 2;
		AddLinker( eLINKER_TYPE_CANCEL, nHeight );

		switch ( m_pParent->GetParent()->GetParent()->GetProjectEntityVersion() )
		{
		case 0:
			if ( !Load_Trig_Ver_00000000( ar ) )
			{
				return;
			}
			break;

		case 1:
			if ( !Load_Trig_Ver_00000001( ar ) )
			{
				return;
			}
			break;

		default:
			ASSERT( !_T("The version of its project entity file is wrong.") );
			return;
		}
	}
}


void CShape_UsrSel::ShowContainerEntityAttributeAddDlg( int nGroupID )
{
	AfxMessageBox( _T("����� �� �ִ� ������ �����ϴ�") );
}


void CShape_UsrSel::Save( CArchive& ar )
{
}


bool CShape_UsrSel::Load_Trig_Ver_00000000( CArchive& ar )
{
	return true;
}


bool CShape_UsrSel::Load_Trig_Ver_00000001( CArchive& ar )
{
	return true;
}
