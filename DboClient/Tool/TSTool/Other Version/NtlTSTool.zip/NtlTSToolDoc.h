// NtlTSToolDoc.h : interface of the CNtlTSToolDoc class
//


#pragma once


#include "TSShape.h"

class CTSProject;
class CTSProjectEntity;
class CTSGroup;


class CNtlTSToolDoc : public CDocument
{
protected: // create from serialization only
	CNtlTSToolDoc();
	DECLARE_DYNCREATE(CNtlTSToolDoc)

// Attributes
public:

// Operations
public:

// Overrides
protected:
	virtual BOOL OnNewDocument();
	virtual void DeleteContents();
	virtual void OnCloseDocument();

	virtual void Serialize(CArchive& ar);

// Implementation
public:
	virtual ~CNtlTSToolDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

	CTSProject* m_pTSProject;
	CTSProjectEntity* m_pTSProjectEntity;

	CTSGroup* m_pCurSelGroup;

	TSShapeList m_Selection;

public:

	bool	IsValidDocument( void ) const { return (NULL == m_pTSProject || NULL == m_pTSProjectEntity || NULL == m_pCurSelGroup) ? false : true; }

	CTSProject* GetTSProject( void ) const { return m_pTSProject; }

	CTSProjectEntity* GetTSProjectEntity( void ) const { return m_pTSProjectEntity; }

	CTSGroup* GetSelGroup( void ) const { return m_pCurSelGroup; }
	bool	SelMainGroup( void );
	bool	SelExceptGroup( BYTE byGroupID );
	void	UnselectGroup( void );

	TSShapeList& GetSelectShape( void );
	const TSShapeList& GetSelectShape( void ) const;
	bool	IsSelectShape( CTSShape* pShape );
	void	SelectShape( CTSShape* pShape, bool bAdd );
	void	SelectShape( const CRect& rtRgn, bool bAdd );
	void	UnselectShape( CTSShape* pShape = NULL );

	CTSShape*	GetShapeAt( const CPoint &ptPos ) const;
	void	GetShapesInRect( const CRect &rtRgn, TSShapeList& ShapeList ) const;

	bool	AddShape( CTSShape* pShape );
	void	RemoveShape( CTSShape* pShape );

	bool	GetShapeLinkInfoAt( const CPoint &ptPos, eLINKER_TYPE& eLinkerType, CTSShape*& pShape, void*& pLinkInfo ) const;
	void	OnDeleteShapeLink( CTSShape* pShape, void* pLinkInfo );

	void	OnShapeChange( CTSShape* pTSShape = NULL );

	void	RenderShapes( CDC* pDC );
	void	RenderLinkTrace( CDC* pDC );
	void	RenderSelectShapes( CDC* pDC );

	void	RaiseUpShapes( CTSShape* pShape );

public:

	bool	OnCreateProject( void );
	bool	OnOpenProject( void );
	void	OnCloseProject( void );

	bool	OnCreateProjectEntity( const CString& strFileName );
	bool	OnOpenProjectEntity( const CString& strEntityName );
	bool	OnDeleteProjectEntity( const CString& strEntityName );
	bool	OnClearProjectEntity( void );

	bool	OnCreateMainGroup( void );
	bool	OnCreateTimeLimitGroup( BYTE byGroupID );
	bool	OnCreateServerGroup( BYTE byGroupID );
	bool	OnCreateClientGroup( BYTE byGroupID );
	bool	OnCreateGiveUpGroup( BYTE byGroupID );
	bool	OnCreateExceptGroup( BYTE byGroupID );
	bool	OnDeleteSubGroup( BYTE byGroupID );

protected:

	void	Save( CArchive& ar );

	void	Load_Trig_Ver_00000000( CArchive& ar );

	bool	LoadProjectEntity( const CString& strFileName );

	void	UpdateLinks( void );


// Generated message map functions
protected:
	DECLARE_MESSAGE_MAP()

public:
};


inline TSShapeList& CNtlTSToolDoc::GetSelectShape( void )
{
	return m_Selection;
}

inline const TSShapeList& CNtlTSToolDoc::GetSelectShape( void ) const
{
	return m_Selection;
}
