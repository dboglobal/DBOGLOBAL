// TSAttr_CONT_UserSel.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "NtlTSTool.h"
#include "TSAttr_CONT_UserSel.h"


// CTSAttr_CONT_UserSel ��ȭ �����Դϴ�.

IMPLEMENT_SERIAL(CTSAttr_CONT_UserSel, CTSAttr_Page, 1)

CTSAttr_CONT_UserSel::CTSAttr_CONT_UserSel()
	: CTSAttr_Page(CTSAttr_CONT_UserSel::IDD)
	, m_tcID(NTL_TS_TC_ID_INVALID)
	, m_dwTitle(0xffffffff)
{

}

CTSAttr_CONT_UserSel::~CTSAttr_CONT_UserSel()
{
}

CString CTSAttr_CONT_UserSel::CollectAttrDataFromDlgItems( void )
{
	CTSAttr_Page::CollectAttrDataFromDlgItems();

	CString strData;

	strData += MakeAttrData( _T("cid"), m_tcID );
	strData += MakeAttrData( _T("desc"), m_dwTitle );

	return strData;
}

void CTSAttr_CONT_UserSel::SettingAttrDataToDlgItems( CString& strKey, CString& strValue )
{
	if ( _T("cid") == strKey )
	{
		m_tcID = atoi( strValue.GetBuffer() );
	}
	else if ( _T("desc") == strKey )
	{
		m_dwTitle = atoi( strValue.GetString() );
	}
}

void CTSAttr_CONT_UserSel::DoDataExchange(CDataExchange* pDX)
{
	CTSAttr_Page::DoDataExchange(pDX);

	DDX_Text(pDX, IDC_TS_CONT_ATTR_USRSEL_ID_EDITOR, m_tcID);
	DDV_MinMaxUInt(pDX, m_tcID, 0, NTL_TS_TC_ID_INVALID);
	DDX_Text(pDX, IDC_TS_CONT_ATTR_USRSELL_TITLE_EDITOR, m_dwTitle);
	DDV_MinMaxUInt(pDX, m_dwTitle, 0, 0xffffffff);
}


BEGIN_MESSAGE_MAP(CTSAttr_CONT_UserSel, CTSAttr_Page)
END_MESSAGE_MAP()


// CTSAttr_CONT_UserSel �޽��� ó�����Դϴ�.
