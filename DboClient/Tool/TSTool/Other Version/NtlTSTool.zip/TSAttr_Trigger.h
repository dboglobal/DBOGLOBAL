#pragma once


#include "TSAttr_Page.h"
#include "afxwin.h"


// CTSAttr_Trigger ��ȭ �����Դϴ�.

class CTSAttr_Trigger : public CTSAttr_Page
{
	DECLARE_SERIAL(CTSAttr_Trigger)

public:
	CTSAttr_Trigger();
	virtual ~CTSAttr_Trigger();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_TS_TRIGGER_ATTR_DIAG };

protected:
	virtual CString	CollectAttrDataFromDlgItems( void );
	virtual void	SettingAttrDataToDlgItems( CString& strKey, CString& strValue );

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.
	virtual BOOL OnInitDialog();

	DECLARE_MESSAGE_MAP()

public:
	DWORD m_tID;
	CButton m_ctrRepeat;
	CButton m_ctrCanShare;
	DWORD m_uiTitle;
};
