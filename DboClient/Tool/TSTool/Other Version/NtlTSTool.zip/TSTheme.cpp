#include "stdafx.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#endif


CTSTheme* g_pTSTheme = NULL;


CTSTheme::CTSTheme( void )
{
	// View

	m_fMinScale = 0.5;
	m_fNormalScale = 1.0;
	m_fMaxScale = 1.5;

	m_Extent = CSize( 3000, 3000 );

	m_ViewColor = RGB( 255, 255, 255 );

	// Grid

	m_GridSize = CSize( 10, 10 );


	// Handler

	m_nHandlerRadius = 4;


	// Linker

	m_nLinkerRadius = 8;

	m_cLinkerBGColor[eLINKER_TYPE_YES]			= RGB(0, 255, 0);
	m_cLinkerBGColor[eLINKER_TYPE_NO]			= RGB(255, 100, 0);
	m_cLinkerBGColor[eLINKER_TYPE_NEXT]			= RGB(200, 200, 200);
	m_cLinkerBGColor[eLINKER_TYPE_CANCEL]		= RGB(255, 0, 255);
	m_cLinkerBGColor[eLINKER_TYPE_ERROR]		= RGB(255, 0, 0);
	m_cLinkerBGColor[eLINKER_TYPE_BRANCH]		= RGB(0, 255, 255);
	m_cLinkerBGColor[eLINKER_TYPE_SWITCH]		= RGB(200, 200, 0);

	m_pLinkerStringFont = new CFont();
	m_pLinkerStringFont->CreateFont( 12,
		0,
		0,
		0,
		FW_BOLD,
		true,
		false,
		false,
		ANSI_CHARSET,
		OUT_DEFAULT_PRECIS,
		CLIP_DEFAULT_PRECIS,
		DEFAULT_QUALITY,
		DEFAULT_PITCH, _T("Arial") );

	m_cLinkerStringColor[eLINKER_TYPE_YES]		= RGB(0, 0, 0);
	m_cLinkerStringColor[eLINKER_TYPE_NO]		= RGB(0, 0, 0);
	m_cLinkerStringColor[eLINKER_TYPE_NEXT]		= RGB(0, 0, 0);
	m_cLinkerStringColor[eLINKER_TYPE_CANCEL]	= RGB(0, 0, 0);
	m_cLinkerStringColor[eLINKER_TYPE_ERROR]	= RGB(0, 0, 0);
	m_cLinkerStringColor[eLINKER_TYPE_BRANCH]	= RGB(0, 0, 0);
	m_cLinkerStringColor[eLINKER_TYPE_SWITCH]	= RGB(0, 0, 0);

	m_strLinkerString[eLINKER_TYPE_YES]			= _T("Y");
	m_strLinkerString[eLINKER_TYPE_NO]			= _T("N");
	m_strLinkerString[eLINKER_TYPE_NEXT]		= _T("F");
	m_strLinkerString[eLINKER_TYPE_CANCEL]		= _T("C");
	m_strLinkerString[eLINKER_TYPE_ERROR]		= _T("E");
	m_strLinkerString[eLINKER_TYPE_BRANCH]		= _T("B");
	m_strLinkerString[eLINKER_TYPE_SWITCH]		= _T("S");

	m_pShapeBoxNameFont = new CFont();
	m_pShapeBoxNameFont->CreateFont( 16,
		0,
		0,
		0,
		FW_BOLD,
		false,
		false,
		false,
		ANSI_CHARSET,
		OUT_DEFAULT_PRECIS,
		CLIP_DEFAULT_PRECIS,
		DEFAULT_QUALITY,
		DEFAULT_PITCH, _T("Arial") );

	m_caShapeBoxNameColor = RGB( 0, 0, 0 );

	m_pShapeBoxIDFont = new CFont();
	m_pShapeBoxIDFont->CreateFont( 16,
		0,
		0,
		0,
		FW_NORMAL,
		false,
		false,
		false,
		ANSI_CHARSET,
		OUT_DEFAULT_PRECIS,
		CLIP_DEFAULT_PRECIS,
		DEFAULT_QUALITY,
		DEFAULT_PITCH,
		_T("Arial") );

	m_cShapeBoxIDColor = RGB( 0, 0, 0 );

	m_pShapeBoxAttrNameFont = new CFont();
	m_pShapeBoxAttrNameFont->CreateFont( 14,
		0,
		0,
		0,
		FW_BOLD,
		false,
		false,
		false,
		ANSI_CHARSET,
		OUT_DEFAULT_PRECIS,
		CLIP_DEFAULT_PRECIS,
		DEFAULT_QUALITY,
		DEFAULT_PITCH,
		_T("Arial") );

	m_cShapeBoxAttrNameColor = RGB( 128, 128, 128 );

	m_pShapeBoxAttrFont = new CFont();
	m_pShapeBoxAttrFont->CreateFont( 16,
		0,
		0,
		0,
		FW_NORMAL,
		false,
		false,
		false,
		ANSI_CHARSET,
		OUT_DEFAULT_PRECIS,
		CLIP_DEFAULT_PRECIS,
		DEFAULT_QUALITY,
		DEFAULT_PITCH,
		_T("Arial") );

	m_cShapeBoxAttrColor = RGB( 0, 0, 0 );


	m_pShapeBoxEntityNameFont = new CFont();
	m_pShapeBoxEntityNameFont->CreateFont( 14,
		0,
		0,
		0,
		FW_BOLD,
		false,
		false,
		false,
		ANSI_CHARSET,
		OUT_DEFAULT_PRECIS,
		CLIP_DEFAULT_PRECIS,
		DEFAULT_QUALITY,
		DEFAULT_PITCH,
		_T("Arial") );

	m_cShapeBoxEntityNameColor = RGB( 128, 128, 128 );

	m_pShapeBoxEntityFont = new CFont();
	m_pShapeBoxEntityFont->CreateFont( 16,
		0,
		0,
		0,
		FW_NORMAL,
		false,
		false,
		false,
		ANSI_CHARSET,
		OUT_DEFAULT_PRECIS,
		CLIP_DEFAULT_PRECIS,
		DEFAULT_QUALITY,
		DEFAULT_PITCH,
		_T("Arial") );

	m_cShapeBoxEntityColor = RGB( 0, 0, 0 );

	// Shape box

	m_nShapeBoxNameHeight = 22;

	m_nShapeBoxIDHeight = 22;

	m_nShapeBoxAttrNameHeight = 22;
	m_nShapeBoxAttrHeight = 22;
	m_nShapeBoxAttrNewHeight = 10;

	m_nShapeBoxEntityNameHeight = 22;
	m_nShapeBoxEntityHeight = 22;
	m_nShapeBoxEntityNewHeight = 10;

	m_cShapeBoxShadowColor = RGB( 100, 100, 100 );
	m_cShapeBoxShadowFillColor = RGB( 100, 100, 100 );

	m_cShapeBoxOutlineColor = RGB( 0, 0, 0 );
	m_cShapeBoxOutlineFillColor = RGB( 248, 254, 192 );

	// Link

	m_LinkerLineStyle[eLINKER_TYPE_YES]		= PS_SOLID;
	m_LinkerLineStyle[eLINKER_TYPE_NO]		= PS_SOLID;
	m_LinkerLineStyle[eLINKER_TYPE_NEXT]	= PS_SOLID;
	m_LinkerLineStyle[eLINKER_TYPE_CANCEL]	= PS_SOLID;
	m_LinkerLineStyle[eLINKER_TYPE_ERROR]	= PS_SOLID;
	m_LinkerLineStyle[eLINKER_TYPE_BRANCH]	= PS_SOLID;
	m_LinkerLineStyle[eLINKER_TYPE_SWITCH]	= PS_SOLID;

	m_LinkerLineColor[eLINKER_TYPE_YES]		= RGB(0, 255, 0);
	m_LinkerLineColor[eLINKER_TYPE_NO]		= RGB(255, 100, 0);
	m_LinkerLineColor[eLINKER_TYPE_NEXT]	= RGB(200, 200, 200);
	m_LinkerLineColor[eLINKER_TYPE_CANCEL]	= RGB(255, 0, 255);
	m_LinkerLineColor[eLINKER_TYPE_ERROR]	= RGB(255, 0, 0);
	m_LinkerLineColor[eLINKER_TYPE_BRANCH]	= RGB(0, 255, 255);
	m_LinkerLineColor[eLINKER_TYPE_SWITCH]	= RGB(200, 200, 0);

	m_pLinkerNameFont = new CFont();
	m_pLinkerNameFont->CreateFont( 16,
		0,
		0,
		0,
		FW_NORMAL,
		false,
		false,
		false,
		ANSI_CHARSET,
		OUT_DEFAULT_PRECIS,
		CLIP_DEFAULT_PRECIS,
		DEFAULT_QUALITY,
		DEFAULT_PITCH,
		_T("Arial") );
}


CTSTheme::~CTSTheme()
{
	delete m_pLinkerStringFont;
	delete m_pShapeBoxNameFont;
	delete m_pShapeBoxIDFont;
	delete m_pShapeBoxAttrNameFont;
	delete m_pShapeBoxAttrFont;
	delete m_pShapeBoxEntityNameFont;
	delete m_pShapeBoxEntityFont;
	delete m_pLinkerNameFont;
}


void CTSTheme::Create( void )
{
	ASSERT( NULL == g_pTSTheme );
	g_pTSTheme = new CTSTheme;
}


void CTSTheme::Delete( void )
{
	if ( g_pTSTheme )
	{
		delete g_pTSTheme;
		g_pTSTheme = NULL;
	}
}
