#include "StdAfx.h"
#include "NtlTSTool.h"
#include "Shape_Link.h"

#include "MainFrm.h"
#include "NtlTSToolDoc.h"

#include "TSProjectEntity.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#endif


IMPLEMENT_SERIAL( CShape_Link, CTSShape, 1 )


void s_CalcSafeBox( const CPoint& p1, const CPoint& p2, int nWidth, CPoint* p )
{
	double dx = p1.x - p2.x;
	double dy = p1.y - p2.y;
	double diag = ::sqrt( dx * dx + dy * dy );

	int ox = 0;
	int oy = 0;

	if ( 0 != diag )
	{
		double rx = dx / diag;
		double ry = dy / diag;
		ox = (int)(nWidth * ry);
		oy = (int)(nWidth * rx);
	}

	p[0] = p1 + CSize(-ox, oy);
	p[1] = p1 + CSize(ox, -oy);
	p[2] = p2 + CSize(ox, -oy);
	p[3] = p2 + CSize(-ox, oy);
}


void s_Transform( CPoint p[], int nCount, const CPoint& A, const CPoint& B, const CRect& R )
{
	double dx = B.x - A.x;
	double dy = B.y - A.y;
	double dLength = ::sqrt( dx * dx + dy * dy );

	if ( 0 == dLength )
	{
		for ( int i = 0; i < nCount; ++i ) p[i] = CPoint( 0, 0 );
		return;
	}

	double rx = dx / dLength;
	double ry = dy / dLength;

	double ox = dx > 0 ? R.right - A.x : R.left - A.x;
	double oy = ox * (dy / dx);

	if ( A.y + oy > R.bottom || A.y + oy < R.top )
	{
		oy = dy > 0 ? R.bottom - A.y : R.top - A.y;
		ox = oy * (dx / dy);
	}

	CPoint O( (int)(A.x + ox), (int)(A.y + oy) );

	for ( int i = 0; i < nCount; ++i )
	{
		double ax = p[i].x;
		double ay = p[i].y;
		p[i].x = O.x + (int)(rx * ax - ry * ay);
		p[i].y = O.y + (int)(ry * ax + rx * ay);
	}
}


void CShape_Link::CAnchor::MovePoint( const CPoint &ptPos )
{
	m_dRx = (ptPos.x - m_pShape->GetBoundBox().left) / (double)m_pShape->GetBoundBox().Width();
	m_dRy = (ptPos.y - m_pShape->GetBoundBox().top) / (double)m_pShape->GetBoundBox().Height();

	if ( m_dRx < 0 )	m_dRx = 0;
	if ( m_dRx > 1 )	m_dRx = 1;
	if ( m_dRy < 0 )	m_dRy = 0;
	if ( m_dRy > 1 )	m_dRy = 1;

	UpdatePoint();
}


void CShape_Link::CAnchor::UpdatePoint( void )
{
	ASSERT( m_dRx >= 0 && m_dRx <= 1 );
	ASSERT( m_dRy >= 0 && m_dRy <= 1 );

	if ( eANCHOR_TYPE_SRC == m_eAnchorType )
	{
		ASSERT( m_pLinkerInfo );

		if ( m_pLinkerInfo )
		{
			m_ptPosition = m_pShape->GetLinkerPosFromLinkerInfo( m_pLinkerInfo );
		}
	}
	else
	{
		CRect rt = m_pShape->GetBoundBox();

		m_ptPosition.x = (int)( rt.left + rt.Width() * m_dRx );
		m_ptPosition.y = (int)( rt.top + rt.Height() * m_dRy );
	}
}


CShape_Link::CShape_Link( void )
{
	m_srcAnchor.m_pParent = this;
	m_srcAnchor.m_eAnchorType = CAnchor::eANCHOR_TYPE_SRC;
	m_srcAnchor.m_pShape = NULL;
	m_srcAnchor.m_pLinkerInfo = NULL;

	m_destAnchor.m_pParent = this;
	m_destAnchor.m_eAnchorType = CAnchor::eANCHOR_TYPE_DEST;
	m_destAnchor.m_pShape = NULL;
	m_srcAnchor.m_pLinkerInfo = NULL;
}


CShape_Link::CShape_Link( const CPoint& ptPos, CTSGroup* pParent, CTSShape* pShape, eLINKER_TYPE eLinkerType, void* pLinkerInfo )
: CTSShape( pParent )
{
	m_bCreated = false;

	m_ptOrigin = ptPos;
	m_ptTempEnd = ptPos;

	m_eLinkerType = eLinkerType;

	m_bShowName = false;
	m_strName = CString( _T("") );
	m_NameOffset = CSize( 0, 10 );

	if ( eLINKER_TYPE_BRANCH == m_eLinkerType )
	{
		m_strName = _T("-1");
	}

	m_srcAnchor.m_pParent = this;
	m_srcAnchor.m_eAnchorType = CAnchor::eANCHOR_TYPE_SRC;
	m_srcAnchor.m_pShape = pShape;
	m_srcAnchor.m_pLinkerInfo = pLinkerInfo;
	m_srcAnchor.MovePoint( ptPos );

	m_destAnchor.m_pParent = this;
	m_destAnchor.m_eAnchorType = CAnchor::eANCHOR_TYPE_DEST;
	m_destAnchor.m_pShape = NULL;
	m_destAnchor.m_pLinkerInfo = NULL;
}


CShape_Link::~CShape_Link( void )
{
}


CRect CShape_Link::GetNameRect( void ) const
{
	ASSERT( m_bCreated );

	CRect rt( GetCenterPoint() + m_NameOffset, CSize(0, 0) );
	rt.InflateRect( 100, 8 );
	return rt;
}


int CShape_Link::GetHandlerCount( void ) const
{
	return 2 + (int)m_defNodeList.GetCount();
}


HHANDLER CShape_Link::GetHandlerAt( const CPoint& ptPos ) const
{
	HHANDLER hHandler = CTSShape::GetHandlerAt( ptPos );

	return hHandler != eHHANDLER_INVALID ? hHandler : (CTSShape::Intersects( ptPos ) ? NEW_NODE : eHHANDLER_INVALID );
}


CPoint CShape_Link::GetHandlerPos( HHANDLER hHandler ) const
{
	ASSERT( hHandler >= 0 && hHandler < GetHandlerCount() );

	switch ( hHandler )
	{
	case 0:
		return m_srcAnchor.m_ptPosition;

	case 1:
		return m_destAnchor.m_ptPosition;

	default:
		return m_defNodeList[hHandler - 2];
	}

	return CPoint();
}


bool CShape_Link::Intersects( const CRect& rect ) const
{
	// Name

	if ( m_bShowName &&
		 0 != (int)m_strName.GetLength() &&
		 GetNameRect().PtInRect( rect.TopLeft() ) )
	{
		return true;
	}

	// Segment

	for ( int i = 0; i <= (int)m_defNodeList.GetCount(); ++i )
	{
		if ( IntersectsSeg( rect, i ) )
		{
			return true;
		}
	}

	return false;
}


void CShape_Link::Activate( const CPoint& ptPos, bool bLBtn )
{
	if ( m_bShowName && GetNameRect().PtInRect( ptPos ) )
	{
	}
}


void CShape_Link::Update( void )
{
	if ( m_bCreated )
	{
		CPoint ptOldSrcPoint = m_srcAnchor.m_ptPosition;
		CPoint ptOldDestPoint = m_destAnchor.m_ptPosition;

		m_srcAnchor.UpdatePoint();
		m_destAnchor.UpdatePoint();

		CSize srcDelta = m_srcAnchor.m_ptPosition - ptOldSrcPoint;
		CSize destDelta = m_destAnchor.m_ptPosition - ptOldDestPoint;

		int i = 0;
		for( ; i < (int)m_defNodeList.GetCount() / 2; ++i )	m_defNodeList[i] += srcDelta;
		for( ; i < (int)m_defNodeList.GetCount(); ++i )		m_defNodeList[i] += destDelta;

		if ( m_srcAnchor.m_pShape->IsZombie() || m_destAnchor.m_pShape->IsZombie() )
		{
			MakeZombie();
		}
	}
}


void CShape_Link::DragTemp( const CPoint& ptPos )
{
	ASSERT( !m_bCreated );

	m_ptTempEnd = ptPos;
}


void CShape_Link::Finish( const CPoint& ptPos, CTSShape* pShape )
{
	ASSERT( !m_bCreated );

	m_bCreated = true;

	m_bShowName = true;

	m_destAnchor.m_pShape = pShape;
	m_destAnchor.MovePoint( ptPos );

	if ( m_srcAnchor.m_pShape == m_destAnchor.m_pShape )
	{
		BreakSeg( 0, CPoint(m_srcAnchor.m_ptPosition.x - 30, m_srcAnchor.m_pShape->GetBoundBox().top - 40) );
		BreakSeg( 1, CPoint(m_srcAnchor.m_ptPosition.x + 0, m_srcAnchor.m_pShape->GetBoundBox().top - 40) );
	}
}


void CShape_Link::BeginDrag( const CPoint& ptPos, HHANDLER hHandler /*= eHHANDLER_INVALID*/ )
{
	CTSShape::BeginDrag( ptPos, hHandler );

	if ( NEW_NODE == hHandler )
	{
		int i;
		CRect rt( ptPos, CSize(0, 0) );
		rt.InflateRect( 1, 1 );

		// Name

		if ( m_bShowName && GetNameRect().PtInRect( ptPos ) )
		{
			m_hDragHandler = eHHANDLER_DRAG_TEXT_HANDLE;
			return;
		}

		// Segment

		for ( i = 0; i <= (int)m_defNodeList.GetCount(); ++i )
		{
			if ( IntersectsSeg( rt, i ) )
			{
				break;
			}
		}

		m_hDragHandler = BreakSeg( i, ptPos );
	}
}


void CShape_Link::Drag( const CPoint& ptPos )
{
	// Name

	if ( eHHANDLER_DRAG_TEXT_HANDLE == m_hDragHandler )
	{
		CSize delta = ptPos - m_ptLastPoint;
		m_NameOffset += delta;
		m_ptLastPoint = ptPos;

		return;
	}

	// Segment

	if ( 0 == m_hDragHandler )
	{
		m_srcAnchor.MovePoint( ptPos );
	}
	else if ( 1 == m_hDragHandler )
	{
		m_destAnchor.MovePoint( ptPos );
	}
	else if ( 1 < m_hDragHandler )
	{
		m_defNodeList[m_hDragHandler - 2] = ptPos;
	}

	CTSShape::Drag( ptPos );
}

void CShape_Link::EndDrag( void )
{
	CTSShape::EndDrag();

	OptimizeSeg();
}


void CShape_Link::RenderShape( CDC* pDC ) const
{
	CTSShape::RenderShape( pDC );

	int nStyle = g_pTSTheme->GetLinkerLineStyle( m_eLinkerType );
	COLORREF cColor = g_pTSTheme->GetLinkerLineColor( m_eLinkerType );
	CFont* pNameFont = g_pTSTheme->GetLinkerNameFont();

	if ( m_bCreated )
	{
		CPen pen( nStyle, 2, cColor );
		CPen* pOldPen = pDC->SelectObject( &pen );

		// Shape

		pDC->MoveTo( m_srcAnchor.m_ptPosition );

		for ( int i = 0; i < (int)m_defNodeList.GetCount(); ++i )
		{
			pDC->LineTo( m_defNodeList[i] );
		}

		pDC->LineTo( m_destAnchor.m_ptPosition );

		// Arrow

		CPoint p[] = { CPoint(16, 8), CPoint(0, 0), CPoint(16, -8), };

		{
			DestTransform( p, 3 );

			CPen pen( PS_SOLID, 2, cColor );
			CPen* pOldPen = pDC->SelectObject( &pen );
			pDC->Polyline( p, 3 );
			pDC->SelectObject( pOldPen );
		}

		// Name

		if ( m_bShowName && 0 != (int)m_strName.GetLength() )
		{
			CFont* pOldFont = pDC->SelectObject( pNameFont );
			pDC->SetTextColor( cColor );
			pDC->SetBkMode( TRANSPARENT );

			pDC->DrawText( m_strName, GetNameRect(), DT_CENTER|DT_SINGLELINE|DT_VCENTER|DT_END_ELLIPSIS|DT_NOPREFIX );

			pDC->SelectObject( pOldFont );
		}

		pDC->SelectObject( pOldPen );
	}
}


void CShape_Link::RenderHandler( CDC* pDC ) const
{
	int nHandleSize = g_pTSTheme->GetHandlerRadius();
	int nStyle = g_pTSTheme->GetLinkerLineStyle( m_eLinkerType );
	COLORREF cColor = g_pTSTheme->GetLinkerLineColor( m_eLinkerType );
	CFont* pNameFont = g_pTSTheme->GetLinkerNameFont();

	CPen pen( PS_DOT, 3, cColor ), *pOldPen;
	CPen handlePen( PS_SOLID, 3, RGB(100, 100, 255) );
	CBrush* pOldBrush;

	pOldPen = pDC->SelectObject( &pen );
	pOldBrush = (CBrush*)pDC->SelectStockObject( NULL_BRUSH );
	pDC->SetBkMode( TRANSPARENT );

	if ( m_bCreated )
	{
		int i;
		CRect rt;

		pDC->MoveTo( m_srcAnchor.m_ptPosition );
		for ( i = 0; i < (int)m_defNodeList.GetCount(); ++i )
		{
			pDC->LineTo( m_defNodeList[i] );
		}
		pDC->LineTo( m_destAnchor.m_ptPosition );

		pDC->SelectObject( &handlePen );

		rt = CRect( m_srcAnchor.m_ptPosition, CSize(0, 0) );
		rt.InflateRect( nHandleSize, nHandleSize );
		pDC->Rectangle( rt );

		rt = CRect( m_destAnchor.m_ptPosition, CSize(0, 0) );
		rt.InflateRect( nHandleSize, nHandleSize );
		pDC->Rectangle( rt );

		for ( i = 0; i < (int)m_defNodeList.GetCount(); ++i )
		{
			rt = CRect( m_defNodeList[i], CSize(0, 0) );
			rt.InflateRect( nHandleSize, nHandleSize );
			pDC->Ellipse( rt );
		}

		if ( m_bShowName && 0 != (int)m_strName.GetLength() )
		{
			CRect rtSelBox = GetNameRect();
			CBrush rectBrush( RGB(100, 100, 255) );
			CBrush* pOldBrush = pDC->SelectObject( &rectBrush );
			pDC->FrameRect( rtSelBox, &rectBrush );
			pDC->SelectObject( pOldBrush );
		}
	}
	else
	{
		pDC->MoveTo( m_srcAnchor.m_ptPosition );
		pDC->LineTo( m_ptTempEnd );
	}

	pDC->SelectObject( pOldPen );
	pDC->SelectObject( pOldBrush );
}


void CShape_Link::RenderLinkTrace( CDC* pDC ) const
{
	COLORREF cColor = g_pTSTheme->GetLinkerLineColor( m_eLinkerType );

	CPen pen( PS_DOT, 1, cColor ), *pOldPen;
	CBrush* pOldBrush;

	pOldPen = pDC->SelectObject( &pen );
	pOldBrush = (CBrush*)pDC->SelectStockObject( NULL_BRUSH );
	pDC->SetBkMode( TRANSPARENT );

	if ( m_bCreated )
	{
		int i;
		CRect rt;

		pDC->MoveTo( m_srcAnchor.m_ptPosition );
		for ( i = 0; i < (int)m_defNodeList.GetCount(); ++i )
		{
			pDC->LineTo( m_defNodeList[i] );
		}
		pDC->LineTo( m_destAnchor.m_ptPosition );
	}
	else
	{
		pDC->MoveTo( m_srcAnchor.m_ptPosition );
		pDC->LineTo( m_ptTempEnd );
	}

	pDC->SelectObject( pOldPen );
	pDC->SelectObject( pOldBrush );
}


void CShape_Link::Serialize( CArchive& ar )
{
	CTSShape::Serialize( ar );

	if ( ar.IsStoring() )
	{
		Save( ar );
	}
	else
	{
		ClearAll();

		switch ( m_pParent->GetParent()->GetParent()->GetProjectEntityVersion() )
		{
		case 0:
			if ( !Load_Trig_Ver_00000000( ar ) )
			{
				return;
			}
			break;

		case 1:
			if ( !Load_Trig_Ver_00000001( ar ) )
			{
				return;
			}
			break;

		default:
			ASSERT( !_T("The version of its project entity file is wrong.") );
			return;
		}
	}
}


void CShape_Link::Save( CArchive& ar )
{
	ar << m_eLinkerType;

	ar << (int)m_bShowName;
	ar << m_strName;
	ar << m_NameOffset;

	ar << m_srcAnchor.m_pShape;
	ar << m_srcAnchor.m_ptPosition;
	ar << m_srcAnchor.m_dRx;
	ar << m_srcAnchor.m_dRy;

	ar << m_destAnchor.m_pShape;
	ar << m_destAnchor.m_ptPosition;
	ar << m_destAnchor.m_dRx;
	ar << m_destAnchor.m_dRy;

	m_defNodeList.Serialize( ar );
	m_defSegTypeList.Serialize( ar );
}


bool CShape_Link::Load_Trig_Ver_00000000( CArchive& ar )
{
	int nFlag;

	ar >> m_srcAnchor.m_pShape;
	ar >> m_srcAnchor.m_dRx;
	ar >> m_srcAnchor.m_dRy;

	ar >> m_destAnchor.m_pShape;
	ar >> m_destAnchor.m_dRx;
	ar >> m_destAnchor.m_dRy;

	ar >> m_strName;
	ar >> m_NameOffset;
	ar >> nFlag; m_bShowName = nFlag ? true : false;

	ar >> nFlag;

	eLINKER_TYPE eLinkerType;
	HLINKER hLinker;
	if ( !ConvertLinkerType( (eOLD_BRANCH_TYPE)nFlag, m_srcAnchor.m_pShape, eLinkerType, hLinker ) )
	{
		ASSERT( !_T("Failed convert linker type.") );
	}

	m_srcAnchor.m_pLinkerInfo = m_srcAnchor.m_pShape->GetLinkerInfo( hLinker );
	ASSERT( m_srcAnchor.m_pLinkerInfo );

	m_eLinkerType = eLinkerType;

	m_srcAnchor.UpdatePoint();
	m_destAnchor.UpdatePoint();

	m_defNodeList.Serialize( ar );
	m_defSegTypeList.Serialize( ar );

	m_bCreated = true;

	return true;
}


bool CShape_Link::Load_Trig_Ver_00000001( CArchive& ar )
{
	int nFlag;

	ar >> nFlag;
	m_eLinkerType = (eLINKER_TYPE)nFlag;

	ar >> nFlag; m_bShowName = nFlag ? true : false;
	ar >> m_strName;
	ar >> m_NameOffset;

	ar >> m_srcAnchor.m_pShape;
	ar >> m_srcAnchor.m_ptPosition;
	ar >> m_srcAnchor.m_dRx;
	ar >> m_srcAnchor.m_dRy;

	HLINKER hLinker = m_srcAnchor.m_pShape->GetLinkerAt( m_srcAnchor.m_ptPosition );
	m_srcAnchor.m_pLinkerInfo = m_srcAnchor.m_pShape->GetLinkerInfo( hLinker );
	ASSERT( m_srcAnchor.m_pLinkerInfo );

	ar >> m_destAnchor.m_pShape;
	ar >> m_destAnchor.m_ptPosition;
	ar >> m_destAnchor.m_dRx;
	ar >> m_destAnchor.m_dRy;

	m_srcAnchor.UpdatePoint();
	m_destAnchor.UpdatePoint();

	m_defNodeList.Serialize( ar );
	m_defSegTypeList.Serialize( ar );

	m_bCreated = true;

	return true;
}


double CShape_Link::GetSegLength( int nIndex ) const
{
	ASSERT( nIndex >= 0 && nIndex <= (int)m_defNodeList.GetCount() );

	CPoint p1 = nIndex == 0 ? m_srcAnchor.m_ptPosition : m_defNodeList[nIndex - 1];
	CPoint p2 = nIndex == (int)m_defNodeList.GetCount() ? m_destAnchor.m_ptPosition : m_defNodeList[nIndex];
	double dx = p1.x - p2.x;
	double dy = p1.y - p2.y;

	return ::sqrt( dx * dx + dy * dy );
}


double CShape_Link::GetSegAngle( int nIndex ) const
{
	ASSERT(nIndex >= 0 && nIndex <= (int)m_defNodeList.GetCount());

	CPoint p1 = nIndex == 0 ? m_srcAnchor.m_ptPosition : m_defNodeList[nIndex - 1];
	CPoint p2 = nIndex == (int)m_defNodeList.GetCount() ? m_destAnchor.m_ptPosition : m_defNodeList[nIndex];
	double dx = p2.x - p1.x;
	double dy = p2.y - p1.y;
	double length = ::sqrt( dx * dx + dy * dy );

	if ( 0 == length ) return 0;

	return dy > 0 ? ::acos(dx / length) : 2 * 3.141 - ::acos(dx / length);
}


bool CShape_Link::IntersectsSeg( const CRect& rect, int nIndex ) const
{
	if ( NULL == m_destAnchor.m_pShape ) return false;

	int nNumNodes = (int)m_defNodeList.GetCount();

	ASSERT( nIndex >= 0 && nIndex <= nNumNodes );

	int nnHandleSize = g_pTSTheme->GetHandlerRadius();

	CRgn rgn;
	CPoint p[4];
	CPoint p1 = nIndex == 0 ? m_srcAnchor.m_ptPosition : m_defNodeList[nIndex - 1];
	CPoint p2 = nIndex == nNumNodes ? m_destAnchor.m_ptPosition : m_defNodeList[nIndex];

	s_CalcSafeBox( p1, p2, nnHandleSize, p );
	rgn.CreatePolygonRgn( p, 4, ALTERNATE );

	return rgn.RectInRegion( rect ) ? true : false;
}


int CShape_Link::BreakSeg( int nIndex, const CPoint& ptPos )
{
	m_defNodeList.InsertAt( nIndex, ptPos );

	return nIndex + 2;
}


void CShape_Link::RemoveSeg( int nIndex )
{
	ASSERT( nIndex >= 0 && nIndex <= (int)m_defNodeList.GetCount() );

	if ( nIndex == (int)m_defNodeList.GetCount() )
	{
		m_defNodeList.RemoveAt( nIndex - 1 );
	}
	else
	{
		m_defNodeList.RemoveAt( nIndex );
	}
}


bool CShape_Link::OptimizeSeg( void )
{
	int nMinLength = g_pTSTheme->GetGridSize().cx;
	double dMinAngle = 0.12;
	int i;

	if ( (int)m_defNodeList.GetCount() == 0 ) return false;

	for ( i = 0; i <= (int)m_defNodeList.GetCount(); ++i )
	{
		if ( GetSegLength(i) < nMinLength )
		{
			RemoveSeg(i);
		}
	}

	for ( i = 0; i < (int)m_defNodeList.GetCount(); ++i )
	{
		double relAngle = ::fabs( GetSegAngle(i) - GetSegAngle(i + 1) );
		relAngle = relAngle > 3.14 ? (3.14 * 2 - relAngle) : relAngle;

		if ( relAngle < dMinAngle )
		{
			RemoveSeg( i );
			--i;
		}
	}

	return true;
}


CPoint CShape_Link::GetCenterPoint( void ) const
{
	ASSERT( m_bCreated );

	if ( (int)m_defNodeList.GetCount() % 2 == 0 )
	{
		int nIndex = (int)m_defNodeList.GetCount() / 2;
		CPoint p1 = nIndex == 0 ? m_srcAnchor.m_ptPosition : m_defNodeList[nIndex - 1];
		CPoint p2 = nIndex == (int)m_defNodeList.GetCount() ? m_destAnchor.m_ptPosition : m_defNodeList[nIndex];
		return CPoint( (p1.x + p2.x) / 2, (p1.y + p2.y) / 2 );
	}
	else
	{
		return m_defNodeList[(int)m_defNodeList.GetCount() / 2];
	}
}


void CShape_Link::SrcTransform( CPoint p[], int nCount ) const
{
	ASSERT( m_bCreated );

	int nIndex = 0;
	CPoint A = m_srcAnchor.m_ptPosition;
	CPoint B = nIndex == (int)m_defNodeList.GetCount() ? m_destAnchor.m_ptPosition : m_defNodeList[nIndex];
	CRect R = m_srcAnchor.m_pShape->GetBoundBox();

	s_Transform( p, nCount, A, B, R );
}


void CShape_Link::DestTransform( CPoint p[], int nCount ) const
{
	ASSERT( m_bCreated );

	int nIndex = (int)m_defNodeList.GetCount();
	CPoint B = nIndex == 0 ? m_srcAnchor.m_ptPosition : m_defNodeList[nIndex - 1];
	CPoint A = m_destAnchor.m_ptPosition;
	CRect R = m_destAnchor.m_pShape->GetBoundBox();

	s_Transform( p, nCount, A, B, R );
}


void CShape_Link::ClearAll( void )
{
	m_eLinkerType = eLINKER_TYPE_INVALID;

	m_bShowName = false;
	m_strName = CString( _T("") );
	m_NameOffset = CSize( 0, 10 );

	m_srcAnchor.m_pShape = NULL;
	m_srcAnchor.m_pLinkerInfo = NULL;

	m_destAnchor.m_pShape = NULL;
	m_destAnchor.m_pLinkerInfo = NULL;

	m_defNodeList.RemoveAll();
	m_defSegTypeList.RemoveAll();
}


bool CShape_Link::ConvertLinkerType( eOLD_BRANCH_TYPE eBranchType, CTSShape* pSrcShape, eLINKER_TYPE& eLinkerType, HLINKER& hLinker )
{
	eLinkerType = eLINKER_TYPE_INVALID;
	hLinker = eHLINKER_INVALID;

	if ( CString(_T("CShape_Start")) == pSrcShape->GetRuntimeClass()->m_lpszClassName )
	{
		switch ( eBranchType )
		{
		case eBRANCH_TYPE_YES:
			{
				eLinkerType = eLINKER_TYPE_YES;
				hLinker = pSrcShape->GetLinkerHandleFromLinkerType( eLinkerType );

				if ( eHLINKER_INVALID == hLinker )
				{
					eLinkerType = eLINKER_TYPE_INVALID;
					hLinker = eHLINKER_INVALID;

					return false;
				}
			}
			return true;
		case eBRANCH_TYPE_NO:
			{
				eLinkerType = eLINKER_TYPE_NO;
				hLinker = pSrcShape->GetLinkerHandleFromLinkerType( eLinkerType );

				if ( eHLINKER_INVALID == hLinker )
				{
					eLinkerType = eLINKER_TYPE_INVALID;
					hLinker = eHLINKER_INVALID;

					return false;
				}
			}
			return true;
		}
	}
	else if ( CString(_T("CShape_End")) == pSrcShape->GetRuntimeClass()->m_lpszClassName )
	{
	}
	else if ( CString(_T("CShape_GAct")) == pSrcShape->GetRuntimeClass()->m_lpszClassName )
	{
		switch ( eBranchType )
		{
		case eBRANCH_TYPE_DEFAULT:
			{
				eLinkerType = eLINKER_TYPE_NEXT;
				hLinker = pSrcShape->GetLinkerHandleFromLinkerType( eLinkerType );

				if ( eHLINKER_INVALID == hLinker )
				{
					eLinkerType = eLINKER_TYPE_INVALID;
					hLinker = eHLINKER_INVALID;

					return false;
				}
			}
			return true;
		case eBRANCH_TYPE_ERROR:
			{
				eLinkerType = eLINKER_TYPE_ERROR;
				hLinker = pSrcShape->GetLinkerHandleFromLinkerType( eLinkerType );

				if ( eHLINKER_INVALID == hLinker )
				{
					eLinkerType = eLINKER_TYPE_INVALID;
					hLinker = eHLINKER_INVALID;

					return false;
				}
			}
			return true;
		}
	}
	else if ( CString(_T("CShape_GCond")) == pSrcShape->GetRuntimeClass()->m_lpszClassName )
	{
		switch ( eBranchType )
		{
		case eBRANCH_TYPE_YES:
			{
				eLinkerType = eLINKER_TYPE_YES;
				hLinker = pSrcShape->GetLinkerHandleFromLinkerType( eLinkerType );

				if ( eHLINKER_INVALID == hLinker )
				{
					eLinkerType = eLINKER_TYPE_INVALID;
					hLinker = eHLINKER_INVALID;

					return false;
				}
			}
			return true;
		case eBRANCH_TYPE_NO:
			{
				eLinkerType = eLINKER_TYPE_NO;
				hLinker = pSrcShape->GetLinkerHandleFromLinkerType( eLinkerType );

				if ( eHLINKER_INVALID == hLinker )
				{
					eLinkerType = eLINKER_TYPE_INVALID;
					hLinker = eHLINKER_INVALID;

					return false;
				}
			}
			return true;
		}
	}
	else if ( CString(_T("CShape_Proposal")) == pSrcShape->GetRuntimeClass()->m_lpszClassName )
	{
		switch ( eBranchType )
		{
		case eBRANCH_TYPE_YES:
			{
				eLinkerType = eLINKER_TYPE_NEXT;
				hLinker = pSrcShape->GetLinkerHandleFromLinkerType( eLinkerType );

				if ( eHLINKER_INVALID == hLinker )
				{
					eLinkerType = eLINKER_TYPE_INVALID;
					hLinker = eHLINKER_INVALID;

					return false;
				}
			}
			return true;
		case eBRANCH_TYPE_NO:
			{
				eLinkerType = eLINKER_TYPE_CANCEL;
				hLinker = pSrcShape->GetLinkerHandleFromLinkerType( eLinkerType );

				if ( eHLINKER_INVALID == hLinker )
				{
					eLinkerType = eLINKER_TYPE_INVALID;
					hLinker = eHLINKER_INVALID;

					return false;
				}
			}
			return true;
		}
	}
	else if ( CString(_T("CShape_Narration")) == pSrcShape->GetRuntimeClass()->m_lpszClassName )
	{
		switch ( eBranchType )
		{
		case eBRANCH_TYPE_YES:
			{
				eLinkerType = eLINKER_TYPE_NEXT;
				hLinker = pSrcShape->GetLinkerHandleFromLinkerType( eLinkerType );

				if ( eHLINKER_INVALID == hLinker )
				{
					eLinkerType = eLINKER_TYPE_INVALID;
					hLinker = eHLINKER_INVALID;

					return false;
				}
			}
			return true;
		case eBRANCH_TYPE_NO:
			{
				eLinkerType = eLINKER_TYPE_CANCEL;
				hLinker = pSrcShape->GetLinkerHandleFromLinkerType( eLinkerType );

				if ( eHLINKER_INVALID == hLinker )
				{
					eLinkerType = eLINKER_TYPE_INVALID;
					hLinker = eHLINKER_INVALID;

					return false;
				}
			}
			return true;
		}
	}
	else if ( CString(_T("CShape_Reward")) == pSrcShape->GetRuntimeClass()->m_lpszClassName )
	{
		switch ( eBranchType )
		{
		case eBRANCH_TYPE_DEFAULT:
			{
				eLinkerType = eLINKER_TYPE_NEXT;
				hLinker = pSrcShape->GetLinkerHandleFromLinkerType( eLinkerType );

				if ( eHLINKER_INVALID == hLinker )
				{
					eLinkerType = eLINKER_TYPE_INVALID;
					hLinker = eHLINKER_INVALID;

					return false;
				}
			}
			return true;
		case eBRANCH_TYPE_NO:
			{
				eLinkerType = eLINKER_TYPE_CANCEL;
				hLinker = pSrcShape->GetLinkerHandleFromLinkerType( eLinkerType );

				if ( eHLINKER_INVALID == hLinker )
				{
					eLinkerType = eLINKER_TYPE_INVALID;
					hLinker = eHLINKER_INVALID;

					return false;
				}
			}
			return true;
		}
	}
	else if ( CString(_T("CShape_UsrSel")) == pSrcShape->GetRuntimeClass()->m_lpszClassName )
	{
		switch ( eBranchType )
		{
		case eBRANCH_TYPE_DEFAULT:
			{
				eLinkerType = eLINKER_TYPE_BRANCH;
				hLinker = pSrcShape->GetLinkerHandleFromLinkerType( eLinkerType );

				if ( eHLINKER_INVALID == hLinker )
				{
					eLinkerType = eLINKER_TYPE_INVALID;
					hLinker = eHLINKER_INVALID;

					return false;
				}
			}
			return true;
		case eBRANCH_TYPE_NO:
			{
				eLinkerType = eLINKER_TYPE_CANCEL;
				hLinker = pSrcShape->GetLinkerHandleFromLinkerType( eLinkerType );

				if ( eHLINKER_INVALID == hLinker )
				{
					eLinkerType = eLINKER_TYPE_INVALID;
					hLinker = eHLINKER_INVALID;

					return false;
				}
			}
			return true;
		}
	}
	else if ( CString(_T("CShape_Switch")) == pSrcShape->GetRuntimeClass()->m_lpszClassName )
	{
	}

	ASSERT( !_T("Not supported convert linker type.") );

	return false;
}
