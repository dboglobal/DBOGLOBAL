// TSAttr_ACT_QItem.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "NtlTSTool.h"
#include "TSAttr_ACT_QItem.h"


// CTSAttr_ACT_QItem ��ȭ �����Դϴ�.

IMPLEMENT_SERIAL(CTSAttr_ACT_QItem, CTSAttr_Page, 1)

CTSAttr_ACT_QItem::CTSAttr_ACT_QItem()
	: CTSAttr_Page(CTSAttr_ACT_QItem::IDD)
	, m_taID(NTL_TS_TA_ID_INVALID)
	, m_dwItemIdx0(0xffffffff)
	, m_nItemCnt0(0)
	, m_dwItemIdx1(0xffffffff)
	, m_nItemCnt1(0)
	, m_dwItemIdx2(0xffffffff)
	, m_nItemCnt2(0)
{

}

CTSAttr_ACT_QItem::~CTSAttr_ACT_QItem()
{
}

CString CTSAttr_ACT_QItem::CollectAttrDataFromDlgItems( void )
{
	CTSAttr_Page::CollectAttrDataFromDlgItems();

	CString strData;

	strData += MakeAttrData( _T("taid"), m_taID );

	if ( m_ctrCreateBtn.GetCheck() == BST_CHECKED )			strData += MakeAttrData( _T("type"), eQITEM_TYPE_CREATE );
	else if ( m_ctrDeleteBtn.GetCheck() == BST_CHECKED )	strData += MakeAttrData( _T("type"), eQITEM_TYPE_DELETE );

	if ( 0xffffffff != m_dwItemIdx0 )
	{
		strData += MakeAttrData( _T("iidx0"), m_dwItemIdx0 );
		strData += MakeAttrData( _T("icnt0"), m_nItemCnt0 );
	}
	if ( 0xffffffff != m_dwItemIdx1 )
	{
		strData += MakeAttrData( _T("iidx1"), m_dwItemIdx1 );
		strData += MakeAttrData( _T("icnt1"), m_nItemCnt1 );
	}
	if ( 0xffffffff != m_dwItemIdx2 )
	{
		strData += MakeAttrData( _T("iidx2"), m_dwItemIdx2 );
		strData += MakeAttrData( _T("icnt2"), m_nItemCnt2 );
	}

	return strData;
}

void CTSAttr_ACT_QItem::SettingAttrDataToDlgItems( CString& strKey, CString& strValue )
{
	if ( _T("taid") == strKey )
	{
		m_taID = atoi( strValue.GetBuffer() );
	}
	else if ( _T("type") == strKey )
	{
		eQITEM_TYPE eType = (eQITEM_TYPE)atoi( strValue.GetBuffer() );

		if ( eQITEM_TYPE_CREATE == eType )
		{
			m_ctrCreateBtn.SetCheck( BST_CHECKED );
			m_ctrDeleteBtn.SetCheck( BST_UNCHECKED );
		}
		else if ( eQITEM_TYPE_DELETE == eType )
		{
			m_ctrCreateBtn.SetCheck( BST_UNCHECKED );
			m_ctrDeleteBtn.SetCheck( BST_CHECKED );
		}
	}
	else if ( _T("iidx0") == strKey )
	{
		m_dwItemIdx0 = atoi( strValue.GetBuffer() );
	}
	else if ( _T("icnt0") == strKey )
	{
		m_nItemCnt0 = atoi( strValue.GetBuffer() );
	}
	else if ( _T("iidx1") == strKey )
	{
		m_dwItemIdx1 = atoi( strValue.GetBuffer() );
	}
	else if ( _T("icnt1") == strKey )
	{
		m_nItemCnt1 = atoi( strValue.GetBuffer() );
	}
	else if ( _T("iidx2") == strKey )
	{
		m_dwItemIdx2 = atoi( strValue.GetBuffer() );
	}
	else if ( _T("icnt2") == strKey )
	{
		m_nItemCnt2 = atoi( strValue.GetBuffer() );
	}
}

void CTSAttr_ACT_QItem::DoDataExchange(CDataExchange* pDX)
{
	CTSAttr_Page::DoDataExchange(pDX);

	DDX_Text(pDX, IDC_TS_ACT_ATTR_QITEM_ID_EDITOR, m_taID);
	DDV_MinMaxUInt(pDX, m_taID, 0, NTL_TS_TA_ID_INVALID);
	DDX_Control(pDX, IDC_TS_ACT_ATTR_QITEM_CREATE_CHECK, m_ctrCreateBtn);
	DDX_Control(pDX, IDC_TS_ACT_ATTR_QITEM_DELETE_CHECK, m_ctrDeleteBtn);

	DDX_Text(pDX, IDC_TS_ACT_ATTR_QITEM_0_ITEMIDX_EDITOR, m_dwItemIdx0);
	DDX_Text(pDX, IDC_TS_ACT_ATTR_QITEM_0_ITEMCNT_EDITOR, m_nItemCnt0);
	DDX_Text(pDX, IDC_TS_ACT_ATTR_QITEM_1_ITEMIDX_EDITOR, m_dwItemIdx1);
	DDX_Text(pDX, IDC_TS_ACT_ATTR_QITEM_1_ITEMCNT_EDITOR, m_nItemCnt1);
	DDX_Text(pDX, IDC_TS_ACT_ATTR_QITEM_2_ITEMIDX_EDITOR, m_dwItemIdx2);
	DDX_Text(pDX, IDC_TS_ACT_ATTR_QITEM_2_ITEMCNT_EDITOR, m_nItemCnt2);
}

BOOL CTSAttr_ACT_QItem::OnInitDialog()
{
	CTSAttr_Page::OnInitDialog();

	// TODO:  ���⿡ �߰� �ʱ�ȭ �۾��� �߰��մϴ�.
	m_ctrCreateBtn.SetCheck( BST_CHECKED );
	m_ctrDeleteBtn.SetCheck( BST_UNCHECKED );

	if ( m_strAllAttrData.GetLength() > 0 )
	{
		CTSAttr_Page::SettingAttrDataToDlgItems( m_strAllAttrData );
	}

	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}


BEGIN_MESSAGE_MAP(CTSAttr_ACT_QItem, CTSAttr_Page)
	ON_BN_CLICKED(IDC_TS_ACT_ATTR_QITEM_CREATE_CHECK, &CTSAttr_ACT_QItem::OnBnClickedTsActAttrQitemCreateCheck)
	ON_BN_CLICKED(IDC_TS_ACT_ATTR_QITEM_DELETE_CHECK, &CTSAttr_ACT_QItem::OnBnClickedTsActAttrQitemDeleteCheck)
END_MESSAGE_MAP()


// CTSAttr_ACT_QItem �޽��� ó�����Դϴ�.

void CTSAttr_ACT_QItem::OnBnClickedTsActAttrQitemCreateCheck()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	if ( BST_CHECKED == m_ctrCreateBtn.GetCheck() )
	{
		m_ctrDeleteBtn.SetCheck( BST_UNCHECKED );
	}
	else
	{
		m_ctrDeleteBtn.SetCheck( BST_CHECKED );
	}
}

void CTSAttr_ACT_QItem::OnBnClickedTsActAttrQitemDeleteCheck()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	if ( BST_CHECKED == m_ctrDeleteBtn.GetCheck() )
	{
		m_ctrCreateBtn.SetCheck( BST_UNCHECKED );
	}
	else
	{
		m_ctrCreateBtn.SetCheck( BST_CHECKED );
	}
}
