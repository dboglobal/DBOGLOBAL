#pragma once


#include "TSShapeBox.h"


class CShape_Narration : public CTSShapeBox
{

	DECLARE_SERIAL( CShape_Narration )

// Member variables
protected:


// Constructions and Destructions
protected:
	CShape_Narration( void );

public:
	CShape_Narration( const CPoint& ptPos, CTSGroup* pParent );
	virtual ~CShape_Narration( void );


// Methods
public:

	// Serialize

	virtual void						Serialize( CArchive &ar );


// Implementations
protected:

	virtual	void						ShowContainerEntityAttributeAddDlg( int nGroupID ) { return; }

	void								Save( CArchive& ar );

	bool								Load_Trig_Ver_00000000( CArchive& ar );
	bool								Load_Trig_Ver_00000001( CArchive& ar );

};