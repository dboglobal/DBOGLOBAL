#include "StdAfx.h"
#include "TSShapeBox.h"
#include "TSProjectEntity.h"

#include "MainFrm.h"
#include "NtlTSToolDoc.h"
#include "OptionListBox.h"
#include "TSAttr_Page.h"
#include "TSAttr_Page_Mng.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#endif


IMPLEMENT_SERIAL( CTSShapeBox, CTSShape, 1 )


CTSShapeBox::CTSShapeBox( void )
{
}


CTSShapeBox::CTSShapeBox( const CPoint& ptPos, CTSGroup* pParent )
: CTSShape( pParent )
{
	sSHAPE_ID sID; sID.strShapeID.Format( _T("%d"), NTL_TS_TC_ID_INVALID );
	SetShapeID( sID );

	Init( ptPos );
}


CTSShapeBox::~CTSShapeBox( void )
{
	ClearAll();
}


CRect CTSShapeBox::GetBoundBox( void ) const
{
	return CRect( m_ptOrigin, CSize( m_ShapeSize.cx, m_ShapeSize.cy ) );
}


CSize CTSShapeBox::GetMinSize( void ) const
{
	if ( m_arHeightList.GetCount() == 0 )
	{
		return CTSShape::GetMinSize();
	}
	else
	{
		return CSize( 50, m_arHeightList[m_arHeightList.GetCount()-1] );
	}
}


CSize CTSShapeBox::GetMaxSize( void ) const
{
	return GetMinSize() + CSize( 1000, 1000 );
}


CSize CTSShapeBox::GetIdealSize( void ) const
{
	return CTSShape::GetIdealSize();
}


int CTSShapeBox::GetHandlerCount( void ) const
{
	return 4;
}


CPoint CTSShapeBox::GetHandlerPos( HHANDLER hHandler ) const
{
	ASSERT( hHandler >= 0 && hHandler < GetHandlerCount() );

	switch ( hHandler )
	{
	case eBOX_HANDLER_LEFT_TOP:
		{
			return CPoint( m_ptOrigin );
		}
		break;

	case eBOX_HANDLER_LEFT_BOTTOM:
		{
			return CPoint( m_ptOrigin + CSize( 0, m_ShapeSize.cy ) );
		}
		break;

	case eBOX_HANDLER_RIGHT_BOTTOM:
		{
			return CPoint( m_ptOrigin + CSize( m_ShapeSize.cx, m_ShapeSize.cy ) );
		}
		break;

	case eBOX_HANDLER_RIGHT_TOP:
		{
			return CPoint( m_ptOrigin + CSize( m_ShapeSize.cx, 0 ) );
		}
		break;
	}

	return CPoint();
}


int CTSShapeBox::GetLinkerCount( void ) const
{
	return (int)m_defLinkerList.GetCount();
}


CPoint CTSShapeBox::GetLinkerPos( HLINKER hHandler ) const
{
	if ( m_defLinkerList[hHandler]->pShapeGroup )
	{
		int i;
		int nCnt = (int)m_defShapeGroupList.GetCount();
		for ( i = 0; i < nCnt; ++i )
		{
			if ( m_defShapeGroupList[i] == m_defLinkerList[hHandler]->pShapeGroup )
			{
				break;
			}
		}

		if ( i < nCnt )
		{
			CRect rt = GetShapeGroupRect( i );

			return CPoint( m_ptOrigin + CSize( m_ShapeSize.cx + g_pTSTheme->GetLinkerRadius() - 2, rt.top - m_ptOrigin.y + g_pTSTheme->GetLinkerRadius() ) );
		}
	}

	return CPoint( m_ptOrigin + CSize( m_ShapeSize.cx + g_pTSTheme->GetLinkerRadius() - 2, m_defLinkerList[hHandler]->nRelativeHeight ) );
}


eLINKER_TYPE CTSShapeBox::GetLinkerType( HLINKER hHandler ) const
{
	if ( eHLINKER_INVALID == hHandler )
	{
		return eLINKER_TYPE_INVALID;
	}

	return m_defLinkerList[hHandler]->eLinkerType;
}


void* CTSShapeBox::GetLinkerInfo( HLINKER hHandler ) const
{
	if ( eHLINKER_INVALID == hHandler )
	{
		return NULL;
	}

	return m_defLinkerList[hHandler];
}


CRect CTSShapeBox::GetShapeNameRect( void ) const
{
	CRect rt( m_ptOrigin + CSize( 0, m_arHeightList[0] ), CSize( m_ShapeSize.cx, g_pTSTheme->GetShapeBoxNameHeight() ) );
	rt.DeflateRect( 4, 2 );
	return rt;
}


CRect CTSShapeBox::GetShapeIDRect( void ) const
{
	CRect rt( m_ptOrigin + CSize( 0, m_arHeightList[1] ), CSize( m_ShapeSize.cx, g_pTSTheme->GetShapeBoxIDHeight() ) );
	rt.DeflateRect( 4, 2 );
	return rt;
}


CRect CTSShapeBox::GetShapeAttrNameRect( void ) const
{
	CRect rt( m_ptOrigin + CSize( 0, m_arHeightList[2] ), CSize( m_ShapeSize.cx, g_pTSTheme->GetShapeBoxAttrNameHeight() ) );
	rt.DeflateRect( 4, 2 );
	return rt;
}


CRect CTSShapeBox::GetShapeAttrRect( int nAttrIdx ) const
{
	ASSERT( nAttrIdx >= 0 && nAttrIdx < GetShapeAttrCount() );

	nAttrIdx += 3;
	CRect rt( m_ptOrigin + CSize( 0, m_arHeightList[nAttrIdx] ), CSize( m_ShapeSize.cx, g_pTSTheme->GetShapeBoxAttrHeight() ) );
	rt.DeflateRect( 10, 1, 4, 1 );
	return rt;
}


CRect CTSShapeBox::GetShapeAttrNewRect( void ) const
{
	int nIdx = 3 + GetShapeAttrCount();
	return CRect( m_ptOrigin + CSize( 0, m_arHeightList[nIdx] ), CSize( m_ShapeSize.cx, g_pTSTheme->GetShapeBoxAttrNewHeight() ) );
}


int CTSShapeBox::GetShapeAttrAt( const CPoint& ptPos ) const
{
	for ( int i = 0; i < GetShapeAttrCount(); ++i )
	{
		if ( GetShapeAttrRect( i ).PtInRect( ptPos ) )
		{
			return i;
		}
	}

	return -1;
}


bool CTSShapeBox::HasShapeAttrValue( const CString& strAttrType )
{
	for ( int i = 0; i < (int)m_defShapeAttrList.GetCount(); ++i )
	{
		if ( m_defShapeAttrList[i]->strAttrType == strAttrType )
		{
			return true;
		}
	}

	return false;
}


CString CTSShapeBox::GetShapeAttrValue( const CString& strAttrType )
{
	for ( int i = 0; i < (int)m_defShapeAttrList.GetCount(); ++i )
	{
		if ( m_defShapeAttrList[i]->strAttrType == strAttrType )
		{
			return m_defShapeAttrList[i]->strAttrValue;
		}
	}

	return CString();
}


void CTSShapeBox::SetShapeAttr( const CString& strAttrType, const CString& strAttrValue )
{
	for ( int i = 0; i < (int)m_defShapeAttrList.GetCount(); ++i )
	{
		if ( m_defShapeAttrList[i]->strAttrType == strAttrType )
		{
			m_defShapeAttrList[i]->strAttrValue = strAttrValue;
		}
	}

	UpdateHeightInfo();

	((CNtlTSToolDoc*)((CMainFrame*)AfxGetMainWnd())->GetActiveDocument())->OnShapeChange( this );
}

CTSShapeBox::sSHAPE_ATTR* CTSShapeBox::AddShapeAttr( const CString& strAttrType, const CString& strAttrValue, int nIdx /*= -1*/ )
{
	if ( -1 == nIdx )
	{
		nIdx = (int)m_defShapeAttrList.GetCount();
	}

	sSHAPE_ATTR* pAttr = new sSHAPE_ATTR;

	pAttr->strAttrType = strAttrType;
	pAttr->strAttrValue = strAttrValue;

	m_defShapeAttrList.InsertAt( nIdx, pAttr );

	UpdateHeightInfo();

	((CNtlTSToolDoc*)((CMainFrame*)AfxGetMainWnd())->GetActiveDocument())->OnShapeChange( this );

	return pAttr;
}


void CTSShapeBox::RemoveShapeAttr( sSHAPE_ATTR*& pAttr )
{
	for ( int i = 0; i < GetShapeAttrCount(); ++i )
	{
		if ( m_defShapeAttrList[i] == pAttr )
		{
			delete pAttr;
			pAttr = NULL;

			m_defShapeAttrList.RemoveAt( i );

			UpdateHeightInfo();

			((CNtlTSToolDoc*)((CMainFrame*)AfxGetMainWnd())->GetActiveDocument())->OnShapeChange( this );

			return;
		}
	}
}


void CTSShapeBox::RemoveShapeAttr( const CString& strAttrType )
{
	for ( int i = 0; i < GetShapeAttrCount(); ++i )
	{
		if ( m_defShapeAttrList[i]->strAttrType == strAttrType )
		{
			delete m_defShapeAttrList[i];

			m_defShapeAttrList.RemoveAt( i );

			UpdateHeightInfo();

			((CNtlTSToolDoc*)((CMainFrame*)AfxGetMainWnd())->GetActiveDocument())->OnShapeChange( this );

			return;
		}
	}
}


void CTSShapeBox::ClearAllShapeAttr( bool bShapeChange /*= true*/ )
{
	for ( int i = 0; i < GetShapeAttrCount(); ++i )
	{
		delete m_defShapeAttrList[i];
	}

	UpdateHeightInfo();

	m_defShapeAttrList.RemoveAll();

	if ( bShapeChange )
	{
		((CNtlTSToolDoc*)((CMainFrame*)AfxGetMainWnd())->GetActiveDocument())->OnShapeChange( this );
	}
}


CString CTSShapeBox::GetAllAttributeInfo( void )
{
	CString strAttrList;

	strAttrList.Format( _T("%s # %s # "), _T("cid"), m_sShapeID.strShapeID );

	CString strAttr;
	for ( int i = 0; i < (int)m_defShapeAttrList.GetCount(); ++i )
	{
		strAttr.Format( _T("%s # %s # "), m_defShapeAttrList[i]->strAttrType, m_defShapeAttrList[i]->strAttrValue );

		strAttrList += strAttr;
	}

	return strAttrList;
}


void CTSShapeBox::SetAllAttributeInfo( const CString& strData )
{
	enum { eTOKEN_TYPE_KEY, eTOKEN_TYPE_VALUE };

	CString strKey, strValue;

	CString strToken;
	int nStart = 0;
	bool bLoop = true;

	int nTokType = eTOKEN_TYPE_KEY;

	ClearAllShapeAttr();

	while ( bLoop )
	{
		strToken = strData.Tokenize( _T("#"), nStart );
		if ( nStart >= strData.GetLength() ) bLoop = false;

		switch ( nTokType )
		{
		case eTOKEN_TYPE_KEY:
			{
				strKey = strToken.Trim();
				strValue.Empty();

				nTokType = eTOKEN_TYPE_VALUE;
			}
			break;

		case eTOKEN_TYPE_VALUE:
			{
				strValue = strToken.Trim();

				if ( _T("cid") == strKey )
				{
					sSHAPE_ID sID;
					sID.strShapeID = strValue;

					SetShapeID( sID );
				}
				else
				{
					AddShapeAttr( strKey, strValue );
				}

				strKey.Empty();
				strValue.Empty();

				nTokType = eTOKEN_TYPE_KEY;
			}
			break;
		}
	}
}


CRect CTSShapeBox::GetShapeGroupRect( int nGroupIdx ) const
{
	int nStartIdx = 3 + GetShapeAttrCount() + 1;
	for ( int i = 0; i < nGroupIdx; ++i )
	{
		nStartIdx += (int)m_defShapeGroupList[i]->defEntityList.GetCount() + 2;
	}

	int nEndIdx = 3 + GetShapeAttrCount() + 1;
	nEndIdx += (int)m_defShapeGroupList[nGroupIdx]->defEntityList.GetCount() + 2;

	return CRect( m_ptOrigin + CSize( 0, m_arHeightList[nStartIdx] ), CSize( m_ShapeSize.cx, m_arHeightList[nEndIdx] - m_arHeightList[nStartIdx] ) );
}


int CTSShapeBox::GetShapeGroupAt( const CPoint& ptPos ) const
{
	for ( int i = 0; i < GetShapeGroupCount(); ++i )
	{
		if ( GetShapeGroupRect( i ).PtInRect( ptPos ) )
		{
			return i;
		}
	}

	return -1;
}


CTSShapeBox::sSHAPE_GROUP* CTSShapeBox::AddShapeGroup( int nIdx /*= -1*/ )
{
	if ( -1 == nIdx )
	{
		nIdx = (int)m_defShapeGroupList.GetCount();
	}

	sSHAPE_GROUP* pGroup = new sSHAPE_GROUP;

	pGroup->pLinkerInfo = NULL;

	m_defShapeGroupList.InsertAt( nIdx, pGroup );

	UpdateHeightInfo();

	((CNtlTSToolDoc*)((CMainFrame*)AfxGetMainWnd())->GetActiveDocument())->OnShapeChange( this );

	return pGroup;
}


void CTSShapeBox::RemoveShapeGroup( int nIdx )
{
	RemoveShapeGroup( m_defShapeGroupList[nIdx] );
}


void CTSShapeBox::RemoveShapeGroup( sSHAPE_GROUP*& pGroup )
{
	for ( int i = 0; i < m_defShapeGroupList.GetCount(); ++i )
	{
		if ( m_defShapeGroupList[i] == pGroup )
		{
			ClearAllShapeEntity( i );

			delete pGroup;
			pGroup = NULL;

			m_defShapeGroupList.RemoveAt( i );

			UpdateHeightInfo();

			((CNtlTSToolDoc*)((CMainFrame*)AfxGetMainWnd())->GetActiveDocument())->OnShapeChange( this );

			return;
		}
	}
}


void CTSShapeBox::MoveUpShapeGroup( int nGroupIdx )
{
	if ( nGroupIdx < 1 )
	{
		return;
	}

	if ( nGroupIdx >= m_defShapeGroupList.GetCount() )
	{
		return;
	}

	sSHAPE_GROUP* pGroupInfo = m_defShapeGroupList[nGroupIdx];
	m_defShapeGroupList[nGroupIdx] = m_defShapeGroupList[nGroupIdx - 1];
	m_defShapeGroupList[nGroupIdx - 1] = pGroupInfo;

	((CNtlTSToolDoc*)((CMainFrame*)AfxGetMainWnd())->GetActiveDocument())->OnShapeChange( this );
}


void CTSShapeBox::MoveDownShapeGroup( int nGroupIdx )
{
	if ( nGroupIdx < 0 )
	{
		return;
	}

	if ( nGroupIdx + 1 >= m_defShapeGroupList.GetCount() )
	{
		return;
	}

	sSHAPE_GROUP* pGroupInfo = m_defShapeGroupList[nGroupIdx];
	m_defShapeGroupList[nGroupIdx] = m_defShapeGroupList[nGroupIdx + 1];
	m_defShapeGroupList[nGroupIdx + 1] = pGroupInfo;

	((CNtlTSToolDoc*)((CMainFrame*)AfxGetMainWnd())->GetActiveDocument())->OnShapeChange( this );
}


void CTSShapeBox::ClearAllShapeGroup( bool bShapeChange /*= true*/ )
{
	for ( int i = 0; i < m_defShapeGroupList.GetCount(); ++i )
	{
		ClearAllShapeEntity( i, bShapeChange );

		delete m_defShapeGroupList[i];
	}

	UpdateHeightInfo();

	m_defShapeGroupList.RemoveAll();

	if ( bShapeChange )
	{
		((CNtlTSToolDoc*)((CMainFrame*)AfxGetMainWnd())->GetActiveDocument())->OnShapeChange( this );
	}
}


CRect CTSShapeBox::GetShapeEntityNameRect( int nGroupIdx ) const
{
	int nIdx = 3 + GetShapeAttrCount() + 1;
	for ( int i = 0; i < nGroupIdx; ++i )
	{
		nIdx += (int)m_defShapeGroupList[i]->defEntityList.GetCount() + 2;
	}

	CRect rt( m_ptOrigin + CSize( 0, m_arHeightList[nIdx] ), CSize( m_ShapeSize.cx, g_pTSTheme->GetShapeBoxEntityNameHeight() ) );
	rt.DeflateRect( 4, 2 );
	return rt;
}


CRect CTSShapeBox::GetShapeEntityRect( int nGroupIdx, int nEntityIdx ) const
{
	int nIdx = 3 + GetShapeAttrCount() + 1;
	for ( int i = 0; i < nGroupIdx; ++i )
	{
		nIdx += (int)m_defShapeGroupList[i]->defEntityList.GetCount() + 2;
	}

	nIdx += 1 + nEntityIdx;

	CRect rt( m_ptOrigin + CSize( 0, m_arHeightList[nIdx] ), CSize( m_ShapeSize.cx, g_pTSTheme->GetShapeBoxEntityHeight() ) );
	rt.DeflateRect( 10, 1, 4, 1 );

	return rt;
}


CRect CTSShapeBox::GetShapeEntityNewRect( int nGroupIdx ) const
{
	int nIdx = 3 + GetShapeAttrCount() + 1;
	for ( int i = 0; i < nGroupIdx; ++i )
	{
		nIdx += (int)m_defShapeGroupList[i]->defEntityList.GetCount() + 2;
	}

	nIdx += 1 + GetShapeEntityCount( nGroupIdx );

	return CRect ( m_ptOrigin + CSize( 0, m_arHeightList[nIdx] ), CSize( m_ShapeSize.cx, g_pTSTheme->GetShapeBoxEntityNewHeight() ) );
}


void CTSShapeBox::GetShapeEntityAt( const CPoint& ptPos, int& nGroupIdx, int& nEntityIdx ) const
{
	int nGroupCnt = (int)m_defShapeGroupList.GetCount();

	for ( int i = 0; i < nGroupCnt; ++i )
	{
		int nEntityCnt = (int)m_defShapeGroupList[i]->defEntityList.GetCount();

		for ( int j = 0; j < nEntityCnt; ++j )
		{
			if ( GetShapeEntityRect( i, j ).PtInRect( ptPos ) )
			{
				nGroupIdx = i;
				nEntityIdx = j;
				return;
			}
		}
	}

	nGroupIdx = -1;
	nEntityIdx = -1;
}


CTSShapeBox::sSHAPE_ENTITY* CTSShapeBox::AddShapeEntity( int nGroupIdx, const CString& strEntityType, const CString& strEntityValue, int nIdx /*= -1*/ )
{
	sSHAPE_GROUP* pGroup = m_defShapeGroupList[nGroupIdx];

	if ( -1 == nIdx )
	{
		nIdx = (int)pGroup->defEntityList.GetCount();
	}

	sSHAPE_ENTITY* pEntity = new sSHAPE_ENTITY;

	pEntity->strEntityType = strEntityType;
	pEntity->strEntityValue = strEntityValue;

	pGroup->defEntityList.InsertAt( nIdx, pEntity );

	((CNtlTSToolDoc*)((CMainFrame*)AfxGetMainWnd())->GetActiveDocument())->OnShapeChange( this );

	UpdateHeightInfo();

	return pEntity;
}


void CTSShapeBox::RemoveShapeEntity( int nGroupIdx, sSHAPE_ENTITY*& pEntity )
{
	sSHAPE_GROUP* pGroup = m_defShapeGroupList[nGroupIdx];

	for ( int i = 0; i < pGroup->defEntityList.GetCount(); ++i )
	{
		if ( pGroup->defEntityList[i] == pEntity )
		{
			delete pEntity;
			pEntity = NULL;

			pGroup->defEntityList.RemoveAt( i );

			UpdateHeightInfo();

			((CNtlTSToolDoc*)((CMainFrame*)AfxGetMainWnd())->GetActiveDocument())->OnShapeChange( this );

			return;
		}
	}
}


void CTSShapeBox::ClearAllShapeEntity( int nGroupIdx, bool bShapeChange /*= true*/ )
{
	sSHAPE_GROUP* pGroup = m_defShapeGroupList[nGroupIdx];

	for ( int i = 0; i < pGroup->defEntityList.GetCount(); ++i )
	{
		delete pGroup->defEntityList[i];
	}

	UpdateHeightInfo();

	pGroup->defEntityList.RemoveAll();

	if ( bShapeChange )
	{
		((CNtlTSToolDoc*)((CMainFrame*)AfxGetMainWnd())->GetActiveDocument())->OnShapeChange( this );
	}
}


bool CTSShapeBox::Intersects( const CRect &rect ) const
{
	CRgn rgn;
	rgn.CreateRectRgnIndirect( CRect( m_ptOrigin, CSize( m_ShapeSize.cx, m_ShapeSize.cy ) ) );
	return rgn.RectInRegion( rect ) ? true : false;
}


void CTSShapeBox::Activate( const CPoint &ptPos, bool bLBtn )
{
	CString str;

	// Shape name
	if ( GetShapeNameRect().PtInRect( ptPos ) )
	{
		ShowContainerAttributeEditDlg();
		return;
	}
	// Shape id
	else if ( GetShapeIDRect().PtInRect( ptPos ) )
	{
		ShowContainerAttributeEditDlg();
		return;
	}
	// Shape attribute
	else if ( GetShapeAttrNameRect().PtInRect( ptPos ) )
	{
		if ( m_sShapeName.strShapeType == _T("cont_switch") && GetAsyncKeyState( VK_LCONTROL ) & 0x8000 )
		{
			AddShapeGroup();
			return;
		}
		else
		{
			ShowContainerAttributeEditDlg();
			return;
		}
	}
	else if ( GetShapeAttrAt( ptPos ) != -1 )
	{
		ShowContainerAttributeEditDlg();
		return;
	}
	else if ( GetShapeAttrNewRect().PtInRect( ptPos ) )
	{
		ShowContainerAttributeEditDlg();
		return;
	}
	// Shape entity
	else
	{
		int nGroupCnt = GetShapeGroupCount();
		for ( int i = 0; i < nGroupCnt; ++i )
		{
			if ( GetShapeEntityNameRect( i ).PtInRect( ptPos ) )
			{
				if ( GetAsyncKeyState( VK_LCONTROL ) & 0x8000 )
				{
					if ( m_sShapeName.strShapeType != _T("cont_switch") ) return;

					CString strMsg;
					strMsg.Format( _T("�� �׷��� ���� ����ðڽ��ϱ�?") );

					if ( IDOK == AfxMessageBox( strMsg, MB_OKCANCEL ) )
					{
						RemoveShapeGroup( i );
						return;
					}
				}
				else
				{
					if ( bLBtn )
					{
						MoveUpShapeGroup( i );
						return;
					}
					else
					{
						MoveDownShapeGroup( i );
						return;
					}
				}
			}
			else if ( GetShapeEntityNewRect( i ).PtInRect( ptPos ) )
			{
				ShowContainerEntityAttributeAddDlg( i );
				return;
			}
		}

		int nGroupIdx, nEntityIdx;
		GetShapeEntityAt( ptPos, nGroupIdx, nEntityIdx );
		if ( -1 != nGroupIdx && -1 != nEntityIdx )
		{
			if ( GetAsyncKeyState( VK_LCONTROL ) & 0x8000 )
			{
				CString strEntityName = g_pTSConverter->GetEntityName( m_defShapeGroupList[nGroupIdx]->defEntityList[nEntityIdx]->strEntityType );

				CString strMsg;
				strMsg.Format( _T("[%s]�� ���� ����ðڽ��ϱ�?"), strEntityName );

				if ( IDOK == AfxMessageBox( strMsg, MB_OKCANCEL ) )
				{
					RemoveShapeEntity( nGroupIdx, m_defShapeGroupList[nGroupIdx]->defEntityList[nEntityIdx] );
				}

				return;
			}
			else
			{
				ShowContainerEntityAttributeEditDlg( nGroupIdx, nEntityIdx );
				return;
			}
		}
	}
}


void CTSShapeBox::Drag( const CPoint &ptPos )
{
	CPoint ptTemp;

	switch ( m_hDragHandler )
	{
	case 0:
		{
			ptTemp = GetHandlerPos( eBOX_HANDLER_RIGHT_BOTTOM );

			m_ShapeSize.cx = ptTemp.x - ptPos.x;
			m_ShapeSize.cy = ptTemp.y - ptPos.y;

			AdjustSize();

			m_ptOrigin = ptTemp - CSize( m_ShapeSize.cx, m_ShapeSize.cy );
		}
		break;

	case 1:
		{
			ptTemp = GetHandlerPos( eBOX_HANDLER_RIGHT_TOP );

			m_ShapeSize.cx = ptTemp.x - ptPos.x;
			m_ShapeSize.cy = ptPos.y - ptTemp.y;

			AdjustSize();

			m_ptOrigin = ptTemp - CSize( m_ShapeSize.cx, 0 );
		}
		break;

	case 2:
		{
			ptTemp = GetHandlerPos( eBOX_HANDLER_LEFT_TOP );

			m_ShapeSize.cx = ptPos.x - ptTemp.x;
			m_ShapeSize.cy = ptPos.y - ptTemp.y;

			AdjustSize();
		}
		break;

	case 3:
		{
			ptTemp = GetHandlerPos( eBOX_HANDLER_LEFT_BOTTOM );

			m_ShapeSize.cx = ptPos.x - ptTemp.x;
			m_ShapeSize.cy = ptTemp.y - ptPos.y;

			AdjustSize();

			m_ptOrigin = ptTemp - CSize( 0, m_ShapeSize.cy );
		}
		break;
	}

	CTSShape::Drag( ptPos );
}


void CTSShapeBox::RenderShape( CDC* pDC ) const
{
	CPen* pcOldPen;
	CBrush* pcOldBrush;
	CFont* pOldFont;

	pDC->SetBkMode( TRANSPARENT );

	// Shape outline

		// Shadow

	CPen cShadowPen( PS_SOLID, 0, g_pTSTheme->GetShapeBoxShadowColor() );
	CBrush cShadowBrush( g_pTSTheme->GetShapeBoxShadowFillColor() );

	pcOldPen = pDC->SelectObject( &cShadowPen );
	pcOldBrush = pDC->SelectObject( &cShadowBrush );

	CRect rtShadow( m_ptOrigin, CSize( m_ShapeSize.cx, m_ShapeSize.cy ) );
	rtShadow.OffsetRect( 8, 8 );
	pDC->Rectangle( rtShadow );

	pDC->SelectObject( pcOldPen );
	pDC->SelectObject( pcOldBrush );

		// Outline

	CPen cPen( PS_SOLID, 0, g_pTSTheme->GetShapeBoxOutlineColor() );
	CBrush cBrush( g_pTSTheme->GetShapeBoxOutlineFillColor() );

	pcOldPen = pDC->SelectObject( &cPen );
	pcOldBrush = pDC->SelectObject( &cBrush );

	pDC->Rectangle( CRect( m_ptOrigin, CSize( m_ShapeSize.cx, m_ShapeSize.cy ) ) );

		// Id

	pDC->MoveTo( m_ptOrigin + CSize( 0, m_arHeightList[1] ) );
	pDC->LineTo( m_ptOrigin + CSize( m_ShapeSize.cx, m_arHeightList[1] ) );

		// Attribute

	pDC->MoveTo( m_ptOrigin + CSize( 0, m_arHeightList[2] ) );
	pDC->LineTo( m_ptOrigin + CSize( m_ShapeSize.cx, m_arHeightList[2] ) );

		// Group

	for ( int i = 0; i < GetShapeGroupCount(); ++i )
	{
		int nIdx = 3 + GetShapeAttrCount() + 1;
		for ( int j = 0; j < i; ++j )
		{
			nIdx += (int)m_defShapeGroupList[j]->defEntityList.GetCount() + 2;
		}

		pDC->MoveTo( m_ptOrigin + CSize( 0, m_arHeightList[nIdx] ) );
		pDC->LineTo( m_ptOrigin + CSize( m_ShapeSize.cx, m_arHeightList[nIdx] ) );
	}

	// Shape name

	CString strShapeName = g_pTSConverter->GetContainerName( m_sShapeName.strShapeType );

	pOldFont = pDC->SelectObject( g_pTSTheme->GetShapeBoxNameFont() );
	pDC->SetTextColor( g_pTSTheme->GetShapeBoxNameColor() );

	pDC->DrawText( strShapeName, GetShapeNameRect(), DT_CENTER|DT_SINGLELINE|DT_VCENTER|DT_END_ELLIPSIS|DT_NOPREFIX );

	pDC->SelectObject( pOldFont );

	// Shape id

	CString strShapeID;
	strShapeID.Format( _T("%s : "), g_pTSConverter->GetContainerAttrName( m_sShapeName.strShapeType, _T("cid") ) );
	strShapeID += m_sShapeID.strShapeID;

	pOldFont = pDC->SelectObject( g_pTSTheme->GetShapeBoxIDFont() );
	pDC->SetTextColor( g_pTSTheme->GetShapeBoxIDColor() );

	pDC->DrawText( strShapeID, GetShapeIDRect(), DT_CENTER|DT_SINGLELINE|DT_VCENTER|DT_END_ELLIPSIS|DT_NOPREFIX );

	pDC->SelectObject( pOldFont );

	// Shape attribute

		// Shape attribute name

	CString strShapeAttrName = _T("�Ӽ�");

	pOldFont = pDC->SelectObject( g_pTSTheme->GetShapeBoxAttrNameFont() );
	pDC->SetTextColor( g_pTSTheme->GetShapeBoxAttrNameColor() );

	pDC->DrawText( strShapeAttrName, GetShapeAttrNameRect(), DT_CENTER|DT_SINGLELINE|DT_VCENTER|DT_END_ELLIPSIS|DT_NOPREFIX );

	pDC->SelectObject( pOldFont );

		// Shape attribute
	for ( int i = 0; i < GetShapeAttrCount(); ++i )
	{
		CString strShapeAttr = g_pTSConverter->GetContainerAttrName( m_sShapeName.strShapeType, m_defShapeAttrList[i]->strAttrType );
		strShapeAttr += _T(" : ");
		strShapeAttr += m_defShapeAttrList[i]->strAttrValue;

		pOldFont = pDC->SelectObject( g_pTSTheme->GetShapeBoxAttrFont() );
		pDC->SetTextColor( g_pTSTheme->GetShapeBoxAttrColor() );

		pDC->DrawText( strShapeAttr, GetShapeAttrRect( i ), DT_LEFT|DT_SINGLELINE|DT_VCENTER|DT_END_ELLIPSIS|DT_NOPREFIX );

		pDC->SelectObject( pOldFont );
	}

	// Shape entity

	for ( int i = 0; i < GetShapeGroupCount(); ++i )
	{
		// Shape entity name

		CString strShapeEntityName = _T("����");

		pOldFont = pDC->SelectObject( g_pTSTheme->GetShapeBoxEntityNameFont() );
		pDC->SetTextColor( g_pTSTheme->GetShapeBoxEntityNameColor() );

		pDC->DrawText( strShapeEntityName, GetShapeEntityNameRect( i ), DT_CENTER|DT_SINGLELINE|DT_VCENTER|DT_END_ELLIPSIS|DT_NOPREFIX );

		pDC->SelectObject( pOldFont );

		// Shape entity

		defSHAPE_ENTITY_LIST* pEntityList = &m_defShapeGroupList[i]->defEntityList;
		for ( int j = 0; j < pEntityList->GetCount(); ++j )
		{
			CString strShapeEntity = g_pTSConverter->GetEntityName( (*pEntityList)[j]->strEntityType );
			strShapeEntity += _T(" : ");
			strShapeEntity += (*pEntityList)[j]->strEntityValue;

			pOldFont = pDC->SelectObject( g_pTSTheme->GetShapeBoxEntityFont() );
			pDC->SetTextColor( g_pTSTheme->GetShapeBoxEntityColor() );

			pDC->DrawText( strShapeEntity, GetShapeEntityRect( i, j ), DT_LEFT|DT_SINGLELINE|DT_VCENTER|DT_END_ELLIPSIS|DT_NOPREFIX );

			pDC->SelectObject( pOldFont );
		}
	}

	pDC->SelectObject( pcOldPen );
	pDC->SelectObject( pcOldBrush );
}


void CTSShapeBox::MakeAttributeInfo( CNtlTSScrProperty& ScrPropertyList )
{
}


void CTSShapeBox::Serialize( CArchive& ar )
{
	CTSShape::Serialize( ar );

	if ( ar.IsStoring() )
	{
		Save( ar );
	}
	else
	{
		ClearAll();

		switch ( m_pParent->GetParent()->GetParent()->GetProjectEntityVersion() )
		{
		case 0:
			if ( !Load_Trig_Ver_00000000( ar ) )
			{
				return;
			}
			break;

		case 1:
			if ( !Load_Trig_Ver_00000001( ar ) )
			{
				return;
			}
			break;

		default:
			ASSERT( !_T("The version of its project entity file is wrong.") );
			return;
		}

		UpdateHeightInfo();
	}
}


void CTSShapeBox::ClearAll( void )
{
	ClearAllLinker( false );
	ClearAllShapeAttr( false );
	ClearAllShapeGroup( false );

	m_arHeightList.RemoveAll();
}


void CTSShapeBox::Init( const CPoint& ptPos )
{
	m_ptOrigin = ptPos;

	m_ShapeSize = GetIdealSize();

	UpdateHeightInfo();
}


void CTSShapeBox::AdjustSize( void )
{
	CSize MinSize = GetMinSize();
	CSize MaxSize = GetMaxSize();

	ASSERT( MinSize.cx <= MaxSize.cx );
	ASSERT( MinSize.cy <= MaxSize.cy );

	if ( m_ShapeSize.cx < MinSize.cx) m_ShapeSize.cx = MinSize.cx;
	if ( m_ShapeSize.cx > MaxSize.cx) m_ShapeSize.cx = MaxSize.cx;
	if ( m_ShapeSize.cy < MinSize.cy) m_ShapeSize.cy = MinSize.cy;
	if ( m_ShapeSize.cy > MaxSize.cy) m_ShapeSize.cy = MaxSize.cy;
}

void CTSShapeBox::UpdateHeightInfo( void )
{
	int nHeight = 0;
	int i, j;

	m_arHeightList.RemoveAll();

	// Shape name
	m_arHeightList.Add( nHeight );
	nHeight += g_pTSTheme->GetShapeBoxNameHeight();

	// Shape id
	m_arHeightList.Add( nHeight );
	nHeight += g_pTSTheme->GetShapeBoxIDHeight();

	// Attribute name
	m_arHeightList.Add( nHeight );
	nHeight += g_pTSTheme->GetShapeBoxAttrNameHeight();

	// Attribute
	for ( i = 0; i < GetShapeAttrCount(); ++i )
	{
		m_arHeightList.Add( nHeight );
		nHeight += g_pTSTheme->GetShapeBoxAttrHeight();
	}

	// Attribute new
	m_arHeightList.Add( nHeight );
	nHeight += g_pTSTheme->GetShapeBoxAttrNewHeight();

	for ( i = 0; i < GetShapeGroupCount(); ++i )
	{
		// Entity name
		m_arHeightList.Add( nHeight );
		nHeight += g_pTSTheme->GetShapeBoxEntityNameHeight();

		// Entity
		for ( j = 0; j < m_defShapeGroupList[i]->defEntityList.GetCount(); ++j )
		{
			m_arHeightList.Add( nHeight );
			nHeight += g_pTSTheme->GetShapeBoxEntityHeight();
		}

		// Entity new
		m_arHeightList.Add( nHeight );
		nHeight += g_pTSTheme->GetShapeBoxEntityNewHeight();
	}

	// Bottom
	m_arHeightList.Add( nHeight );

	AdjustSize();
}


CTSShapeBox::sBOX_LINKER_INFO* CTSShapeBox::AddLinker( eLINKER_TYPE eType, int nRelativeHeight )
{
	sBOX_LINKER_INFO* psLinkInfo = new sBOX_LINKER_INFO;

	psLinkInfo->eLinkerType = eType;
	psLinkInfo->nRelativeHeight = nRelativeHeight;
	psLinkInfo->pShapeGroup = NULL;

	m_defLinkerList.Add( psLinkInfo );

	((CNtlTSToolDoc*)((CMainFrame*)AfxGetMainWnd())->GetActiveDocument())->OnShapeChange( this );

	return psLinkInfo;
}


void CTSShapeBox::RemoveLinker( sBOX_LINKER_INFO*& psLinkerInfo )
{
	for ( int i = 0; i < m_defLinkerList.GetCount(); ++i )
	{
		if ( m_defLinkerList[i] == psLinkerInfo )
		{
			((CNtlTSToolDoc*)((CMainFrame*)AfxGetMainWnd())->GetActiveDocument())->OnDeleteShapeLink( this, psLinkerInfo );

			delete psLinkerInfo;
			psLinkerInfo = NULL;

			m_defLinkerList.RemoveAt( i );

			((CNtlTSToolDoc*)((CMainFrame*)AfxGetMainWnd())->GetActiveDocument())->OnShapeChange( this );

			return;
		}
	}
}


void CTSShapeBox::ClearAllLinker( bool bShapeChange /*= true*/ )
{
	for ( int i = 0; i < m_defLinkerList.GetCount(); ++i )
	{
		((CNtlTSToolDoc*)((CMainFrame*)AfxGetMainWnd())->GetActiveDocument())->OnDeleteShapeLink( this, m_defLinkerList[i] );

		delete m_defLinkerList[i];
	}

	m_defLinkerList.RemoveAll();

	if ( bShapeChange )
	{
		((CNtlTSToolDoc*)((CMainFrame*)AfxGetMainWnd())->GetActiveDocument())->OnShapeChange( this );
	}
}


void CTSShapeBox::ShowContainerAttributeEditDlg( void )
{
	CTSAttr_Page* pPage = g_pTSConverter->GetAttrPage( GetShapeName().strShapeType );
	if ( NULL == pPage ) return;

	pPage->SetAllAttrData( GetAllAttributeInfo() );

	COptionListBox clListBox;
	CTSAttr_Page_Mng clDiag;
	clDiag.SetListControl( &clListBox );

	clDiag.AddTSAttrPage( pPage );

	if ( IDOK == clDiag.DoModal() && clDiag.GetActivatedPage() )
	{
		CString strAttrInfo = clDiag.GetActivatedPage()->GetAllAttrData();

		SetAllAttributeInfo( strAttrInfo );

		UpdateHeightInfo();

		((CNtlTSToolDoc*)((CMainFrame*)AfxGetMainWnd())->GetActiveDocument())->OnShapeChange( this );
	}

	delete pPage;
}


void CTSShapeBox::ShowContainerEntityAttributeEditDlg( int nGroupID, int nEntityIdx )
{
	COptionListBox clListBox;
	CTSAttr_Page_Mng clDiag;
	clDiag.SetListControl( &clListBox );

	CTSAttr_Page* pPage = g_pTSConverter->GetAttrPage( m_defShapeGroupList[nGroupID]->defEntityList[nEntityIdx]->strEntityType );
	pPage->SetAllAttrData( m_defShapeGroupList[nGroupID]->defEntityList[nEntityIdx]->strEntityValue );

	clDiag.AddTSAttrPage( pPage );

	if ( IDOK == clDiag.DoModal() && clDiag.GetActivatedPage() )
	{
		CString strAttrInfo = clDiag.GetActivatedPage()->GetAllAttrData();

		m_defShapeGroupList[nGroupID]->defEntityList[nEntityIdx]->strEntityValue = strAttrInfo;

		UpdateHeightInfo();

		((CNtlTSToolDoc*)((CMainFrame*)AfxGetMainWnd())->GetActiveDocument())->OnShapeChange( this );
	}

	delete pPage;
}


void CTSShapeBox::Save( CArchive& ar )
{
	// Shape size

	ar << m_ShapeSize;

	// Shape id

	ar << m_sShapeID.strShapeID;

	// Shape attributes

	m_defShapeAttrList.Serialize( ar );

	// Shape groups

	ar << (int)m_defShapeGroupList.GetCount();

	for ( int i = 0; i < (int)m_defShapeGroupList.GetCount(); ++i )
	{
		m_defShapeGroupList[i]->defEntityList.Serialize( ar );
	}
}


bool CTSShapeBox::Load_Trig_Ver_00000000( CArchive& ar )
{
	// Shape size

	ar >> m_ShapeSize.cx;
	ar >> m_ShapeSize.cy;

	// Shape attribute or entity show

	BOOL bShow;
	ar >> bShow;	// Attribute show
	ar >> bShow;	// Entity show

	// Shape type

	CString strShapeType;
	ar >> strShapeType;

	// Shape id

	sSHAPE_ID sShapeID;
	ar >> sShapeID.strShapeID;

	SetShapeID( sShapeID );

	// Shape attributes

	m_defShapeAttrList.Serialize( ar );

	// Shape groups

	AddShapeGroup( 0 )->defEntityList.Serialize( ar );

	return true;
}


bool CTSShapeBox::Load_Trig_Ver_00000001( CArchive& ar )
{
	// Shape size

	ar >> m_ShapeSize;

	// Shape id

	sSHAPE_ID sShapeID;
	ar >> sShapeID.strShapeID;

	SetShapeID( sShapeID );

	// Shape attributes

	m_defShapeAttrList.Serialize( ar );

	// Shape groups

	int nShapeGroupCnt;
	ar >> nShapeGroupCnt;

	for ( int i = 0; i < nShapeGroupCnt; ++i )
	{
		AddShapeGroup( i )->defEntityList.Serialize( ar );
	}

	return true;
}


template<> void AFXAPI SerializeElements< CTSShapeBox::sSHAPE_ATTR* >( CArchive &ar, CTSShapeBox::sSHAPE_ATTR** pData, INT_PTR nCount )
{
	if ( ar.IsStoring() )
	{
		for ( int i = 0; i < nCount; ++i )
		{
			ar << pData[i]->strAttrType;
			ar << pData[i]->strAttrValue;
		}
	}
	else
	{
		for ( int i = 0; i < nCount; ++i )
		{
			pData[i] = new CTSShapeBox::sSHAPE_ATTR;

			ar >> pData[i]->strAttrType;
			ar >> pData[i]->strAttrValue;
		}
	}
}


template<> void AFXAPI SerializeElements< CTSShapeBox::sSHAPE_ENTITY* >( CArchive &ar, CTSShapeBox::sSHAPE_ENTITY** pData, INT_PTR nCount )
{
	if ( ar.IsStoring() )
	{
		for ( int i = 0; i < nCount; ++i )
		{
			ar << pData[i]->strEntityType;
			ar << pData[i]->strEntityValue;
		}
	}
	else
	{
		for ( int i = 0; i < nCount; ++i )
		{
			pData[i] = new CTSShapeBox::sSHAPE_ENTITY;

			ar >> pData[i]->strEntityType;
			ar >> pData[i]->strEntityValue;
		}
	}
}
