// TSProjectCreateMenu.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "NtlTSTool.h"
#include "TSProjectCreateMenu.h"


// CTSProjectCreateMenu ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CTSProjectCreateMenu, CDialog)

CTSProjectCreateMenu::CTSProjectCreateMenu(CWnd* pParent /*=NULL*/)
	: CDialog(CTSProjectCreateMenu::IDD, pParent)
	, m_strProjPath(_T(""))
	, m_strProjName(_T(""))
{

}

CTSProjectCreateMenu::~CTSProjectCreateMenu()
{
}

void CTSProjectCreateMenu::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT2, m_strProjPath);
	DDX_Text(pDX, IDC_EDIT1, m_strProjName);
	DDX_Control(pDX, IDC_COMBO1, m_ctrTSMode);
}

void CTSProjectCreateMenu::OnOK()
{
	m_dwMode = (DWORD)m_ctrTSMode.GetItemData( m_ctrTSMode.GetCurSel() );

	CDialog::OnOK();
}

BEGIN_MESSAGE_MAP(CTSProjectCreateMenu, CDialog)
	ON_BN_CLICKED(IDC_BUTTON1, &CTSProjectCreateMenu::OnBnClickedButton1)
END_MESSAGE_MAP()


// CTSProjectCreateMenu �޽��� ó�����Դϴ�.

BOOL CTSProjectCreateMenu::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  ���⿡ �߰� �ʱ�ȭ �۾��� �߰��մϴ�.
	int nIdx = m_ctrTSMode.AddString( _T("Quest CS") );
	m_ctrTSMode.SetItemData( nIdx, 0 );
	m_ctrTSMode.SetItemData( m_ctrTSMode.AddString( _T("Trigger CS") ), 1 );
	m_ctrTSMode.SetItemData( m_ctrTSMode.AddString( _T("Object S") ), 2 );
	m_ctrTSMode.SetCurSel( nIdx );

	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}

void CTSProjectCreateMenu::OnBnClickedButton1()
{
	BROWSEINFO bi;
	ZeroMemory( &bi, sizeof(BROWSEINFO) );
	bi.hwndOwner = NULL;
	LPITEMIDLIST pidl = SHBrowseForFolder( &bi );

	if ( pidl )
	{
		TCHAR szPath[MAX_PATH] = {0};
		SHGetPathFromIDList( pidl, szPath );

		m_strProjPath = szPath;
	}
	else
	{
		m_strProjPath.Empty();
	}

	UpdateData( FALSE );
}

