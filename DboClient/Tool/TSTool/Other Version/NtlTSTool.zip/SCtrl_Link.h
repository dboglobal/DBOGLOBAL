#pragma once


#include "TSShapeCtrl.h"


class CTSShape;
class CShape_Link;


class CSCtrl_Link : public CTSShapeCtrl
{

// Member variables
protected:

	eLINKER_TYPE						m_eLinkerType;
	CTSShape*							m_pSrcShape;
	void*								m_pLinkerInfo;

	CShape_Link*						m_pShapeLink;


// Constructions and Destructions
public:

	CSCtrl_Link( CNtlTSToolView* pParent );
	virtual ~CSCtrl_Link( void );


// Methods
public:

	virtual void						OnMouseLButtonDown( const CPoint& ptPos, UINT nFlags, eLINKER_TYPE eLinkerType, CTSShape* pSrcShape, void* pLinkerInfo );
	virtual void						OnMouseLButtonUp( const CPoint& ptPos, UINT nFlags );
	virtual void						OnMouseLButtonDoubleClick( const CPoint& ptPos, UINT nFlags );
	virtual void						OnMouseMove( const CPoint& ptPos, UINT nFlags );

	virtual void						OnContextMenu( const CPoint& ptPos );
	virtual void						OnDeactivate( void );

	virtual CShape_Link*				New( const CPoint& ptPos );
};