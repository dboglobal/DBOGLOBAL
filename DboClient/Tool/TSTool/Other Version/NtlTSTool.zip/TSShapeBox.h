#pragma once


#include "TSShape.h"


class CTSShapeBox : public CTSShape
{

	DECLARE_SERIAL( CTSShapeBox )


// Declarations
public:

	enum
	{
		eBOX_HANDLER_LEFT_TOP,
		eBOX_HANDLER_LEFT_BOTTOM,
		eBOX_HANDLER_RIGHT_BOTTOM,
		eBOX_HANDLER_RIGHT_TOP,
		eBOX_HANDLER_MAX
	};

	struct sSHAPE_GROUP;

	struct sBOX_LINKER_INFO
	{
		eLINKER_TYPE					eLinkerType;
		int								nRelativeHeight;
		sSHAPE_GROUP*					pShapeGroup;
	};

	typedef CArray< sBOX_LINKER_INFO* >	defLINKER_LIST;

	struct sSHAPE_NAME
	{
		CString							strShapeType;
	};

	struct sSHAPE_ID
	{
		CString							strShapeID;
	};

	struct sSHAPE_ATTR
	{
		CString							strAttrType;
		CString							strAttrValue;
	};

	typedef CArray< sSHAPE_ATTR* > defSHAPE_ATTR_LIST;

	struct sSHAPE_ENTITY
	{
		CString							strEntityType;
		CString							strEntityValue;
	};

	typedef CArray< sSHAPE_ENTITY* > defSHAPE_ENTITY_LIST;

	struct sSHAPE_GROUP
	{
		defSHAPE_ENTITY_LIST			defEntityList;

		sBOX_LINKER_INFO*				pLinkerInfo;
	};

	typedef CArray< sSHAPE_GROUP* > defSHAPE_GROUP_LIST;


// Member variables
protected:

	CSize								m_ShapeSize;

	defLINKER_LIST						m_defLinkerList;

	sSHAPE_NAME							m_sShapeName;

	sSHAPE_ID							m_sShapeID;

	defSHAPE_ATTR_LIST					m_defShapeAttrList;

	defSHAPE_GROUP_LIST					m_defShapeGroupList;

	CArray< int >						m_arHeightList;


// Constructions and Destructions
protected:

	CTSShapeBox( void );


public:

	CTSShapeBox( const CPoint& ptPos, CTSGroup* pParent );

	~CTSShapeBox( void );


// Methods
public:

	// ����

	virtual CRect						GetBoundBox( void ) const;
	virtual CSize						GetMinSize( void ) const;
	virtual CSize						GetMaxSize( void ) const;
	virtual CSize						GetIdealSize( void ) const;


	// Handler

	virtual int							GetHandlerCount( void ) const;
	virtual CPoint						GetHandlerPos( HHANDLER hHandler ) const;


	// Linker

	virtual int							GetLinkerCount( void ) const;
	virtual CPoint						GetLinkerPos( HLINKER hHandler ) const;
	virtual eLINKER_TYPE				GetLinkerType( HLINKER hHandler ) const;
	virtual void*						GetLinkerInfo( HLINKER hHandler ) const;

	// Shape name

	CRect								GetShapeNameRect( void ) const;

	sSHAPE_NAME							GetShapeName( void ) const { return m_sShapeName; }
	void								SetShapeName( const sSHAPE_NAME& sShapeName ) { m_sShapeName = sShapeName; }


	// Shape id

	CRect								GetShapeIDRect( void ) const;

	sSHAPE_ID							GetShapeID( void ) const { return m_sShapeID; }
	void								SetShapeID( const sSHAPE_ID& sShapeID ) { m_sShapeID = sShapeID; }


	// Shape attributes

	CRect								GetShapeAttrNameRect( void ) const;

	int									GetShapeAttrCount( void ) const { return (int)m_defShapeAttrList.GetCount(); }
	CRect								GetShapeAttrRect( int nAttrIdx ) const;

	CRect								GetShapeAttrNewRect( void ) const;

	int									GetShapeAttrAt( const CPoint& ptPos ) const;

	bool								HasShapeAttrValue( const CString& strAttrType );
	CString								GetShapeAttrValue( const CString& strAttrType );
	void								SetShapeAttr( const CString& strAttrType, const CString& strAttrValue );
	sSHAPE_ATTR*						AddShapeAttr( const CString& strAttrType, const CString& strAttrValue, int nIdx = -1 );
	void								RemoveShapeAttr( sSHAPE_ATTR*& pAttr );
	void								RemoveShapeAttr( const CString& strAttrType );
	void								ClearAllShapeAttr( bool bShapeChange = true );

	CString								GetAllAttributeInfo( void );
	void								SetAllAttributeInfo( const CString& strAllAttrData );


	// Shape group

	int									GetShapeGroupCount( void ) const { return (int)m_defShapeGroupList.GetCount(); }
	CRect								GetShapeGroupRect( int nGroupIdx ) const;

	int									GetShapeGroupAt( const CPoint& ptPos ) const;

	virtual sSHAPE_GROUP*				AddShapeGroup( int nIdx = -1 );
	virtual void						RemoveShapeGroup( int nIdx );
	virtual void						RemoveShapeGroup( sSHAPE_GROUP*& pGroup );
	void								MoveUpShapeGroup( int nGroupIdx );
	void								MoveDownShapeGroup( int nGroupIdx );
	virtual void						ClearAllShapeGroup( bool bShapeChange = true );


	// Shape entity

	CRect								GetShapeEntityNameRect( int nGroupIdx ) const;

	int									GetShapeEntityCount( int nGroupIdx ) const { return (int)m_defShapeGroupList[nGroupIdx]->defEntityList.GetCount(); }
	CRect								GetShapeEntityRect( int nGroupIdx, int nEntityIdx ) const;

	CRect								GetShapeEntityNewRect( int nGroupIdx ) const;

	void								GetShapeEntityAt( const CPoint& ptPos, int& nGroupIdx, int& nEntityIdx ) const;

	sSHAPE_ENTITY*						AddShapeEntity( int nGroupIdx, const CString& strEntityType, const CString& strEntityValue, int nIdx = -1 );
	void								RemoveShapeEntity( int nGroupIdx, sSHAPE_ENTITY*& pEntity );
	void								ClearAllShapeEntity( int nGroupIdx, bool bShapeChange = true );


	// Intersection

	virtual bool						Intersects( const CRect &rect ) const;


	// Activate

	virtual void						Activate( const CPoint &ptPos, bool bLBtn );


	// Drag

	virtual void						Drag( const CPoint &ptPos );


	// Render

	virtual void						RenderShape( CDC* pDC ) const;


	// Attribute info for export

	virtual void						MakeAttributeInfo( CNtlTSScrProperty& ScrPropertyList );


	// Serialize

	virtual void						Serialize( CArchive& ar );


// Implementations
protected:

	void								ClearAll( void );

	void								Init( const CPoint& ptPos );

	void								AdjustSize( void );

	virtual void						UpdateHeightInfo( void );

	sBOX_LINKER_INFO*					AddLinker( eLINKER_TYPE eType, int nRelativeHeight );
	void								RemoveLinker( sBOX_LINKER_INFO*& psLinkerInfo );
	void								ClearAllLinker( bool bShapeChange = true );

	virtual	void						ShowContainerAttributeEditDlg( void );
	virtual	void						ShowContainerEntityAttributeAddDlg( int nGroupID ) { return; }
	virtual	void						ShowContainerEntityAttributeEditDlg( int nGroupID, int nEntityIdx );

	// Load and Save

	void								Save( CArchive& ar );

	bool								Load_Trig_Ver_00000000( CArchive& ar );
	bool								Load_Trig_Ver_00000001( CArchive& ar );

};


template<> void AFXAPI SerializeElements< CTSShapeBox::sSHAPE_ATTR* >( CArchive &ar, CTSShapeBox::sSHAPE_ATTR** pData, INT_PTR nCount );
template<> void AFXAPI SerializeElements< CTSShapeBox::sSHAPE_ENTITY* >( CArchive &ar, CTSShapeBox::sSHAPE_ENTITY** pData, INT_PTR nCount );
