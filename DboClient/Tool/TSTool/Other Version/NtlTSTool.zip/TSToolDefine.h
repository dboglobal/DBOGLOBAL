// TSToolDefine.h
//


#pragma once


/** 
	Extention
*/


#define PROJECT_FILE_EXTENTION			_T("pro");
#define TS_FILE_EXTENTION				(_T("ts"))


/** 
	Version
*/


#define TS_PROJECT_FILE_VERSION			(0x00000001)

#define TS_PROJECT_ENTITY_FILE_VERSION	(0x00000001)



/** 
	Select group type
*/


enum eSEL_GROUP_TYPE
{
	eSEL_GROUP_TYPE_MAIN,
	eSEL_GROUP_TYPE_EXCEPTION,

	eSEL_GROUP_TYPE_INVALID				= 0xffffffff
};


/** 
	Handler
*/


typedef int HHANDLER;


enum
{
	eHHANDLER_DRAG_TEXT_HANDLE			= -2,
	eHHANDLER_INVALID					= -1
};


/** 
	Linker
*/


typedef int HLINKER;


enum
{
	eHLINKER_INVALID					= -1
};


enum eLINKER_TYPE
{
	eLINKER_TYPE_YES,
	eLINKER_TYPE_NO,
	eLINKER_TYPE_NEXT,
	eLINKER_TYPE_CANCEL,
	eLINKER_TYPE_ERROR,
	eLINKER_TYPE_BRANCH,
	eLINKER_TYPE_SWITCH,

	eLINKER_TYPE_MAX,

	eLINKER_TYPE_INVALID				= -1
};
