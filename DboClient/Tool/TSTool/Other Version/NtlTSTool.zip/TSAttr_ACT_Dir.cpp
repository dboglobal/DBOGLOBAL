// TSAttr_ACT_Dir.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "NtlTSTool.h"
#include "TSAttr_ACT_Dir.h"


// CTSAttr_ACT_Dir ��ȭ �����Դϴ�.

IMPLEMENT_SERIAL(CTSAttr_ACT_Dir, CTSAttr_Page, 1)

CTSAttr_ACT_Dir::CTSAttr_ACT_Dir()
	: CTSAttr_Page(CTSAttr_ACT_Dir::IDD)
	, m_taID(NTL_TS_TA_ID_INVALID)
	, m_tcJumpID(NTL_TS_TC_ID_INVALID)
{

}

CTSAttr_ACT_Dir::~CTSAttr_ACT_Dir()
{
}

CString CTSAttr_ACT_Dir::CollectAttrDataFromDlgItems( void )
{
	CTSAttr_Page::CollectAttrDataFromDlgItems();

	CString strData;

	strData += MakeAttrData( _T("taid"), m_taID );

	if ( m_ctrStartBtn.GetCheck() == BST_CHECKED )		strData += MakeAttrData( _T("type"), eDIR_TYPE_START );
	else if ( m_ctrEndBtn.GetCheck() == BST_CHECKED )	strData += MakeAttrData( _T("type"), eDIR_TYPE_END );

	strData += MakeAttrData( _T("jump"), m_tcJumpID );

	return strData;
}

void CTSAttr_ACT_Dir::SettingAttrDataToDlgItems( CString& strKey, CString& strValue )
{
	if ( _T("taid") == strKey )
	{
		m_taID = atoi( strValue.GetBuffer() );
	}
	else if ( _T("type") == strKey )
	{
		eDIR_TYPE eType = (eDIR_TYPE)atoi( strValue.GetBuffer() );

		if ( eDIR_TYPE_START == eType )	m_ctrStartBtn.SetCheck( BST_CHECKED );
		else if ( eDIR_TYPE_END == eType )	m_ctrEndBtn.SetCheck( BST_CHECKED );
	}
	else if ( _T("jump") == strKey )
	{
		m_tcJumpID = atoi( strValue.GetBuffer() );
	}
}

void CTSAttr_ACT_Dir::DoDataExchange(CDataExchange* pDX)
{
	CTSAttr_Page::DoDataExchange(pDX);

	DDX_Text(pDX, IDC_TS_ACT_ATTR_DIR_ID_EDITOR, m_taID);
	DDV_MinMaxUInt(pDX, m_taID, 0, NTL_TS_TA_ID_INVALID);
	DDX_Text(pDX, IDC_TS_ACT_ATTR_DIR_JUMPCONTID_EDITOR, m_tcJumpID);
	DDV_MinMaxUInt(pDX, m_tcJumpID, 0, NTL_TS_TC_ID_INVALID);
	DDX_Control(pDX, IDC_TS_ACT_ATTR_DIR_DIR_START_CHECK, m_ctrStartBtn);
	DDX_Control(pDX, IDC_TS_ACT_ATTR_DIR_DIR_END_CHECK, m_ctrEndBtn);
}

BOOL CTSAttr_ACT_Dir::OnInitDialog()
{
	CTSAttr_Page::OnInitDialog();

	// TODO:  ���⿡ �߰� �ʱ�ȭ �۾��� �߰��մϴ�.
	m_ctrStartBtn.SetCheck( BST_UNCHECKED );
	m_ctrEndBtn.SetCheck( BST_UNCHECKED );

	if ( m_strAllAttrData.GetLength() > 0 )
	{
		CTSAttr_Page::SettingAttrDataToDlgItems( m_strAllAttrData );
	}

	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}


BEGIN_MESSAGE_MAP(CTSAttr_ACT_Dir, CTSAttr_Page)
	ON_BN_CLICKED(IDC_TS_ACT_ATTR_DIR_DIR_START_CHECK, &CTSAttr_ACT_Dir::OnBnClickedTsActAttrDirDirStartCheck)
	ON_BN_CLICKED(IDC_TS_ACT_ATTR_DIR_DIR_END_CHECK, &CTSAttr_ACT_Dir::OnBnClickedTsActAttrDirDirEndCheck)
END_MESSAGE_MAP()


// CTSAttr_ACT_Dir �޽��� ó�����Դϴ�.

void CTSAttr_ACT_Dir::OnBnClickedTsActAttrDirDirStartCheck()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	if ( BST_CHECKED == m_ctrStartBtn.GetCheck() )
	{
		m_ctrEndBtn.SetCheck( BST_UNCHECKED );
	}
	else
	{
		m_ctrEndBtn.SetCheck( BST_CHECKED );
	}
}

void CTSAttr_ACT_Dir::OnBnClickedTsActAttrDirDirEndCheck()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	if ( BST_CHECKED == m_ctrEndBtn.GetCheck() )
	{
		m_ctrStartBtn.SetCheck( BST_UNCHECKED );
	}
	else
	{
		m_ctrStartBtn.SetCheck( BST_CHECKED );
	}
}
