#pragma once


#include "TSShapeBoxCtrl.h"


class CSCtrl_GAct : public CTSShapeBoxCtrl
{

	// Constructions and Destructions
public:

	CSCtrl_GAct( CNtlTSToolView* pParent );
	virtual ~CSCtrl_GAct( void );


	// Methods
public:

	virtual CTSShapeBox*				New( const CPoint& ptPos );
};
