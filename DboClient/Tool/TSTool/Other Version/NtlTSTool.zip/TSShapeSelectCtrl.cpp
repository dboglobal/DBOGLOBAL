#pragma once


#include "stdafx.h"
#include "TSShapeSelectCtrl.h"

#include "NtlTSToolDoc.h"
#include "NtlTSToolView.h"

#include "SCtrl_Link.h"


CTSShapeSelectCtrl::CTSShapeSelectCtrl( CNtlTSToolView* pParent )
: CTSShapeCtrl( pParent )
{
	m_eState = eSTATE_NONE;

	m_pLinkerCtrl = new CSCtrl_Link( pParent );

	m_pTSShapeHandling = NULL;

	m_bLock = false;
}


CTSShapeSelectCtrl::~CTSShapeSelectCtrl( void )
{
	if ( m_pLinkerCtrl )
	{
		delete m_pLinkerCtrl;
		m_pLinkerCtrl = NULL;
	}
}


void CTSShapeSelectCtrl::OnMouseLButtonDown( const CPoint& ptPos, UINT nFlags )
{
	if ( !m_pParent->GetDocument()->IsValidDocument() ) return;

	CTSShapeCtrl::OnMouseLButtonDown( ptPos, nFlags );

	if ( m_pParent->GetDocument()->GetSelectShape().GetCount() == 1 &&
		 m_pParent->GetDocument()->GetSelectShape().GetHead()->GetHandlerAt( ptPos ) != -1 )
	{
		m_pTSShapeHandling = m_pParent->GetDocument()->GetSelectShape().GetHead();

		m_pTSShapeHandling->BeginDrag( ptPos, m_pTSShapeHandling->GetHandlerAt( ptPos ) );

		m_eState = eSTATE_DRAGHANDLE;
	}
	else
	{
		CTSShape* pTSShape = m_pParent->GetDocument()->GetShapeAt( ptPos );

		if ( pTSShape )
		{
			if ( nFlags & MK_CONTROL )
			{
				if ( m_pParent->GetDocument()->IsSelectShape( pTSShape ) )
				{
					m_pParent->GetDocument()->UnselectShape( pTSShape );
				}
				else
				{
					m_pParent->GetDocument()->SelectShape( pTSShape, true );
				}
			}
			else
			{
				if ( !m_pParent->GetDocument()->IsSelectShape( pTSShape ) )
				{
					m_pParent->GetDocument()->SelectShape( pTSShape, false );
				}

				POSITION pos = m_pParent->GetDocument()->GetSelectShape().GetHeadPosition();
				while ( pos )
				{
					m_pParent->GetDocument()->GetSelectShape().GetNext( pos )->BeginDrag( m_pParent->Align2Grid( ptPos ) );
				}

				m_eState = eSTATE_DRAG;
			}
		}
		else
		{
			eLINKER_TYPE eLinkerType;
			CTSShape* pSrcShape;
			void* pLinkerInfo;

			if ( m_pParent->GetDocument()->GetShapeLinkInfoAt( ptPos, eLinkerType, pSrcShape, pLinkerInfo ) )
			{
				m_pLinkerCtrl->OnMouseLButtonDown( ptPos, nFlags, eLinkerType, pSrcShape, pLinkerInfo );

				m_eState = eSTATE_LINKERHANDLE;
			}
			else if ( (nFlags & MK_CONTROL) )
			{
				m_eState = eSTATE_NETSELECT;
			}
			else
			{
				m_pParent->GetDocument()->UnselectShape();
			}
		}
	}

	m_ptDown = ptPos;
	m_ptLastDown = ptPos;
}


void CTSShapeSelectCtrl::OnMouseLButtonUp( const CPoint& ptPos, UINT nFlags )
{
	if ( !m_pParent->GetDocument()->IsValidDocument() ) return;

	CTSShapeCtrl::OnMouseLButtonUp( ptPos, nFlags );

	if ( eSTATE_DRAGHANDLE == m_eState )
	{
		m_pTSShapeHandling->EndDrag();
	}
	else if ( eSTATE_DRAG == m_eState )
	{
		POSITION pos = m_pParent->GetDocument()->GetSelectShape().GetHeadPosition();
		while ( pos )
		{
			m_pParent->GetDocument()->GetSelectShape().GetNext( pos )->EndDrag();
		}
	}
	else if ( eSTATE_LINKERHANDLE == m_eState )
	{
		m_pLinkerCtrl->OnMouseLButtonUp( ptPos, nFlags );
	}
	else if ( eSTATE_NETSELECT == m_eState )
	{
		CClientDC dc( m_pParent );
		dc.DrawFocusRect( m_pParent->Doc2Device( CRect( m_ptDown, m_ptLastDown ) ) );
		m_pParent->GetDocument()->SelectShape( CRect( m_ptDown, ptPos ), true );
	}

	m_eState = eSTATE_NONE;
}


void CTSShapeSelectCtrl::OnMouseLButtonDoubleClick( const CPoint& ptPos, UINT nFlags )
{
	if ( !m_pParent->GetDocument()->IsValidDocument() ) return;

	CTSShapeCtrl::OnMouseLButtonDoubleClick( ptPos, nFlags );

	CTSShape* pTSShape = m_pParent->GetDocument()->GetShapeAt( ptPos );

	if ( pTSShape )
	{
		pTSShape->Activate( ptPos, true );
	}
}


void CTSShapeSelectCtrl::OnMouseRButtonDoubleClick( const CPoint& ptPos, UINT nFlags )
{
	if ( !m_pParent->GetDocument()->IsValidDocument() ) return;

	CTSShapeCtrl::OnMouseRButtonDoubleClick( ptPos, nFlags );

	CTSShape* pTSShape = m_pParent->GetDocument()->GetShapeAt( ptPos );

	if ( pTSShape )
	{
		pTSShape->Activate( ptPos, false );
	}
}


void CTSShapeSelectCtrl::OnMouseMove( const CPoint& ptPos, UINT nFlags )
{
	if ( !m_pParent->GetDocument()->IsValidDocument() ) return;

	CTSShapeCtrl::OnMouseMove( ptPos, nFlags );

	if ( eSTATE_DRAGHANDLE == m_eState && !m_bLock )
	{
		m_pTSShapeHandling->Drag( m_pParent->Align2Grid( ptPos ) );
	}
	else if ( eSTATE_DRAG == m_eState && !m_bLock )
	{
		POSITION pos = m_pParent->GetDocument()->GetSelectShape().GetHeadPosition();

		while ( pos )
		{
			m_pParent->GetDocument()->GetSelectShape().GetNext( pos )->Drag( m_pParent->Align2Grid( ptPos ) );
		}
	}
	else if ( eSTATE_LINKERHANDLE == m_eState )
	{
		m_pLinkerCtrl->OnMouseMove( ptPos, nFlags );
	}
	else if ( eSTATE_NETSELECT == m_eState )
	{
		CClientDC dc( m_pParent );
		dc.DrawFocusRect( m_pParent->Doc2Device( CRect( m_ptDown, m_ptLastDown ) ) );
		dc.DrawFocusRect( m_pParent->Doc2Device( CRect( m_ptDown, ptPos ) ) );
	}

	m_ptLastDown = ptPos;
}


void CTSShapeSelectCtrl::OnContextMenu( const CPoint& ptPos )
{
	if ( !m_pParent->GetDocument()->IsValidDocument() ) return;

	CTSShapeCtrl::OnContextMenu( ptPos );

	if ( eSTATE_LINKERHANDLE == m_eState )
	{
		m_pLinkerCtrl->OnContextMenu( ptPos );
	}
}


void CTSShapeSelectCtrl::OnDeactivate( void )
{
	CTSShapeCtrl::OnDeactivate();

	if ( eSTATE_LINKERHANDLE == m_eState )
	{
		m_pLinkerCtrl->OnDeactivate();
	}

	m_eState = eSTATE_NONE;
}
