// TSAttr_Trigger.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "NtlTSTool.h"
#include "TSAttr_Trigger.h"


// CTSAttr_Trigger ��ȭ �����Դϴ�.

IMPLEMENT_SERIAL(CTSAttr_Trigger, CTSAttr_Page, 1)

CTSAttr_Trigger::CTSAttr_Trigger()
	: CTSAttr_Page(CTSAttr_Trigger::IDD)
	, m_tID(NTL_TS_T_ID_INVALID)
	, m_uiTitle(0xffffffff)
{
}

CTSAttr_Trigger::~CTSAttr_Trigger()
{
}

CString CTSAttr_Trigger::CollectAttrDataFromDlgItems( void )
{
	CTSAttr_Page::CollectAttrDataFromDlgItems();

	CString strData;

	strData += MakeAttrData( _T("tid"), m_tID );
	strData += MakeAttrData( _T("rq"), m_ctrRepeat.GetCheck() == BST_CHECKED ? 1 : 0 );
	strData += MakeAttrData( _T("sq"), m_ctrCanShare.GetCheck() == BST_CHECKED ? 1 : 0 );
	strData += MakeAttrData( _T("title"), m_uiTitle );

	return strData;
}

void CTSAttr_Trigger::SettingAttrDataToDlgItems( CString& strKey, CString& strValue )
{
	if ( _T("tid") == strKey )
	{
		if ( strValue.IsEmpty() )
		{
			m_tID = NTL_TS_T_ID_INVALID;
		}
		else
		{
			m_tID = atoi( strValue.GetBuffer() );
		}
	}
	else if ( _T("rq") == strKey )
	{
		if ( strValue.IsEmpty() )
		{
			m_ctrRepeat.SetCheck( BST_UNCHECKED );
		}
		else
		{
			if ( atoi( strValue.GetBuffer() ) == 1 )
			{
				m_ctrRepeat.SetCheck( BST_CHECKED );
			}
			else
			{
				m_ctrRepeat.SetCheck( BST_UNCHECKED );
			}
		}
	}
	else if ( _T("sq") == strKey )
	{
		if ( strValue.IsEmpty() )
		{
			m_ctrCanShare.SetCheck( BST_CHECKED );
		}
		else
		{
			if ( atoi( strValue.GetBuffer() ) == 1 )
			{
				m_ctrCanShare.SetCheck( BST_CHECKED );
			}
			else
			{
				m_ctrCanShare.SetCheck( BST_UNCHECKED );
			}
		}
	}
	else if ( _T("title") == strKey )
	{
		if ( strValue.IsEmpty() )
		{
			m_uiTitle = 0xffffffff;
		}
		else
		{
			m_uiTitle = atoi( strValue.GetBuffer() );
		}
	}
}

void CTSAttr_Trigger::DoDataExchange(CDataExchange* pDX)
{
	CTSAttr_Page::DoDataExchange(pDX);

	DDX_Text(pDX, IDC_TS_TRIGGER_ATTR_ID_EDITOR, m_tID);
	DDV_MinMaxUInt(pDX, m_tID, 0, 65535);
	DDX_Text(pDX, IDC_TS_TRIGGER_ATTR_TITLE_EDITOR, m_uiTitle);
	DDV_MinMaxUInt(pDX, m_uiTitle, 0, 0xffffffff);
	DDX_Control(pDX, IDC_TS_TRIGGER_ATTR_REPEAT_QUEST_CHECK, m_ctrRepeat);
	DDX_Control(pDX, IDC_TS_TRIGGER_ATTR_SHARE_QUEST_CHECK, m_ctrCanShare);
}

BOOL CTSAttr_Trigger::OnInitDialog()
{
	CTSAttr_Page::OnInitDialog();

	// TODO:  ���⿡ �߰� �ʱ�ȭ �۾��� �߰��մϴ�.
	m_ctrRepeat.SetCheck( BST_UNCHECKED );
	m_ctrCanShare.SetCheck( BST_CHECKED );

	if ( m_strAllAttrData.GetLength() > 0 )
	{
		CTSAttr_Page::SettingAttrDataToDlgItems( m_strAllAttrData );
	}

	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}

BEGIN_MESSAGE_MAP(CTSAttr_Trigger, CTSAttr_Page)
END_MESSAGE_MAP()


// CTSAttr_Trigger �޽��� ó�����Դϴ�.
