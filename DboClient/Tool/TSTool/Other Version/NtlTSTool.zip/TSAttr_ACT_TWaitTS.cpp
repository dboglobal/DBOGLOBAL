// TSAttr_ACT_TWaitTS.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "NtlTSTool.h"
#include "TSAttr_ACT_TWaitTS.h"


// CTSAttr_ACT_TWaitTS ��ȭ �����Դϴ�.

IMPLEMENT_SERIAL(CTSAttr_ACT_TWaitTS, CTSAttr_Page, 1)

CTSAttr_ACT_TWaitTS::CTSAttr_ACT_TWaitTS()
	: CTSAttr_Page(CTSAttr_ACT_TWaitTS::IDD)
	, m_taID(NTL_TS_TA_ID_INVALID)
	, m_dwWTime(0xffffffff)
{

}

CTSAttr_ACT_TWaitTS::~CTSAttr_ACT_TWaitTS()
{
}

CString CTSAttr_ACT_TWaitTS::CollectAttrDataFromDlgItems( void )
{
	CTSAttr_Page::CollectAttrDataFromDlgItems();

	CString strData;

	strData += MakeAttrData( _T("taid"), m_taID );
	strData += MakeAttrData( _T("time"), m_dwWTime * 1000 );

	return strData;
}

void CTSAttr_ACT_TWaitTS::SettingAttrDataToDlgItems( CString& strKey, CString& strValue )
{
	if ( _T("taid") == strKey )
	{
		m_taID = atoi( strValue.GetBuffer() );
	}
	else if ( _T("time") == strKey )
	{
		m_dwWTime = atoi( strValue.GetBuffer() ) / 1000;
	}
}

void CTSAttr_ACT_TWaitTS::DoDataExchange(CDataExchange* pDX)
{
	CTSAttr_Page::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_TS_ACT_ATTR_TWAIT_ID_EDITOR, m_taID);
	DDV_MinMaxUInt(pDX, m_taID, 0, NTL_TS_TA_ID_INVALID);
	DDX_Text(pDX, IDC_TS_ACT_ATTR_TWAIT_WTIME_EDITOR, m_dwWTime);
}


BEGIN_MESSAGE_MAP(CTSAttr_ACT_TWaitTS, CTSAttr_Page)
END_MESSAGE_MAP()


// CTSAttr_ACT_TWaitTS �޽��� ó�����Դϴ�.
