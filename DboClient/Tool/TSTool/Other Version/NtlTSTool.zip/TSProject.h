#pragma once


class CTSProjectEntity;


class CTSProject : public CObject
{

	DECLARE_SERIAL( CTSProject )


// Member variables
protected:

	CString								m_strProjectDir;

	CString								m_strProjectHeader;
	DWORD								m_dwProjectVersion;

	CString								m_strProjectName;
	DWORD								m_dwProjectType;

	CArray< CString >					m_EntityFileList;
	CArray< CTSProjectEntity* >			m_EntityList;


// Constructions and Destructions
protected:

	CTSProject( void );


public:

	virtual ~CTSProject( void );


// Methods
public:

	CString								GetProjectDir( void ) const { return m_strProjectDir; }
	void								SetProjectDir( const CString& strProjectDir ) { m_strProjectDir = strProjectDir; }

	CString								GetProjectHeader( void ) const { return m_strProjectHeader; }

	DWORD								GetProjectVersion( void ) const { return m_dwProjectVersion; }
	void								SetProjectVersion( DWORD dwProjectVersion ) { m_dwProjectVersion = dwProjectVersion; }

	CString								GetProjectName( void ) const { return m_strProjectName; }
	void								SetProjectName( const CString& strProjectName ) { m_strProjectName = strProjectName; }

	DWORD								GetProjectType( void ) const { return m_dwProjectType; }
	void								SetProjectType( DWORD dwProjectType ) { m_dwProjectType = dwProjectType; }

	CTSProjectEntity*					CreateEntity( void );
	void								DeleteEntity( CTSProjectEntity*& pEntity );
	void								ClearAllEntity( void );

	const CArray< CString >&			GetEntityFileList( void ) const { return m_EntityFileList; }
	bool								LoadEntityFileList( const CString& strPath );
	bool								ReloadEntityFileList( void );
	void								UnloadEntityFileList( void );

	virtual void						Serialize( CArchive& ar );


// Implementations
protected:

	void								Save( CArchive& ar );

	bool								Load_Proj_Ver_00000000( CArchive& ar );
	bool								Load_Proj_Ver_00000001( CArchive& ar );

};


