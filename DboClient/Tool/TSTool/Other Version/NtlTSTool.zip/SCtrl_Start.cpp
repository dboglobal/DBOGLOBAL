#include "stdafx.h"
#include "SCtrl_Start.h"
#include "Shape_Start.h"

#include "NtlTSToolDoc.h"
#include "NtlTSToolView.h"


CSCtrl_Start::CSCtrl_Start( CNtlTSToolView* pParent )
: CTSShapeBoxCtrl( pParent )
{
}


CSCtrl_Start::~CSCtrl_Start( void )
{
}


CTSShapeBox* CSCtrl_Start::New( const CPoint& ptPos )
{
	CTSGroup* pGroup = m_pParent->GetDocument()->GetSelGroup();

	if ( NULL == pGroup )
	{
		ASSERT( !_T("A group must be selected.") );
		return NULL;
	}

	return new CShape_Start( ptPos, pGroup );
}
