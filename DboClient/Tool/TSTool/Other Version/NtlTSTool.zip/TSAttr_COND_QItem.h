#pragma once


#include "TSAttr_Page.h"


// CTSAttr_COND_QItem ��ȭ �����Դϴ�.

class CTSAttr_COND_QItem : public CTSAttr_Page
{
	DECLARE_SERIAL(CTSAttr_COND_QItem)

public:
	CTSAttr_COND_QItem();
	virtual ~CTSAttr_COND_QItem();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_TS_COND_QITEM_ATTR_DIAG };

protected:
	virtual CString	CollectAttrDataFromDlgItems( void );
	virtual void	SettingAttrDataToDlgItems( CString& strKey, CString& strValue );

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()

public:
	DWORD m_dwItemIdx;
	int m_nItemCnt;
};
