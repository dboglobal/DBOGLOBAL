// TSAttr_COND_ClrQst.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "NtlTSTool.h"
#include "TSAttr_COND_ClrQst.h"


// CTSAttr_COND_ClrQst ��ȭ �����Դϴ�.

IMPLEMENT_SERIAL(CTSAttr_COND_ClrQst, CTSAttr_Page, 1)

CTSAttr_COND_ClrQst::CTSAttr_COND_ClrQst()
	: CTSAttr_Page(CTSAttr_COND_ClrQst::IDD)
	, m_strAndList(_T(""))
	, m_strOrList(_T(""))
{

}

CTSAttr_COND_ClrQst::~CTSAttr_COND_ClrQst()
{
}

CString CTSAttr_COND_ClrQst::CollectAttrDataFromDlgItems( void )
{
	CTSAttr_Page::CollectAttrDataFromDlgItems();

	CString strData;

	strData += MakeAttrData( _T("and"), m_strAndList );
	strData += MakeAttrData( _T("or"), m_strOrList );

	return strData;
}

void CTSAttr_COND_ClrQst::SettingAttrDataToDlgItems( CString& strKey, CString& strValue )
{
	if ( _T("and") == strKey )
	{
		m_strAndList = strValue.GetBuffer();
	}
	else if ( _T("or") == strKey )
	{
		m_strOrList = strValue.GetBuffer();
	}
}

void CTSAttr_COND_ClrQst::DoDataExchange(CDataExchange* pDX)
{
	CTSAttr_Page::DoDataExchange(pDX);

	DDX_Text(pDX, IDC_TS_COND_ATTR_CLRQST_ANDLIST_EDITOR, m_strAndList);
	DDX_Text(pDX, IDC_TS_COND_ATTR_CLRQST_ORLIST_EDITOR, m_strOrList);
}


BEGIN_MESSAGE_MAP(CTSAttr_COND_ClrQst, CTSAttr_Page)
END_MESSAGE_MAP()


// CTSAttr_COND_ClrQst �޽��� ó�����Դϴ�.
