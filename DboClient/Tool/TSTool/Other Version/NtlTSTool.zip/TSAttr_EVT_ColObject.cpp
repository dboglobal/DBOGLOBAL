// TSAttr_EVT_ColObject.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "NtlTSTool.h"
#include "TSAttr_EVT_ColObject.h"


// CTSAttr_EVT_ColObject ��ȭ �����Դϴ�.

IMPLEMENT_SERIAL(CTSAttr_EVT_ColObject, CTSAttr_Page, 1)

CTSAttr_EVT_ColObject::CTSAttr_EVT_ColObject(CWnd* pParent /*=NULL*/)
	: CTSAttr_Page(CTSAttr_EVT_ColObject::IDD)
	, m_dwWorldIdx( 0xffffffff )
{

}

CTSAttr_EVT_ColObject::~CTSAttr_EVT_ColObject()
{
}

CString CTSAttr_EVT_ColObject::CollectAttrDataFromDlgItems( void )
{
	CTSAttr_Page::CollectAttrDataFromDlgItems();

	CString strData;

	strData += MakeAttrData( _T("widx"), m_dwWorldIdx );
	strData += MakeAttrData( _T("objidx"), m_strObjectIdx );

	return strData;
}

void CTSAttr_EVT_ColObject::SettingAttrDataToDlgItems( CString& strKey, CString& strValue )
{
	if ( _T("widx") == strKey )
	{
		m_dwWorldIdx = atoi( strValue.GetBuffer() );
	}
	if ( _T("objidx") == strKey )
	{
		m_strObjectIdx = strValue;
	}
}

void CTSAttr_EVT_ColObject::DoDataExchange(CDataExchange* pDX)
{
	CTSAttr_Page::DoDataExchange(pDX);

	DDX_Text(pDX, IDC_TS_EVT_ATTR_COL_WORLDIDX_EDITOR, m_dwWorldIdx);
	DDX_Text(pDX, IDC_TS_EVT_ATTR_COL_OBJIDX_EDITOR, m_strObjectIdx);
}


BEGIN_MESSAGE_MAP(CTSAttr_EVT_ColObject, CTSAttr_Page)
END_MESSAGE_MAP()


// CTSAttr_EVT_ColObject �޽��� ó�����Դϴ�.
