#pragma once


#include "stdafx.h"
#include "TSShapeBoxCtrl.h"
#include "TSShapeBox.h"

#include "NtlTSToolDoc.h"
#include "NtlTSToolView.h"


CTSShapeBoxCtrl::CTSShapeBoxCtrl( CNtlTSToolView* pParent )
: CTSShapeCtrl( pParent )
{
	m_pShapeBox = NULL;
}


CTSShapeBoxCtrl::~CTSShapeBoxCtrl( void )
{
}


void CTSShapeBoxCtrl::OnMouseLButtonDown( const CPoint& ptPos, UINT nFlags )
{
	if ( !m_pParent->GetDocument()->IsValidDocument() ) return;

	CTSShapeCtrl::OnMouseLButtonDown( ptPos, nFlags );

	ASSERT( NULL == m_pShapeBox );

	m_pShapeBox = New( m_pParent->Align2Grid( ptPos ) );

	m_pParent->GetDocument()->AddShape( m_pShapeBox );

	m_pParent->GetDocument()->SelectShape( m_pShapeBox, false );
}


void CTSShapeBoxCtrl::OnMouseLButtonUp( const CPoint& ptPos, UINT nFlags )
{
	if ( !m_pParent->GetDocument()->IsValidDocument() ) return;

	CTSShapeCtrl::OnMouseLButtonUp( ptPos, nFlags );

	if ( m_pShapeBox )
	{
		m_pShapeBox = NULL;
	}
}


void CTSShapeBoxCtrl::OnMouseLButtonDoubleClick( const CPoint& ptPos, UINT nFlags )
{
	if ( !m_pParent->GetDocument()->IsValidDocument() ) return;

	CTSShapeCtrl::OnMouseLButtonDoubleClick( ptPos, nFlags );
}


void CTSShapeBoxCtrl::OnMouseRButtonDoubleClick( const CPoint& ptPos, UINT nFlags )
{
	if ( !m_pParent->GetDocument()->IsValidDocument() ) return;

	CTSShapeCtrl::OnMouseRButtonDoubleClick( ptPos, nFlags );
}


void CTSShapeBoxCtrl::OnMouseMove( const CPoint& ptPos, UINT nFlags )
{
	if ( !m_pParent->GetDocument()->IsValidDocument() ) return;

	CTSShapeCtrl::OnMouseMove( ptPos, nFlags );
}


void CTSShapeBoxCtrl::OnContextMenu( const CPoint& ptPos )
{
	if ( !m_pParent->GetDocument()->IsValidDocument() ) return;

	CTSShapeCtrl::OnContextMenu( ptPos );
}


void CTSShapeBoxCtrl::OnDeactivate( void )
{
	CTSShapeCtrl::OnDeactivate();

	if ( m_pShapeBox )
	{
		m_pShapeBox = NULL;
	}
}


CTSShapeBox* CTSShapeBoxCtrl::New( const CPoint& ptPos )
{
	CTSGroup* pGroup = m_pParent->GetDocument()->GetSelGroup();

	if ( NULL == pGroup )
	{
		ASSERT( !_T("A group must be selected.") );
		return NULL;
	}

	return new CTSShapeBox( ptPos, pGroup );
}
