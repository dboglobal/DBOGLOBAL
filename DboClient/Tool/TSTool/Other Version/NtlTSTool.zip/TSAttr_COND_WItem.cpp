// TSAttr_COND_WItem.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "NtlTSTool.h"
#include "TSAttr_COND_WItem.h"


// CTSAttr_COND_WItem ��ȭ �����Դϴ�.

IMPLEMENT_SERIAL(CTSAttr_COND_WItem, CTSAttr_Page, 1)

CTSAttr_COND_WItem::CTSAttr_COND_WItem()
	: CTSAttr_Page(CTSAttr_COND_WItem::IDD)
	, m_dwItemIdx(0xffffffff)
{

}

CTSAttr_COND_WItem::~CTSAttr_COND_WItem()
{
}

CString CTSAttr_COND_WItem::CollectAttrDataFromDlgItems( void )
{
	CTSAttr_Page::CollectAttrDataFromDlgItems();

	UpdateData( true );

	CString strData;

	strData += MakeAttrData( _T("iidx"), m_dwItemIdx );

	return strData;
}

void CTSAttr_COND_WItem::SettingAttrDataToDlgItems( CString& strKey, CString& strValue )
{
	if ( _T("iidx") == strKey )
	{
		m_dwItemIdx = atoi( strValue.GetBuffer() );
	}
}

void CTSAttr_COND_WItem::DoDataExchange(CDataExchange* pDX)
{
	CTSAttr_Page::DoDataExchange(pDX);

	DDX_Text(pDX, IDC_TS_COND_ATTR_WITEM_ITEMIDX_EDITOR, m_dwItemIdx);
}


BEGIN_MESSAGE_MAP(CTSAttr_COND_WItem, CTSAttr_Page)
END_MESSAGE_MAP()


// CTSAttr_COND_WItem �޽��� ó�����Դϴ�.
