#pragma once


#include "TSAttr_Page.h"


// CTSAttr_CONT_Reward ��ȭ �����Դϴ�.

class CTSAttr_CONT_Reward : public CTSAttr_Page
{
	DECLARE_SERIAL(CTSAttr_CONT_Reward)

public:
	CTSAttr_CONT_Reward();
	virtual ~CTSAttr_CONT_Reward();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_TS_CONT_REWARD_ATTR_DIAG };

	virtual CString	CollectAttrDataFromDlgItems( void );
	virtual void	SettingAttrDataToDlgItems( CString& strKey, CString& strValue );

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.
	virtual BOOL OnInitDialog();

	DECLARE_MESSAGE_MAP()
public:
	DWORD m_tcID;
	DWORD m_uiDesc;

	CComboBox m_ctrDefRwdType0;
	DWORD m_dwDefIndex0;
	int m_nDefValue0;

	CComboBox m_ctrDefRwdType1;
	DWORD m_dwDefIndex1;
	int m_nDefValue1;

	CComboBox m_ctrDefRwdType2;
	DWORD m_dwDefIndex2;
	int m_nDefValue2;

	CComboBox m_ctrDefRwdType3;
	DWORD m_dwDefIndex3;
	int m_nDefValue3;

	CComboBox m_ctrSelRwdType0;
	DWORD m_dwSelIndex0;
	int m_nSelValue0;

	CComboBox m_ctrSelRwdType1;
	DWORD m_dwSelIndex1;
	int m_nSelValue1;

	CComboBox m_ctrSelRwdType2;
	DWORD m_dwSelIndex2;
	int m_nSelValue2;

	CComboBox m_ctrSelRwdType3;
	DWORD m_dwSelIndex3;
	int m_nSelValue3;
};
