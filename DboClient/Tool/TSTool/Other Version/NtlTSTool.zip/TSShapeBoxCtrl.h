#pragma once


#include "TSShapeCtrl.h"


class CTSShapeBox;


class CTSShapeBoxCtrl : public CTSShapeCtrl
{

// Member variables
protected:

	CTSShapeBox*						m_pShapeBox;


// Constructions and Destructions
public:

	CTSShapeBoxCtrl( CNtlTSToolView* pParent );
	virtual ~CTSShapeBoxCtrl( void );


// Methods
public:

	virtual void						OnMouseLButtonDown( const CPoint& ptPos, UINT nFlags );
	virtual void						OnMouseLButtonUp( const CPoint& ptPos, UINT nFlags );
	virtual void						OnMouseLButtonDoubleClick( const CPoint& ptPos, UINT nFlags );
	virtual void						OnMouseRButtonDoubleClick( const CPoint &point, UINT nFlags );
	virtual void						OnMouseMove( const CPoint& ptPos, UINT nFlags );

	virtual void						OnContextMenu( const CPoint& ptPos );
	virtual void						OnDeactivate( void );


// Implementations
protected:

	virtual CTSShapeBox*				New( const CPoint& ptPos );

};
