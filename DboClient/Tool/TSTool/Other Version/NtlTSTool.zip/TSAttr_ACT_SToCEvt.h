#pragma once


#include "afxwin.h"
#include "TSAttr_Page.h"


// CTSAttr_ACT_SToCEvt ��ȭ �����Դϴ�.

class CTSAttr_ACT_SToCEvt : public CTSAttr_Page
{
	DECLARE_SERIAL(CTSAttr_ACT_SToCEvt)

public:
	CTSAttr_ACT_SToCEvt();
	virtual ~CTSAttr_ACT_SToCEvt();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_TS_ACT_STOCEVT_ATTR_DIAG };

protected:
	virtual CString	CollectAttrDataFromDlgItems( void );
	virtual void	SettingAttrDataToDlgItems( CString& strKey, CString& strValue );

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.
	virtual BOOL OnInitDialog();

	DECLARE_MESSAGE_MAP()

public:
	DWORD m_taID;
	CButton m_ctrStartBtn;
	CButton m_ctrEndBtn;
	CComboBox m_ctrSvrEvtType;
	DWORD m_dwIndex1;
	int m_nCount1;
	DWORD m_dwIndex2;
	int m_nCount2;
	DWORD m_dwIndex3;
	int m_nCount3;

public:
	afx_msg void OnBnClickedTsActAttrStocevtStartCheck();
	afx_msg void OnBnClickedTsActAttrStocevtEndCheck();
};
