#pragma once


#include "TSShapeBox.h"


class CShape_End : public CTSShapeBox
{

	DECLARE_SERIAL( CShape_End )


// Member variables
protected:


// Constructions and Destructions
protected:
	CShape_End( void );

public:
	CShape_End( const CPoint& ptPos, CTSGroup* pParent );
	virtual ~CShape_End( void );


// Methods
public:

	// Serialize

	virtual void						Serialize( CArchive &ar );


// Implementations
protected:

	virtual	void						ShowContainerEntityAttributeAddDlg( int nGroupID );

	void								Save( CArchive& ar );

	bool								Load_Trig_Ver_00000000( CArchive& ar );
	bool								Load_Trig_Ver_00000001( CArchive& ar );

};