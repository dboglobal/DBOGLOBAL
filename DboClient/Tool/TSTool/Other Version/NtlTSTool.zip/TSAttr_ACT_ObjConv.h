#pragma once


#include "afxwin.h"
#include "TSAttr_Page.h"


// CTSAttr_ACT_ObjConv ��ȭ �����Դϴ�.

class CTSAttr_ACT_ObjConv : public CTSAttr_Page
{
	DECLARE_SERIAL(CTSAttr_ACT_ObjConv)

public:
	CTSAttr_ACT_ObjConv();
	virtual ~CTSAttr_ACT_ObjConv();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_TS_ACT_OBJCONV_ATTR_DIAG };

protected:
	virtual CString	CollectAttrDataFromDlgItems( void );
	virtual void	SettingAttrDataToDlgItems( CString& strKey, CString& strValue );

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.
	virtual BOOL OnInitDialog();

	DECLARE_MESSAGE_MAP()

public:
	DWORD m_taID;
	CComboBox m_ctrConvType;
	DWORD m_dwWorldIdx;
	DWORD m_dwObjIdx;
	DWORD m_uiConv;
};
