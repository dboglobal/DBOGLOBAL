#include "stdafx.h"
#include "TSProjectEntity.h"

#include "NtlTSToolDoc.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#endif


static const CString PROJECT_ENTITY_FILE_HEADER = _T("NTL_TRIGGER_SYSTEM_PROJECT_ENTITY_HEADER");


CTSGroup* CTSGroup::s_pTempLoadGroup = NULL;


IMPLEMENT_SERIAL( CTSGroup, CObject, 1 )


CTSGroup::CTSGroup( void )
{
	m_pParent = NULL;
	m_byGroupID = 0xff;
}


CTSGroup::~CTSGroup( void )
{
	ClearAll();
}


void CTSGroup::RaiseUp( CTSShape* pShape )
{
	CTSShape* pRetShape;
	POSITION Pos, OldPos;

	for ( Pos = m_NoteLayer.GetTailPosition(); Pos != NULL; )
	{
		OldPos = Pos;

		pRetShape = m_NoteLayer.GetPrev( Pos );

		if ( pRetShape == pShape )
		{
			m_NoteLayer.RemoveAt( OldPos );
			m_NoteLayer.AddTail( pShape );

			return;
		}
	}

	for ( Pos = m_ContainerLayer.GetTailPosition(); Pos != NULL; )
	{
		OldPos = Pos;

		pRetShape = m_ContainerLayer.GetPrev( Pos );

		if ( pRetShape == pShape )
		{
			m_ContainerLayer.RemoveAt( OldPos );
			m_ContainerLayer.AddTail( pShape );

			return;
		}
	}

	for ( Pos = m_LinkLayer.GetTailPosition(); Pos != NULL; )
	{
		OldPos = Pos;

		pRetShape = m_NoteLayer.GetPrev( Pos );

		if ( pRetShape == pShape )
		{
			m_LinkLayer.RemoveAt( OldPos );
			m_LinkLayer.AddTail( pShape );

			return;
		}
	}
}


void CTSGroup::ClearAll( void )
{
	for ( POSITION Pos = m_LinkLayer.GetTailPosition(); Pos != NULL; )
	{
		CTSShape* pShape = m_LinkLayer.GetPrev( Pos );
		delete pShape;
	}
	m_LinkLayer.RemoveAll();

	for ( POSITION Pos = m_ContainerLayer.GetTailPosition(); Pos != NULL; )
	{
		CTSShape* pShape = m_ContainerLayer.GetPrev( Pos );
		delete pShape;
	}
	m_ContainerLayer.RemoveAll();

	for ( POSITION Pos = m_NoteLayer.GetTailPosition(); Pos != NULL; )
	{
		CTSShape* pShape = m_NoteLayer.GetPrev( Pos );
		delete pShape;
	}
	m_NoteLayer.RemoveAll();
}


void CTSGroup::Serialize( CArchive& ar )
{
	CObject::Serialize( ar );

	if ( ar.IsStoring() )
	{
		Save( ar );
	}
	else
	{
		ClearAll();

		switch ( m_pParent->GetParent()->GetProjectEntityVersion() )
		{
		case 0:
			if ( !Load_Trig_Ver_00000000( ar ) )
			{
				return;
			}
			break;

		case 1:
			if ( !Load_Trig_Ver_00000001( ar ) )
			{
				return;
			}
			break;

		default:
			ASSERT( !_T("The version of its project entity file is wrong.") );
			return;
		}
	}
}


void CTSGroup::Save( CArchive& ar )
{
	m_LinkLayer.Serialize( ar );
	m_ContainerLayer.Serialize( ar );
	m_NoteLayer.Serialize( ar );
}


bool CTSGroup::Load_Trig_Ver_00000000( CArchive& ar )
{
	s_pTempLoadGroup = this;

	m_LinkLayer.Serialize( ar );
	m_ContainerLayer.Serialize( ar );
	m_NoteLayer.Serialize( ar );

	s_pTempLoadGroup = NULL;

	return true;
}


bool CTSGroup::Load_Trig_Ver_00000001( CArchive& ar )
{
	s_pTempLoadGroup = this;

	m_LinkLayer.Serialize( ar );
	m_ContainerLayer.Serialize( ar );
	m_NoteLayer.Serialize( ar );

	s_pTempLoadGroup = NULL;

	return true;
}


IMPLEMENT_SERIAL( CTSTrigger, CObject, 1 )


CTSTrigger::CTSTrigger( void )
{
	m_pParent = NULL;
}


CTSTrigger::~CTSTrigger( void )
{
	ClearAll();
}


CTSGroup* CTSTrigger::GetGroup( BYTE byGroupID ) const
{
	for ( int i = 0; i < m_GroupList.GetCount(); ++i )
	{
		if ( m_GroupList[i]->GetGroupID() == byGroupID )
		{
			return m_GroupList[i];
		}
	}

	return NULL;
}


CTSGroup* CTSTrigger::CreateGroup( BYTE byGroupID )
{
	ASSERT( 0xff != byGroupID );

	CTSGroup* pGroup = GetGroup( byGroupID );
	if ( pGroup )
	{
		ASSERT( !_T("The group id already exists") );
		return pGroup;
	}

	pGroup = DYNAMIC_DOWNCAST( CTSGroup, CTSGroup::CreateObject() );

	ASSERT( pGroup );

	pGroup->SetParent( this );
	pGroup->SetGroupID( byGroupID );

	m_GroupList.Add( pGroup );

	return pGroup;
}


void CTSTrigger::DeleteGroup( BYTE byGroupID )
{
	for ( int i = 0; i < m_GroupList.GetCount(); ++i )
	{
		if ( m_GroupList[i]->GetGroupID() == byGroupID )
		{
			delete m_GroupList[i];

			m_GroupList.RemoveAt( i );

			return;
		}
	}
}


void CTSTrigger::DeleteGroup( CTSGroup*& pGroup )
{
	for ( int i = 0; i < m_GroupList.GetCount(); ++i )
	{
		if ( m_GroupList[i] == pGroup )
		{
			delete m_GroupList[i];

			m_GroupList.RemoveAt( i );

			pGroup = NULL;

			return;
		}
	}
}


void CTSTrigger::DeleteAllGroup( void )
{
	for ( int i = 0; i < m_GroupList.GetCount(); ++i )
	{
		delete m_GroupList[i];
	}

	m_GroupList.RemoveAll();
}


void CTSTrigger::ClearAll( void )
{
	m_strAttr.Empty();

	DeleteAllGroup();
}


void CTSTrigger::Serialize( CArchive& ar )
{
	CObject::Serialize( ar );

	if ( ar.IsStoring() )
	{
		Save( ar );
	}
	else
	{
		ClearAll();

		switch ( m_pParent->GetProjectEntityVersion() )
		{
		case 0:
			if ( !Load_Trig_Ver_00000000( ar ) )
			{
				return;
			}
			break;

		case 1:
			if ( !Load_Trig_Ver_00000001( ar ) )
			{
				return;
			}
			break;

		default:
			ASSERT( !_T("The version of its project entity file is wrong.") );
			return;
		}
	}
}


void CTSTrigger::Save( CArchive& ar )
{
	// Trigger attribute

	ar << m_strAttr;

	// Group

	ar << (int)m_GroupList.GetSize();

	for ( int i = 0; i < (int)m_GroupList.GetSize(); ++i )
	{
		ar << m_GroupList[i]->GetGroupID();

		m_GroupList[i]->Serialize( ar );
	}
}


bool CTSTrigger::Load_Trig_Ver_00000000( CArchive& ar )
{
	// Trigger attribute

	ar >> m_strAttr;

	// Main group

	bool bMainGroup;
	ar >> bMainGroup;

	if ( bMainGroup )
	{
		CreateGroup( 0 )->Serialize( ar );
	}

	// Except group

	int nExceptGroupCnt;
	ar >> nExceptGroupCnt;

	BYTE byGroupID;
	for ( int i = 0; i < nExceptGroupCnt; ++i )
	{
		ar >> byGroupID;

		CreateGroup( byGroupID )->Serialize( ar );
	}

	return true;
}


bool CTSTrigger::Load_Trig_Ver_00000001( CArchive& ar )
{
	// Trigger attribute

	ar >> m_strAttr;

	// Group

	int GroupCnt;
	ar >> GroupCnt;

	BYTE byGroupID;
	for ( int i = 0; i < GroupCnt; ++i )
	{
		ar >> byGroupID;

		CreateGroup( byGroupID )->Serialize( ar );
	}

	return true;
}


IMPLEMENT_SERIAL( CTSProjectEntity, CObject, 1 )


CTSProjectEntity::CTSProjectEntity( void )
{
	m_dwProjectEntityVersion = 0;

	m_pTrigger = DYNAMIC_DOWNCAST( CTSTrigger, CTSTrigger::CreateObject() );
	ASSERT( m_pTrigger );

	m_pTrigger->SetParent( this );
}


CTSProjectEntity::~CTSProjectEntity( void )
{
	ClearAll();

	if ( m_pTrigger )
	{
		delete m_pTrigger;
		m_pTrigger = NULL;
	}
}


void CTSProjectEntity::ClearAll( void )
{
	m_strProjectEntityHeader.Empty();
	m_dwProjectEntityVersion = 0;

	m_pTrigger->ClearAll();
}


void CTSProjectEntity::Serialize( CArchive& ar )
{
	CObject::Serialize( ar );

	if ( ar.IsStoring() )
	{
		Save( ar );
	}
	else
	{
		ClearAll();

		// Load the project entity file version

		ar >> m_dwProjectEntityVersion;

		// Load the project entity informations

		switch ( m_dwProjectEntityVersion )
		{
		case 0:
			if ( !Load_Trig_Ver_00000000( ar ) )
			{
				return;
			}
			break;

		case 1:
			if ( !Load_Trig_Ver_00000001( ar ) )
			{
				return;
			}
			break;

		default:
			ASSERT( !_T("The version of its project entity file is wrong.") );
			return;
		}
	}
}


void CTSProjectEntity::Save( CArchive& ar )
{
	// Save the project entity file version

	ar << TS_PROJECT_ENTITY_FILE_VERSION;

	// Save the project entity file header

	ar << PROJECT_ENTITY_FILE_HEADER;

	// Save the project entity informations

	m_pTrigger->Serialize( ar );
}


bool CTSProjectEntity::Load_Trig_Ver_00000000( CArchive& ar )
{
	// Load the project entity informations

	m_pTrigger->Serialize( ar );

	return true;
}


bool CTSProjectEntity::Load_Trig_Ver_00000001( CArchive& ar )
{
	// Load the project entity file header

	ar >> m_strProjectEntityHeader;

	if ( PROJECT_ENTITY_FILE_HEADER != m_strProjectEntityHeader )
	{
		ASSERT( !_T("It is not the TS project entity file.") );
		return false;
	}

	// Load the project entity informations

	m_pTrigger->Serialize( ar );

	return true;
}