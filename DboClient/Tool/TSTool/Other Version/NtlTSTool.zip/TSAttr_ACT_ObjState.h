#pragma once


#include "afxwin.h"
#include "TSAttr_Page.h"


// CTSAttr_ACT_ObjState ��ȭ �����Դϴ�.

class CTSAttr_ACT_ObjState : public CTSAttr_Page
{
	DECLARE_SERIAL(CTSAttr_ACT_ObjState)

public:
	CTSAttr_ACT_ObjState();
	virtual ~CTSAttr_ACT_ObjState();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_TS_ACT_OBJSTATE_ATTR_DIAG };

protected:
	virtual CString	CollectAttrDataFromDlgItems( void );
	virtual void	SettingAttrDataToDlgItems( CString& strKey, CString& strValue );

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.
	virtual BOOL OnInitDialog();

	DECLARE_MESSAGE_MAP()

public:
	DWORD m_taID;
	DWORD m_dwWorldIdx;
	DWORD m_dwObjectIdx;
	CComboBox m_ctrMainState;
	CComboBox m_ctrObjShowHide;
};
