// TSAttr_ACT_ETimerE.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "NtlTSTool.h"
#include "TSAttr_ACT_ETimerE.h"


// CTSAttr_ACT_ETimerE ��ȭ �����Դϴ�.

IMPLEMENT_SERIAL(CTSAttr_ACT_ETimerE, CTSAttr_Page, 1)

CTSAttr_ACT_ETimerE::CTSAttr_ACT_ETimerE()
	: CTSAttr_Page(CTSAttr_ACT_ETimerE::IDD)
	, m_taID( NTL_TS_TA_ID_INVALID )
	, m_tcEID( NTL_TS_TC_ID_INVALID )
	, m_taEID( NTL_TS_TA_ID_INVALID )
{

}

CTSAttr_ACT_ETimerE::~CTSAttr_ACT_ETimerE()
{
}

CString CTSAttr_ACT_ETimerE::CollectAttrDataFromDlgItems( void )
{
	CTSAttr_Page::CollectAttrDataFromDlgItems();

	CString strData;

	strData += MakeAttrData( _T("taid"), m_taID );
	strData += MakeAttrData( _T("tceid"), m_tcEID );
	strData += MakeAttrData( _T("taeid"), m_taEID );

	return strData;
}

void CTSAttr_ACT_ETimerE::SettingAttrDataToDlgItems( CString& strKey, CString& strValue )
{
	if ( _T("taid") == strKey )
	{
		m_taID = atoi( strValue.GetBuffer() );
	}

	if ( _T("tceid") == strKey )
	{
		m_tcEID = atoi( strValue.GetBuffer() );
	}

	if ( _T("taeid") == strKey )
	{
		m_taEID = atoi( strValue.GetBuffer() );
	}
}

void CTSAttr_ACT_ETimerE::DoDataExchange(CDataExchange* pDX)
{
	CTSAttr_Page::DoDataExchange(pDX);

	DDX_Text(pDX, IDC_TS_ACT_ATTR_EXCEPTTIMER_E_ID_EDITOR, m_taID);
	DDV_MinMaxUInt(pDX, m_taID, 0, NTL_TS_TA_ID_INVALID);
	DDX_Text(pDX, IDC_TS_ACT_ATTR_EXCEPTTIMER_E_TCID_EDITOR, m_tcEID);
	DDV_MinMaxUInt(pDX, m_tcEID, 0, NTL_TS_TC_ID_INVALID);
	DDX_Text(pDX, IDC_TS_ACT_ATTR_EXCEPTTIMER_E_TAID_EDITOR, m_taEID);
	DDV_MinMaxUInt(pDX, m_taEID, 0, NTL_TS_TA_ID_INVALID);
}

BOOL CTSAttr_ACT_ETimerE::OnInitDialog()
{
	CTSAttr_Page::OnInitDialog();

	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}


BEGIN_MESSAGE_MAP(CTSAttr_ACT_ETimerE, CTSAttr_Page)
END_MESSAGE_MAP()


// CTSAttr_ACT_ETimerE �޽��� ó�����Դϴ�.
