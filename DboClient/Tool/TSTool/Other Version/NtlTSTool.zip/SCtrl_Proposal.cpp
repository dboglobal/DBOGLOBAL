#include "stdafx.h"
#include "SCtrl_Proposal.h"
#include "Shape_Proposal.h"

#include "NtlTSToolDoc.h"
#include "NtlTSToolView.h"


CSCtrl_Proposal::CSCtrl_Proposal( CNtlTSToolView* pParent )
: CTSShapeBoxCtrl( pParent )
{
}


CSCtrl_Proposal::~CSCtrl_Proposal( void )
{
}


CTSShapeBox* CSCtrl_Proposal::New( const CPoint& ptPos )
{
	CTSGroup* pGroup = m_pParent->GetDocument()->GetSelGroup();

	if ( NULL == pGroup )
	{
		ASSERT( !_T("A group must be selected.") );
		return NULL;
	}

	return new CShape_Proposal( ptPos, pGroup );
}
