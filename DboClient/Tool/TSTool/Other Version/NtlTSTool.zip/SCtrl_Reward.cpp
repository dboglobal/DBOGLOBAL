#include "stdafx.h"
#include "SCtrl_Reward.h"
#include "Shape_Reward.h"

#include "NtlTSToolDoc.h"
#include "NtlTSToolView.h"


CSCtrl_Reward::CSCtrl_Reward( CNtlTSToolView* pParent )
: CTSShapeBoxCtrl( pParent )
{
}


CSCtrl_Reward::~CSCtrl_Reward( void )
{
}


CTSShapeBox* CSCtrl_Reward::New( const CPoint& ptPos )
{
	CTSGroup* pGroup = m_pParent->GetDocument()->GetSelGroup();

	if ( NULL == pGroup )
	{
		ASSERT( !_T("A group must be selected.") );
		return NULL;
	}

	return new CShape_Reward( ptPos, pGroup );
}
