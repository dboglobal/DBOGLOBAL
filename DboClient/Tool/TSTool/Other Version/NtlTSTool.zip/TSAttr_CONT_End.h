#pragma once


#include "TSAttr_Page.h"
#include "afxwin.h"


// CTSAttr_CONT_End ��ȭ �����Դϴ�.

class CTSAttr_CONT_End : public CTSAttr_Page
{
	DECLARE_SERIAL(CTSAttr_CONT_End)

public:
	CTSAttr_CONT_End();
	virtual ~CTSAttr_CONT_End();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_TS_CONT_END_ATTR_DIAG };

protected:
	virtual CString	CollectAttrDataFromDlgItems( void );
	virtual void	SettingAttrDataToDlgItems( CString& strKey, CString& strValue );

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.
	virtual BOOL OnInitDialog();

	DECLARE_MESSAGE_MAP()

public:
	DWORD m_tcID;
	CComboBox m_ctlEndType;
};
