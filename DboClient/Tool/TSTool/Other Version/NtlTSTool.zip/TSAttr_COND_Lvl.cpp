// TSAttr_COND_Lvl.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "NtlTSTool.h"
#include "TSAttr_COND_Lvl.h"


// CTSAttr_COND_Lvl ��ȭ �����Դϴ�.

IMPLEMENT_SERIAL(CTSAttr_COND_Lvl, CTSAttr_Page, 1)

CTSAttr_COND_Lvl::CTSAttr_COND_Lvl()
	: CTSAttr_Page(CTSAttr_COND_Lvl::IDD)
	, m_nMinLevel(0)
	, m_nMaxLevel(0)
{

}

CTSAttr_COND_Lvl::~CTSAttr_COND_Lvl()
{
}

CString CTSAttr_COND_Lvl::CollectAttrDataFromDlgItems( void )
{
	CTSAttr_Page::CollectAttrDataFromDlgItems();

	CString strData;

	strData += MakeAttrData( _T("minlvl"), m_nMinLevel );
	strData += MakeAttrData( _T("maxlvl"), m_nMaxLevel );

	return strData;
}

void CTSAttr_COND_Lvl::SettingAttrDataToDlgItems( CString& strKey, CString& strValue )
{
	if ( _T("minlvl") == strKey )
	{
		m_nMinLevel = atoi( strValue.GetBuffer() );
	}
	else if ( _T("maxlvl") == strKey )
	{
		m_nMaxLevel = atoi( strValue.GetBuffer() );
	}
}

void CTSAttr_COND_Lvl::DoDataExchange(CDataExchange* pDX)
{
	CTSAttr_Page::DoDataExchange(pDX);

	DDX_Text(pDX, IDC_TS_COND_ATTR_LVL_MIN_EDITOR, m_nMinLevel);
	DDX_Text(pDX, IDC_TS_COND_ATTR_LVL_MAX_EDITOR, m_nMaxLevel);
}


BEGIN_MESSAGE_MAP(CTSAttr_COND_Lvl, CTSAttr_Page)
END_MESSAGE_MAP()


// CTSAttr_COND_Lvl �޽��� ó�����Դϴ�.
