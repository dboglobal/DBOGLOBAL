// NtlTSToolDoc.cpp : implementation of the CNtlTSToolDoc class
//

#include "stdafx.h"
#include "NtlTSTool.h"

#include "NtlTSToolDoc.h"

#include "TSProject.h"
#include "TSProjectEntity.h"

#include "TSProjectCreateMenu.h"

#include "TSShapeBox.h"
#include "Shape_Link.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CNtlTSToolDoc


IMPLEMENT_DYNCREATE(CNtlTSToolDoc, CDocument)

BEGIN_MESSAGE_MAP(CNtlTSToolDoc, CDocument)
END_MESSAGE_MAP()


// CNtlTSToolDoc construction/destruction

CNtlTSToolDoc::CNtlTSToolDoc()
{
	m_pTSProject = NULL;
	m_pTSProjectEntity = NULL;
	m_pCurSelGroup = NULL;
}

CNtlTSToolDoc::~CNtlTSToolDoc()
{
}

BOOL CNtlTSToolDoc::OnNewDocument()
{
	if ( !CDocument::OnNewDocument() )
	{
		return FALSE;
	}

	// ���ο� TS Project entity�� �����Ѵ�
	if ( m_pTSProject )
	{
		m_pTSProjectEntity = m_pTSProject->CreateEntity();
	}

	return TRUE;
}

void CNtlTSToolDoc::DeleteContents()
{
	UnselectShape();
	UnselectGroup();

	// ����	�ִ� TS Project entity�� �����Ѵ�
	if ( m_pTSProject && m_pTSProjectEntity )
	{
		m_pTSProject->DeleteEntity( m_pTSProjectEntity );
	}
}


void CNtlTSToolDoc::OnCloseDocument()
{
	// ���� �ִ� TS Project�� �ݴ´�

	OnCloseProject();

	CDocument::OnCloseDocument();
}


// CNtlTSToolDoc serialization

void CNtlTSToolDoc::Serialize(CArchive& ar)
{
	if ( NULL == m_pTSProject ||
		 NULL == m_pTSProjectEntity )
	{
		return;
	}

	if ( ar.IsStoring() )
	{
		Save( ar );
	}
	else
	{
		switch ( m_pTSProjectEntity->GetProjectEntityVersion() )
		{
		case 0:
			Load_Trig_Ver_00000000( ar );
			break;

		default:
			ASSERT( !_T("The version of its project entity file is wrong.") );
			return;
		}
	}
}


// CNtlTSToolDoc diagnostics

#ifdef _DEBUG
void CNtlTSToolDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CNtlTSToolDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG


bool CNtlTSToolDoc::SelMainGroup( void )
{
	if ( NULL == m_pTSProject ||
		 NULL == m_pTSProjectEntity )
	{
		m_pCurSelGroup = NULL;
		return false;
	}

	UnselectShape();

	m_pCurSelGroup = m_pTSProjectEntity->GetTrigger()->GetGroup( 0 );

	UpdateAllViews( NULL );

	return m_pCurSelGroup ? true : false;
}


bool CNtlTSToolDoc::SelExceptGroup( BYTE byGroupID )
{
	if ( NULL == m_pTSProject ||
		 NULL == m_pTSProjectEntity )
	{
		m_pCurSelGroup = NULL;
		return false;
	}

	UnselectShape();

	m_pCurSelGroup = m_pTSProjectEntity->GetTrigger()->GetGroup( byGroupID );

	UpdateAllViews( NULL );

	return m_pCurSelGroup ? true : false;
}


void CNtlTSToolDoc::UnselectGroup( void )
{
	UnselectShape();

	m_pCurSelGroup = NULL;

	UpdateAllViews( NULL );
}


bool CNtlTSToolDoc::IsSelectShape( CTSShape* pShape )
{
	return m_Selection.Find( pShape ) == NULL ? false : true;
}


void CNtlTSToolDoc::SelectShape( CTSShape* pShape, bool bAdd )
{
	if ( NULL == m_pTSProject ||
		 NULL == m_pTSProjectEntity ||
		 NULL == m_pCurSelGroup )
	{
		return;
	}

	if ( !bAdd )
	{
		UnselectShape();
	}

	if ( !IsSelectShape( pShape ) )
	{
		m_Selection.AddTail( pShape );
	}

	RaiseUpShapes( pShape );

	UpdateAllViews( NULL );
}


void CNtlTSToolDoc::SelectShape( const CRect& rtRgn, bool bAdd )
{
	if ( NULL == m_pTSProject ||
		 NULL == m_pTSProjectEntity ||
		 NULL == m_pCurSelGroup )
	{
		return;
	}

	if ( !bAdd )
	{
		UnselectShape();
	}

	CTSShape* pShape;
	POSITION Pos;

	for ( Pos = m_pCurSelGroup->GetNoteLayer().GetTailPosition(); Pos != NULL; )
	{
		pShape = m_pCurSelGroup->GetNoteLayer().GetPrev( Pos );

		if ( pShape->Intersects( rtRgn ) && NULL == m_Selection.Find( pShape ) )
		{
			m_Selection.AddTail( pShape );
		}
	}

	for ( Pos = m_pCurSelGroup->GetContainerLayer().GetTailPosition(); Pos != NULL; )
	{
		pShape = m_pCurSelGroup->GetContainerLayer().GetPrev( Pos );

		if ( pShape->Intersects( rtRgn ) && !IsSelectShape( pShape ) )
		{
			m_Selection.AddTail( pShape );
		}
	}

	for ( Pos = m_pCurSelGroup->GetNoteLayer().GetTailPosition(); Pos != NULL; )
	{
		pShape = m_pCurSelGroup->GetNoteLayer().GetPrev( Pos );

		if ( pShape->Intersects( rtRgn ) && !IsSelectShape( pShape ) )
		{
			m_Selection.AddTail( pShape );
		}
	}

	RaiseUpShapes( pShape );

	UpdateAllViews( NULL );
}


void CNtlTSToolDoc::UnselectShape( CTSShape* pShape /*= NULL*/ )
{
	if ( pShape )
	{
		POSITION pos = m_Selection.Find( pShape );

		if ( NULL != pos )
		{
			m_Selection.RemoveAt( pos );
		}
	}
	else
	{
		m_Selection.RemoveAll();
	}

	UpdateAllViews( NULL );
}


CTSShape* CNtlTSToolDoc::GetShapeAt( const CPoint &ptPos ) const
{
	if ( NULL == m_pTSProject ||
		 NULL == m_pTSProjectEntity ||
		 NULL == m_pCurSelGroup )
	{
		return NULL;
	}

	CTSShape* pShape;
	POSITION Pos;

	for ( Pos = m_pCurSelGroup->GetNoteLayer().GetTailPosition(); Pos != NULL; )
	{
		pShape = m_pCurSelGroup->GetNoteLayer().GetPrev( Pos );

		if ( pShape->Intersects( ptPos ) )
		{
			return pShape;
		}
	}

	for ( Pos = m_pCurSelGroup->GetContainerLayer().GetTailPosition(); Pos != NULL; )
	{
		pShape = m_pCurSelGroup->GetContainerLayer().GetPrev( Pos );

		if ( pShape->Intersects( ptPos ) )
		{
			return pShape;
		}
	}

	for ( Pos = m_pCurSelGroup->GetLinkLayer().GetTailPosition(); Pos != NULL; )
	{
		pShape = m_pCurSelGroup->GetLinkLayer().GetPrev( Pos );

		if ( pShape->Intersects( ptPos ) )
		{
			return pShape;
		}
	}

	return NULL;
}


void CNtlTSToolDoc::GetShapesInRect( const CRect &rtRgn, TSShapeList& ShapeList ) const
{
	if ( NULL == m_pTSProject ||
		 NULL == m_pTSProjectEntity ||
		 NULL == m_pCurSelGroup )
	{
		return;
	}

	CTSShape* pShape;
	POSITION Pos;

	for ( Pos = m_pCurSelGroup->GetNoteLayer().GetTailPosition(); Pos != NULL; )
	{
		pShape = m_pCurSelGroup->GetNoteLayer().GetPrev( Pos );

		if ( pShape->Intersects( rtRgn ) && NULL == ShapeList.Find( pShape ) )
		{
			ShapeList.AddTail( pShape );
		}
	}

	for ( Pos = m_pCurSelGroup->GetContainerLayer().GetTailPosition(); Pos != NULL; )
	{
		pShape = m_pCurSelGroup->GetContainerLayer().GetPrev( Pos );

		if ( pShape->Intersects( rtRgn ) && NULL == ShapeList.Find( pShape ) )
		{
			ShapeList.AddTail( pShape );
		}
	}

	for ( Pos = m_pCurSelGroup->GetLinkLayer().GetTailPosition(); Pos != NULL; )
	{
		pShape = m_pCurSelGroup->GetLinkLayer().GetPrev( Pos );

		if ( pShape->Intersects( rtRgn ) && NULL == ShapeList.Find( pShape ) )
		{
			ShapeList.AddTail( pShape );
		}
	}
}


bool CNtlTSToolDoc::AddShape( CTSShape* pShape )
{
	if ( NULL == m_pTSProject ||
		 NULL == m_pTSProjectEntity ||
		 NULL == m_pCurSelGroup )
	{
		ASSERT( !_T("Can not add the shape.") );
		return false;
	}

	if ( DYNAMIC_DOWNCAST( CShape_Link, pShape ) )
	{
		m_pCurSelGroup->GetLinkLayer().AddTail( pShape );
	}
	else if ( DYNAMIC_DOWNCAST( CTSShapeBox, pShape ) )
	{
		m_pCurSelGroup->GetContainerLayer().AddTail( pShape );
	}
	else
	{
		ASSERT( !_T("Not supported shape type") );
		return false;
	}

	OnShapeChange( pShape );

	return true;
}


void CNtlTSToolDoc::RemoveShape( CTSShape* pShape )
{
	if ( NULL == m_pTSProject ||
		 NULL == m_pTSProjectEntity ||
		 NULL == m_pCurSelGroup )
	{
		ASSERT( !_T("Can not remove the shape.") );
		return;
	}

	pShape->MakeZombie();

	UpdateLinks();

	CTSShape* pTempShape;
	POSITION Pos, OldPos;

	for ( Pos = m_pCurSelGroup->GetNoteLayer().GetTailPosition(); Pos != NULL; )
	{
		OldPos = Pos;

		pTempShape = m_pCurSelGroup->GetNoteLayer().GetPrev( Pos );

		if ( pTempShape->IsZombie() )
		{
			m_pCurSelGroup->GetNoteLayer().RemoveAt( OldPos );

			UnselectShape( pShape );

			delete pTempShape;
		}
	}

	for ( Pos = m_pCurSelGroup->GetContainerLayer().GetTailPosition(); Pos != NULL; )
	{
		OldPos = Pos;

		pTempShape = m_pCurSelGroup->GetContainerLayer().GetPrev( Pos );

		if ( pTempShape->IsZombie() )
		{
			m_pCurSelGroup->GetContainerLayer().RemoveAt( OldPos );

			UnselectShape( pShape );

			delete pTempShape;
		}
	}

	for ( Pos = m_pCurSelGroup->GetLinkLayer().GetTailPosition(); Pos != NULL; )
	{
		OldPos = Pos;

		pTempShape = m_pCurSelGroup->GetLinkLayer().GetPrev( Pos );

		if ( pTempShape->IsZombie() )
		{
			m_pCurSelGroup->GetLinkLayer().RemoveAt( OldPos );

			UnselectShape( pShape );

			delete pTempShape;
		}
	}

	OnShapeChange();
}

bool CNtlTSToolDoc::GetShapeLinkInfoAt( const CPoint &ptPos, eLINKER_TYPE& eLinkerType, CTSShape*& pShape, void*& pLinkInfo ) const
{
	if ( NULL == m_pTSProject ||
		 NULL == m_pTSProjectEntity ||
		 NULL == m_pCurSelGroup )
	{
		eLinkerType = eLINKER_TYPE_INVALID;
		pShape = NULL;
		return false;
	}

	CTSShape* pTempShape;
	POSITION Pos;
	HLINKER hLinker;

	for ( Pos = m_pCurSelGroup->GetNoteLayer().GetTailPosition(); Pos != NULL; )
	{
		pTempShape = m_pCurSelGroup->GetNoteLayer().GetPrev( Pos );

		hLinker = pTempShape->GetLinkerAt( ptPos );

		if ( eHLINKER_INVALID != hLinker )
		{
			eLinkerType = pTempShape->GetLinkerType( hLinker );
			pShape = pTempShape;
			pLinkInfo = pTempShape->GetLinkerInfo( hLinker );
			return true;
		}
	}

	for ( Pos = m_pCurSelGroup->GetContainerLayer().GetTailPosition(); Pos != NULL; )
	{
		pTempShape = m_pCurSelGroup->GetContainerLayer().GetPrev( Pos );

		hLinker = pTempShape->GetLinkerAt( ptPos );

		if ( eHLINKER_INVALID != hLinker )
		{
			eLinkerType = pTempShape->GetLinkerType( hLinker );
			pShape = pTempShape;
			pLinkInfo = pTempShape->GetLinkerInfo( hLinker );
			return true;
		}
	}

	eLinkerType = eLINKER_TYPE_INVALID;
	pShape = NULL;

	return false;
}


void CNtlTSToolDoc::OnDeleteShapeLink( CTSShape* pShape, void* pLinkInfo )
{
	if ( NULL == m_pTSProject ||
		 NULL == m_pTSProjectEntity ||
		 NULL == m_pCurSelGroup )
	{
		return;
	}

	CArray< CShape_Link* > arDelShapeList;

	POSITION OldPos;
	CShape_Link* pLinkShape;

	for ( POSITION Pos = m_pCurSelGroup->GetLinkLayer().GetTailPosition(); Pos != NULL; )
	{
		OldPos = Pos;

		pLinkShape = DYNAMIC_DOWNCAST( CShape_Link, m_pCurSelGroup->GetLinkLayer().GetPrev( Pos ) );

		if ( pShape == pLinkShape->GetSrcAnchor().m_pShape &&
			 pLinkInfo == pLinkShape->GetSrcAnchor().m_pLinkerInfo )
		{
			arDelShapeList.Add( pLinkShape );
		}
	}

	for ( int i = 0; i < (int)arDelShapeList.GetCount(); ++i )
	{
		RemoveShape( arDelShapeList[i] );
	}
}


void CNtlTSToolDoc::OnShapeChange( CTSShape* pTSShape /*= NULL*/ )
{
	UpdateLinks();

	UpdateAllViews( NULL );

	SetModifiedFlag();
}


void CNtlTSToolDoc::RenderShapes( CDC* pDC )
{
	if ( NULL == m_pTSProject ||
		 NULL == m_pTSProjectEntity ||
		 NULL == m_pCurSelGroup )
	{
		return;
	}

	CTSShape* pShape;
	POSITION Pos;

	for ( Pos = m_pCurSelGroup->GetLinkLayer().GetHeadPosition(); Pos != NULL; )
	{
		pShape = m_pCurSelGroup->GetLinkLayer().GetNext( Pos );
		pShape->RenderShape( pDC );
		pShape->RenderLinker( pDC );
	}

	for ( Pos = m_pCurSelGroup->GetContainerLayer().GetHeadPosition(); Pos != NULL; )
	{
		pShape = m_pCurSelGroup->GetContainerLayer().GetNext( Pos );
		pShape->RenderShape( pDC );
		pShape->RenderLinker( pDC );
	}

	for ( Pos = m_pCurSelGroup->GetNoteLayer().GetHeadPosition(); Pos != NULL; )
	{
		pShape = m_pCurSelGroup->GetNoteLayer().GetNext( Pos );
		pShape->RenderShape( pDC );
		pShape->RenderLinker( pDC );
	}
}

void CNtlTSToolDoc::RenderLinkTrace( CDC* pDC )
{
	if ( NULL == m_pTSProject ||
		 NULL == m_pTSProjectEntity ||
		 NULL == m_pCurSelGroup )
	{
		return;
	}

	CShape_Link* pShape;
	POSITION Pos;

	for ( Pos = m_pCurSelGroup->GetLinkLayer().GetHeadPosition(); Pos != NULL; )
	{
		pShape = DYNAMIC_DOWNCAST( CShape_Link, m_pCurSelGroup->GetLinkLayer().GetNext( Pos ) );

		if ( pShape )
		{
			pShape->RenderLinkTrace( pDC );
		}
	}
}


void CNtlTSToolDoc::RenderSelectShapes( CDC* pDC )
{
	if ( NULL == m_pTSProject ||
		 NULL == m_pTSProjectEntity ||
		 NULL == m_pCurSelGroup )
	{
		return;
	}

	for ( POSITION pos = m_Selection.GetHeadPosition(); pos != NULL; )
	{
		m_Selection.GetNext( pos )->RenderHandler( pDC );
	}
}


void CNtlTSToolDoc::RaiseUpShapes( CTSShape* pShape )
{
	if ( NULL == m_pTSProject ||
		 NULL == m_pTSProjectEntity ||
		 NULL == m_pCurSelGroup )
	{
		return;
	}

	POSITION Pos, OldPos;
	CTSShape* pRetShape;
	for ( Pos = m_Selection.GetHeadPosition(); Pos != NULL; )
	{
		OldPos = Pos;

		pRetShape = m_Selection.GetNext( Pos );

		if ( pShape == pRetShape )
		{
			m_Selection.RemoveAt( OldPos );
			m_Selection.AddTail( pShape );

			break;
		}
	}

	m_pCurSelGroup->RaiseUp( pShape );
}


bool CNtlTSToolDoc::OnCreateProject( void )
{
	CTSProjectCreateMenu clDlg;

	if ( IDOK != clDlg.DoModal() )
	{
		return false;
	}

	// ���� ������Ʈ�� �ݴ´�

	UnselectShape();
	UnselectGroup();

	OnCloseProject();

	// ������Ʈ ��ü�� �����Ѵ�

	ASSERT( NULL == m_pTSProject );

	m_pTSProject = DYNAMIC_DOWNCAST( CTSProject, CTSProject::CreateObject() );
	ASSERT( m_pTSProject );

	CString strDir = clDlg.m_strProjPath;
	strDir += _T('\\') != strDir[strDir.GetLength() - 1] ? _T("\\") : _T("");

	CString strFullName = strDir;
	strFullName += clDlg.m_strProjName;
	strFullName += _T(".");
	strFullName += PROJECT_FILE_EXTENTION;

	m_pTSProject->SetProjectDir( strDir );
	m_pTSProject->SetProjectName( clDlg.m_strProjName );
	m_pTSProject->SetProjectType( clDlg.m_dwMode );

	{
		CWaitCursor clWaitCursor;

		CFile clFile( strFullName.GetString(), CFile::modeCreate|CFile::modeReadWrite|CFile::shareExclusive );
		CArchive ar( &clFile, CArchive::store|CArchive::bNoFlushOnDelete );

		m_pTSProject->Serialize( ar );

		ar.Flush();
	}

	UpdateAllViews( NULL );

	return true;
}


bool CNtlTSToolDoc::OnOpenProject( void )
{
	CFileDialog clDlg( TRUE, NULL, NULL, OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT, _T("TS Project files (*.pro)|*.pro||"), NULL, 0 );

	if ( IDOK != clDlg.DoModal() )
	{
		return false;
	}

	// ���� ������Ʈ�� �ݴ´�

	UnselectShape();
	UnselectGroup();

	OnCloseProject();

	// ������Ʈ ��ü�� �����Ѵ�

	ASSERT( NULL == m_pTSProject );

	m_pTSProject = DYNAMIC_DOWNCAST( CTSProject, CTSProject::CreateObject() );
	ASSERT( m_pTSProject );

	CString strPath = clDlg.GetPathName();

	CString strDir;
#ifdef UNICODE
	wchar_t drive[_MAX_DRIVE];
	wchar_t dir[_MAX_DIR];
	_wsplitpath_s( strPath.GetBuffer(), drive, _MAX_DRIVE, dir, _MAX_DIR, NULL, 0, NULL, 0 );
#else
	char drive[_MAX_DRIVE];
	char dir[_MAX_DIR];
	_splitpath_s( strPath.GetBuffer(), drive, _MAX_DRIVE, dir, _MAX_DIR, NULL, 0, NULL, 0 );
#endif
	strDir = drive;
	strDir += dir;
	strDir += _T('\\') != strDir[strDir.GetLength() - 1] ? _T("\\") : _T("");

	m_pTSProject->SetProjectDir( strDir );

	{
		CWaitCursor clWaitCursor;

		CFile clFile( strPath.GetString(), CFile::modeRead|CFile::shareDenyWrite );
		CArchive ar( &clFile, CArchive::load|CArchive::bNoFlushOnDelete );

		m_pTSProject->Serialize( ar );
	}

	UpdateAllViews( NULL );

	return true;
}


void CNtlTSToolDoc::OnCloseProject( void )
{
	// ���� �ִ� TS Project entity�� �ݴ´�

	UnselectShape();
	UnselectGroup();

	SaveModified();
	DeleteContents();

	// ���� �ִ� TS Project�� �ݴ´�

	if ( m_pTSProject )
	{
		delete m_pTSProject;
		m_pTSProject = NULL;
	}

	UpdateAllViews( NULL );
}


bool CNtlTSToolDoc::OnCreateProjectEntity( const CString& strFileName )
{
	// ������ ���� Entity�� �ݰ� ���ο� Entity�� �����Ѵ�

	UnselectShape();
	UnselectGroup();

	SaveModified();
	OnNewDocument();

	// ������Ʈ�� Entity list�� �����Ѵ�

	m_pTSProject->ReloadEntityFileList();

	// ���ο� Entity�� ���Ϸ� �����Ѵ�

	if ( !DoSave( strFileName ) )
	{
		ASSERT( !_T("Can not save the file.") );

		UpdateAllViews( NULL );

		return false;
	}

	// ������Ʈ�� Entity list�� �����Ѵ�

	m_pTSProject->ReloadEntityFileList();

	UpdateAllViews( NULL );

	return true;
}


bool CNtlTSToolDoc::OnOpenProjectEntity( const CString& strEntityName )
{
	CString strPath = m_pTSProject->GetProjectDir();
	strPath = strPath[strPath.GetLength()-1] == _T('\\') ? strPath : strPath + _T("\\");
	strPath += strEntityName;

	// ������ ���� Entity�� �ݴ´�

	UnselectShape();
	UnselectGroup();

	SaveModified();
	DeleteContents();

	// ������Ʈ�� Entity list�� �����Ѵ�

	m_pTSProject->ReloadEntityFileList();

	// ���ο� Entity�� ����

	if ( !LoadProjectEntity( strPath ) )
	{
		ASSERT( !_T("Can not open the file.") );

		UpdateAllViews( NULL );

		return false;
	}

	// ������Ʈ�� Entity list�� �����Ѵ�

	m_pTSProject->ReloadEntityFileList();

	UpdateAllViews( NULL );

	return true;
}


bool CNtlTSToolDoc::OnDeleteProjectEntity( const CString& strEntityName )
{
	CString strPath = m_pTSProject->GetProjectDir();
	strPath = strPath[strPath.GetLength()-1] == _T('\\') ? strPath : strPath + _T("\\");
	strPath += strEntityName;

	// ������ ���� Entity�� �ݴ´�

	UnselectShape();
	UnselectGroup();

	SaveModified();
	DeleteContents();

	// ������Ʈ�� Entity list�� �����Ѵ�

	m_pTSProject->ReloadEntityFileList();

	// �ش� ������ �����Ѵ�

	if ( !DeleteFile( strPath ) )
	{
		ASSERT( !_T("Can not delete the file.") );

		UpdateAllViews( NULL );

		return false;
	}

	// ������Ʈ�� Entity list�� �����Ѵ�

	m_pTSProject->ReloadEntityFileList();

	UpdateAllViews( NULL );

	return true;
}


bool CNtlTSToolDoc::OnClearProjectEntity( void )
{
	// ������ ���� Entity�� �ݴ´�

	UnselectShape();
	UnselectGroup();

	SaveModified();
	DeleteContents();

	// ������Ʈ�� Entity list�� �����Ѵ�

	m_pTSProject->ReloadEntityFileList();

	UpdateAllViews( NULL );

	return true;
}


bool CNtlTSToolDoc::OnCreateMainGroup( void )
{
	if ( NULL == m_pTSProject ||
		 NULL == m_pTSProjectEntity )
	{
		ASSERT( !_T("Project or Project entity is empty.") );
		return false;
	}

	if ( NULL == m_pTSProjectEntity->GetTrigger()->GetGroup( 0 ) )
	{
		m_pTSProjectEntity->GetTrigger()->CreateGroup( 0 );
	}
	else
	{
		AfxMessageBox( _T("The main group already exist.") );
	}

	OnShapeChange();

	return true;
}


bool CNtlTSToolDoc::OnCreateTimeLimitGroup( BYTE byGroupID )
{
	return OnCreateExceptGroup( byGroupID );
}


bool CNtlTSToolDoc::OnCreateServerGroup( BYTE byGroupID )
{
	return OnCreateExceptGroup( byGroupID );
}


bool CNtlTSToolDoc::OnCreateClientGroup( BYTE byGroupID )
{
	return OnCreateExceptGroup( byGroupID );
}


bool CNtlTSToolDoc::OnCreateGiveUpGroup( BYTE byGroupID )
{
	return OnCreateExceptGroup( byGroupID );
}


bool CNtlTSToolDoc::OnCreateExceptGroup( BYTE byGroupID )
{
	if ( NULL == m_pTSProject ||
		 NULL == m_pTSProjectEntity )
	{
		ASSERT( !_T("the Project or Project entity is empty.") );
		return false;
	}

	if ( 0 == byGroupID )
	{
		ASSERT( !_T("The group id 0 can not be used by exception group id.") );
		return false;
	}

	if ( NULL == m_pTSProjectEntity->GetTrigger()->GetGroup( byGroupID ) )
	{
		m_pTSProjectEntity->GetTrigger()->CreateGroup( byGroupID );
	}
	else
	{
		AfxMessageBox( _T("The except group already exist.") );
		return false;
	}

	OnShapeChange();

	return true;
}


bool CNtlTSToolDoc::OnDeleteSubGroup( BYTE byGroupID )
{
	if ( NULL == m_pTSProject ||
		 NULL == m_pTSProjectEntity )
	{
		ASSERT( !_T("the Project or Project entity is empty.") );
		return false;
	}

	m_pTSProjectEntity->GetTrigger()->DeleteGroup( byGroupID );

	OnShapeChange();

	return true;
}


void CNtlTSToolDoc::Save( CArchive& ar )
{
	m_pTSProjectEntity->Serialize( ar );
}


void CNtlTSToolDoc::Load_Trig_Ver_00000000( CArchive& ar )
{
	m_pTSProjectEntity->Serialize( ar );
}


bool CNtlTSToolDoc::LoadProjectEntity( const CString& strFileName )
{
#ifdef _DEBUG
	if (IsModified())
		TRACE(traceAppMsg, 0, "Warning: OnOpenDocument replaces an unsaved document.\n");
#endif

	OnNewDocument();
	SetModifiedFlag();

	SetPathName( strFileName );

	CFile* pFile = GetFile( strFileName, CFile::modeRead|CFile::shareDenyWrite, NULL );
	if ( pFile == NULL )
	{
		ASSERT( !_T("Can not open the file.") );
		return false;
	}

	CArchive loadArchive( pFile, CArchive::load | CArchive::bNoFlushOnDelete );
	loadArchive.m_pDocument = this;
	loadArchive.m_bForceFlat = FALSE;

	{
		CWaitCursor wait;
		if ( pFile->GetLength() != 0 )
		{
			Serialize( loadArchive );
		}
	}

	loadArchive.Close();
	ReleaseFile( pFile, FALSE );

	SetModifiedFlag( FALSE );

	return true;
}


void CNtlTSToolDoc::UpdateLinks( void )
{
	if ( NULL == m_pTSProject ||
	 	 NULL == m_pTSProjectEntity ||
		 NULL == m_pCurSelGroup )
	{
		return;
	}

	CTSShape* pTempShape;
	for ( POSITION pos = m_pCurSelGroup->GetLinkLayer().GetTailPosition(); pos != NULL; )
	{
		pTempShape = m_pCurSelGroup->GetLinkLayer().GetPrev( pos );

		pTempShape->Update();
	}
}

// CNtlTSToolDoc commands
