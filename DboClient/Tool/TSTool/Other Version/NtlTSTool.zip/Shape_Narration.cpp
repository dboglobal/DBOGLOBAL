#include "stdafx.h"
#include "Shape_Narration.h"

#include "TSProjectEntity.h"


IMPLEMENT_SERIAL( CShape_Narration, CTSShapeBox, 1 )


CShape_Narration::CShape_Narration( void )
{
}


CShape_Narration::CShape_Narration( const CPoint& ptPos, CTSGroup* pParent )
: CTSShapeBox( ptPos, pParent )
{
	// Name

	sSHAPE_NAME sName;	sName.strShapeType = _T("cont_narration");
	SetShapeName( sName );

	// Container attributes

	CString strTemp;

	strTemp.Format( _T("%d"), eNARRATION_PROGRESS_STATE_START );
	AddShapeAttr( _T("pt"), strTemp );

	strTemp.Format( _T("%d"), eNARRATION_OWNER_NPC );
	AddShapeAttr( _T("ot"), strTemp );

	strTemp.Format( _T("%d"), 0xffffffff );
	AddShapeAttr( _T("oi"), strTemp );

	strTemp.Format( _T("%d"), eNARRATION_OWNER_STATE_1 );
	AddShapeAttr( _T("os"), strTemp );

	strTemp.Format( _T("%d"), eNARRATION_DIALOG_DIR_TYPE_NORMAL );
	AddShapeAttr( _T("dt"), strTemp );

	strTemp.Format( _T("%d"), 0xffffffff );
	AddShapeAttr( _T("dg"), strTemp );

	strTemp.Format( _T("%d"), eNARRATION_GUI_TYPE_NORMAL );
	AddShapeAttr( _T("gt"), strTemp );

	// Linker 

	int nHeight = g_pTSTheme->GetLinkerRadius() + 20;
	AddLinker( eLINKER_TYPE_NEXT, nHeight );

	nHeight += g_pTSTheme->GetLinkerRadius() * 2 + 2;
	AddLinker( eLINKER_TYPE_CANCEL, nHeight );
}


CShape_Narration::~CShape_Narration( void )
{
}


void CShape_Narration::Serialize( CArchive &ar )
{
	CTSShapeBox::Serialize( ar );

	if ( ar.IsStoring() )
	{
		Save( ar );
	}
	else
	{
		// Name

		sSHAPE_NAME sName;	sName.strShapeType = _T("cont_narration");
		SetShapeName( sName );

		// Linker 

		int nHeight = g_pTSTheme->GetLinkerRadius() + 20;
		AddLinker( eLINKER_TYPE_NEXT, nHeight );

		nHeight += g_pTSTheme->GetLinkerRadius() * 2 + 2;
		AddLinker( eLINKER_TYPE_CANCEL, nHeight );

		switch ( m_pParent->GetParent()->GetParent()->GetProjectEntityVersion() )
		{
		case 0:
			if ( !Load_Trig_Ver_00000000( ar ) )
			{
				return;
			}
			break;

		case 1:
			if ( !Load_Trig_Ver_00000001( ar ) )
			{
				return;
			}
			break;

		default:
			ASSERT( !_T("The version of its project entity file is wrong.") );
			return;
		}
	}
}


void CShape_Narration::Save( CArchive& ar )
{
}


bool CShape_Narration::Load_Trig_Ver_00000000( CArchive& ar )
{
	return true;
}


bool CShape_Narration::Load_Trig_Ver_00000001( CArchive& ar )
{
	return true;
}
