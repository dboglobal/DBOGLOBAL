#pragma once


#include "TSShapeCtrl.h"


class CSCtrl_Link;
class CTSShape;


class CTSShapeSelectCtrl : public CTSShapeCtrl
{

// Declarations
public:

	enum eSTATE { eSTATE_NONE, eSTATE_DRAG, eSTATE_DRAGHANDLE, eSTATE_LINKERHANDLE, eSTATE_NETSELECT };


// Member variables
protected:

	eSTATE								m_eState;

	CSCtrl_Link*						m_pLinkerCtrl;

	CTSShape*							m_pTSShapeHandling;

	bool								m_bLock;
	CPoint								m_ptDown;
	CPoint								m_ptLastDown;


// Constructions and Destructions
public:

	CTSShapeSelectCtrl( CNtlTSToolView* pParent );
	virtual ~CTSShapeSelectCtrl( void );


// Methods
public:

	virtual void						OnMouseLButtonDown( const CPoint& ptPos, UINT nFlags );
	virtual void						OnMouseLButtonUp( const CPoint& ptPos, UINT nFlags );
	virtual void						OnMouseLButtonDoubleClick( const CPoint& ptPos, UINT nFlags );
	virtual void						OnMouseRButtonDoubleClick( const CPoint& ptPos, UINT nFlags );
	virtual void						OnMouseMove( const CPoint& ptPos, UINT nFlags );

	virtual void						OnContextMenu( const CPoint& ptPos );
	virtual void						OnDeactivate( void );

};
