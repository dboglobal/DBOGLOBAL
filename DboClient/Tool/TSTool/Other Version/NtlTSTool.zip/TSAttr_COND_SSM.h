#pragma once


#include "TSAttr_Page.h"
#include "afxwin.h"


// CTSAttr_COND_SSM ��ȭ �����Դϴ�.

class CTSAttr_COND_SSM : public CTSAttr_Page
{
	DECLARE_SERIAL(CTSAttr_COND_SSM)

public:
	CTSAttr_COND_SSM();
	virtual ~CTSAttr_COND_SSM();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_TS_COND_SSM_ATTR_DIAG };

protected:
	virtual CString	CollectAttrDataFromDlgItems( void );
	virtual void	SettingAttrDataToDlgItems( CString& strKey, CString& strValue );

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.
	virtual BOOL OnInitDialog();

	DECLARE_MESSAGE_MAP()

public:
	CComboBox m_ctrOPType;
	CComboBox m_ctrSSMId;
	DWORD m_dwValue;
};
