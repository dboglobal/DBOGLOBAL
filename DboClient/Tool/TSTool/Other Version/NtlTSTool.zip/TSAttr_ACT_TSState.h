#pragma once


#include "afxwin.h"
#include "TSAttr_Page.h"


// CTSAttr_ACT_TSState ��ȭ �����Դϴ�.

class CTSAttr_ACT_TSState : public CTSAttr_Page
{
	DECLARE_SERIAL(CTSAttr_ACT_TSState)

public:
	CTSAttr_ACT_TSState();
	virtual ~CTSAttr_ACT_TSState();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_TS_ACT_TSSTATE_ATTR_DIAG };

protected:
	virtual CString	CollectAttrDataFromDlgItems( void );
	virtual void	SettingAttrDataToDlgItems( CString& strKey, CString& strValue );

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.
	virtual BOOL OnInitDialog();

	DECLARE_MESSAGE_MAP()

public:
	DWORD m_taID;
	CButton m_ctrTypeAddBtn;
	CButton m_ctrTypeRemoveBtn;
	CButton m_ctrTSFailed;
public:
	afx_msg void OnBnClickedTsActAttrTsstateTypeAddCheck();
public:
	afx_msg void OnBnClickedTsActAttrTsstateTypeRemoveCheck();
};
