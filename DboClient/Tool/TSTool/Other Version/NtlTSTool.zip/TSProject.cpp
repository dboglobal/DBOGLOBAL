#include "stdafx.h"
#include "TSProject.h"
#include "TSProjectEntity.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#endif


static const CString PROJECT_FILE_HEADER = _T("NTL_TRIGGER_SYSTEM_PROJECT_HEADER");


IMPLEMENT_SERIAL( CTSProject, CObject, 1 )


CTSProject::CTSProject( void )
{
}


CTSProject::~CTSProject( void )
{
	ASSERT( m_EntityList.GetCount() == 0 );

	UnloadEntityFileList();

	ClearAllEntity();
}


CTSProjectEntity* CTSProject::CreateEntity( void )
{
	CTSProjectEntity* pEntity = DYNAMIC_DOWNCAST( CTSProjectEntity, CTSProjectEntity::CreateObject() );

	if ( NULL == pEntity )
	{
		return pEntity;
	}
	else
	{
		m_EntityList.Add( pEntity );

		return pEntity;
	}
}


void CTSProject::DeleteEntity( CTSProjectEntity*& pEntity )
{
	for ( int i = 0; i < m_EntityList.GetCount(); ++i )
	{
		if ( m_EntityList[i] == pEntity )
		{
			delete pEntity;
			pEntity = NULL;

			m_EntityList.RemoveAt( i );

			return;
		}
	}
}


void CTSProject::ClearAllEntity( void )
{
	for ( int i = 0; i < m_EntityList.GetCount(); ++i )
	{
		delete m_EntityList[i];
	}

	m_EntityList.RemoveAll();
}


bool CTSProject::LoadEntityFileList( const CString& strPath )
{
	WIN32_FIND_DATA FindFileData;
	HANDLE hFind = INVALID_HANDLE_VALUE;

	CString strSearchSpec( strPath[strPath.GetLength()-1] == _T('\\') ? strPath + _T("*.*") : strPath + _T("\\*.*") );

	hFind = FindFirstFile( strSearchSpec.GetBuffer(), &FindFileData );
	if ( INVALID_HANDLE_VALUE == hFind )
	{
		ASSERT( !_T("Loading trigger files is failed.") );
		return false;
	}

	do 
	{
		if ( FILE_ATTRIBUTE_DIRECTORY != (FindFileData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) &&
			 '.' != FindFileData.cFileName[0] )
		{
			CString strName = FindFileData.cFileName;
			int nFind = strName.ReverseFind( _T('.') );
			if ( -1 != nFind )
			{
				CString strExtention = strName.Right( strName.GetLength() - nFind - 1 );

				if ( TS_FILE_EXTENTION == strExtention )
				{
					m_EntityFileList.Add( strName );
				}
			}
		}
	}
	while ( FindNextFile( hFind, &FindFileData ) != 0 );

	FindClose( hFind );

	return true;
}


bool CTSProject::ReloadEntityFileList( void )
{
	UnloadEntityFileList();
	return LoadEntityFileList( GetProjectDir() );
}

void CTSProject::UnloadEntityFileList( void )
{
	m_EntityFileList.RemoveAll();
}


void CTSProject::Serialize( CArchive& ar )
{
	CObject::Serialize( ar );

	if ( ar.IsStoring() )
	{
		Save( ar );
	}
	else
	{
		// Load the project file version

		ar >> m_dwProjectVersion;

		// Load the project informations

		switch ( m_dwProjectVersion )
		{
		case 0:
			if ( !Load_Proj_Ver_00000000( ar ) )
			{
				return;
			}
			break;

		case 1:
			if ( !Load_Proj_Ver_00000001( ar ) )
			{
				return;
			}
			break;

		default:
			ASSERT( !_T("The version of its project file is wrong.") );
			return;
		}

		UnloadEntityFileList();
		LoadEntityFileList( GetProjectDir() );
	}
}


void CTSProject::Save( CArchive& ar )
{
	// Save the project file version

	ar << TS_PROJECT_FILE_VERSION;

	// Save the project file header

	ar << PROJECT_FILE_HEADER;

	// Save the project informations

	ar << m_strProjectName;
	ar << m_dwProjectType;
}


bool CTSProject::Load_Proj_Ver_00000000( CArchive& ar )
{
	// Load the project file header

	ar >> m_strProjectHeader;

	if ( _T("NTL_TRIGGER_SYSTEM_HEADER") != m_strProjectHeader )
	{
		ASSERT( !_T("It is not the TS Project file.") );
		return false;
	}

	ar >> m_strProjectName;
	ar >> m_dwProjectType;

	return true;
}


bool CTSProject::Load_Proj_Ver_00000001( CArchive& ar )
{
	// Load the project file header

	ar >> m_strProjectHeader;

	if ( PROJECT_FILE_HEADER != m_strProjectHeader )
	{
		ASSERT( !_T("It is not the TS Project file.") );
		return false;
	}

	ar >> m_strProjectName;
	ar >> m_dwProjectType;

	return true;
}
