// Attr_Page.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "TSAttr_Page.h"


// CTSAttr_Page ��ȭ �����Դϴ�.


IMPLEMENT_DYNAMIC(CTSAttr_Page, COptionPage)


CTSAttr_Page::CTSAttr_Page( unsigned int uiIDD )
: COptionPage( uiIDD )
{

}

CTSAttr_Page::~CTSAttr_Page()
{
}

CString CTSAttr_Page::MakeAttrData( const CString& strAttrKey, const CString& strAttrValue )
{
	CString strData;
	strData.Format( _T("%s # %s # "), strAttrKey, strAttrValue );
	return strData;
}

CString	CTSAttr_Page::MakeAttrData( const CString& strAttrKey, DWORD dwAttrValue )
{
	CString strData;
	strData.Format( _T("%s # %d # "), strAttrKey, dwAttrValue );
	return strData;
}

CString	CTSAttr_Page::MakeAttrData( const CString& strAttrKey, int nAttrValue )
{
	CString strData;
	strData.Format( _T("%s # %d # "), strAttrKey, nAttrValue );
	return strData;
}

CString	CTSAttr_Page::MakeAttrData( const CString& strAttrKey, unsigned int uiAttrValue )
{
	CString strData;
	strData.Format( _T("%s # %d # "), strAttrKey, uiAttrValue );
	return strData;
}

CString	CTSAttr_Page::MakeAttrData( const CString& strAttrKey, float fAttrValue )
{
	CString strData;
	strData.Format( _T("%s # %f # "), strAttrKey, fAttrValue );
	return strData;
}

CString CTSAttr_Page::GetAttrValue( const CString& strAttrData, const CString& strAttrKey )
{
	CString strRet;

	int nStart = strAttrData.Find( strAttrKey );
	if ( nStart < 0 || nStart >= strAttrData.GetLength() )
	{
		return CString();
	}

	nStart = strAttrData.Find( '#', nStart );
	if ( nStart < 0 || nStart >= strAttrData.GetLength() )
	{
		return CString();
	}

	strRet = strAttrData.Tokenize( "#", nStart );
	strRet.Trim();

	return strRet;
}

const CString& CTSAttr_Page::GetAllAttrData( void ) const
{
	return m_strAllAttrData;
}

void CTSAttr_Page::SetAllAttrData( const CString& strAllAttrData )
{
	m_strAllAttrData = strAllAttrData;
}

void CTSAttr_Page::ClearAllAttrData( void )
{
	m_strAllAttrData.Empty();
}

CString CTSAttr_Page::GetAttr( const CString& strKey )
{
	CString strRet;

	int nStart = m_strAllAttrData.Find( strKey );
	if ( nStart < 0 || nStart >= m_strAllAttrData.GetLength() ) return CString();

	nStart = m_strAllAttrData.Find( '#', nStart );
	if ( nStart < 0 || nStart >= m_strAllAttrData.GetLength() ) return CString();

	strRet = m_strAllAttrData.Tokenize( "#", nStart );
	strRet.Trim();

	return strRet;
}


void CTSAttr_Page::AddAttr( const CString& strData )
{
	m_strAllAttrData += strData;
}

void CTSAttr_Page::AddAttr( const CString& strAttrKey, const CString& strAttrValue )
{
	m_strAllAttrData += MakeAttrData( strAttrKey, strAttrValue );
}

void CTSAttr_Page::AddAttr( const CString& strAttrKey, int nAttrValue )
{
	m_strAllAttrData += MakeAttrData( strAttrKey, nAttrValue );
}

CString CTSAttr_Page::CollectAttrDataFromDlgItems( void )
{
	UpdateData( TRUE );

	return CString();
}

void CTSAttr_Page::SettingAttrDataToDlgItems( const CString& strData )
{
	enum { eTOKEN_TYPE_KEY, eTOKEN_TYPE_VALUE };

	CString strKey, strValue;

	CString strToken;
	int nStart = 0;
	bool bLoop = true;

	int nTokType = eTOKEN_TYPE_KEY;

	while ( bLoop )
	{
		strToken = strData.Tokenize( _T("#"), nStart );
		if ( nStart >= strData.GetLength() ) bLoop = false;

		switch ( nTokType )
		{
		case eTOKEN_TYPE_KEY:
			{
				strKey = strToken.Trim();
				strValue.Empty();

				nTokType = eTOKEN_TYPE_VALUE;
			}
			break;

		case eTOKEN_TYPE_VALUE:
			{
				strValue = strToken.Trim();

				SettingAttrDataToDlgItems( strKey, strValue );

				strKey.Empty();
				strValue.Empty();

				nTokType = eTOKEN_TYPE_KEY;
			}
			break;
		}
	}

	UpdateData( FALSE );
}

void CTSAttr_Page::SettingAttrDataToDlgItems( CString& strKey, CString& strValue )
{
}

void CTSAttr_Page::DoDataExchange(CDataExchange* pDX)
{
	COptionPage::DoDataExchange(pDX);
}

BOOL CTSAttr_Page::OnInitDialog()
{
	COptionPage::OnInitDialog();

	// ���۽� Attribute data�� control�鿡�� �����Ѵ�

	if ( m_strAllAttrData.GetLength() > 0 )
	{
		CTSAttr_Page::SettingAttrDataToDlgItems( m_strAllAttrData );
	}

	return TRUE;
}

void CTSAttr_Page::OnOK()
{
	// ����� control��� ���� Attribute data�� �����Ѵ�
	m_strAllAttrData = CollectAttrDataFromDlgItems();

	COptionPage::OnOK();
}


BEGIN_MESSAGE_MAP(CTSAttr_Page, COptionPage)
END_MESSAGE_MAP()


// CTSAttr_Page �޽��� ó�����Դϴ�.
