#pragma once


#include "OptionSheet.h"


class CTSAttr_Page;


class CTSAttr_Page_Mng : public COptionSheet
{
	DECLARE_DYNAMIC(CTSAttr_Page_Mng)


// Member variables
protected:

	CTSAttr_Page*		m_pActivatedPage;


// Constructions and Destructions
public:

	CTSAttr_Page_Mng( CWnd* pParent = NULL );
	virtual ~CTSAttr_Page_Mng( void );


// Methods
public:

	CTSAttr_Page*		GetActivatedPage( void );

	void				AddTSAttrPage( CTSAttr_Page* pPage );
	void				ClearAllTSAttrPage( void );


// Messages
protected:

	virtual void		DoDataExchange( CDataExchange* pDX );


	DECLARE_MESSAGE_MAP()


protected:

	virtual BOOL		OnCommand(WPARAM wParam, LPARAM lParam);
};
