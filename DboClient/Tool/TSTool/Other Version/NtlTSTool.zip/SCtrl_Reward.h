#pragma once


#include "TSShapeBoxCtrl.h"


class CSCtrl_Reward : public CTSShapeBoxCtrl
{

	// Constructions and Destructions
public:

	CSCtrl_Reward( CNtlTSToolView* pParent );
	virtual ~CSCtrl_Reward( void );


	// Methods
public:

	virtual CTSShapeBox*				New( const CPoint& ptPos );
};
