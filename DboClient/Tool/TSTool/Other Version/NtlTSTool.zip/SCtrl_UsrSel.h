#pragma once


#include "TSShapeBoxCtrl.h"


class CSCtrl_UsrSel : public CTSShapeBoxCtrl
{

	// Constructions and Destructions
public:

	CSCtrl_UsrSel( CNtlTSToolView* pParent );
	virtual ~CSCtrl_UsrSel( void );


	// Methods
public:

	virtual CTSShapeBox*				New( const CPoint& ptPos );
};
