#pragma once


#include "TSShapeBox.h"


class CShape_Switch : public CTSShapeBox
{

	DECLARE_SERIAL( CShape_Switch )


// Member variables
protected:


// Constructions and Destructions
protected:
	CShape_Switch( void );

public:
	CShape_Switch( const CPoint& ptPos, CTSGroup* pParent );
	virtual ~CShape_Switch( void );


// Methods
public:

	virtual sSHAPE_GROUP*				AddShapeGroup( int nIdx = -1 );
	virtual void						RemoveShapeGroup( sSHAPE_GROUP*& pGroup );
	virtual void						ClearAllShapeGroup( bool bShapeChange = true );

	// Serialize

	virtual void						Serialize( CArchive &ar );


// Implementations
protected:

	virtual	void						ShowContainerEntityAttributeAddDlg( int nGroupID );

	void								Save( CArchive& ar );

	bool								Load_Trig_Ver_00000000( CArchive& ar );
	bool								Load_Trig_Ver_00000001( CArchive& ar );

};