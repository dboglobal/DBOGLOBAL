// Attr_Group.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "NtlTSTool.h"
#include "TSAttr_Group.h"


// CTSAttr_Group ��ȭ �����Դϴ�.

IMPLEMENT_SERIAL(CTSAttr_Group, CTSAttr_Page, 1)

CTSAttr_Group::CTSAttr_Group(CWnd* pParent /*=NULL*/)
	: CTSAttr_Page(CTSAttr_Group::IDD)
	, m_tgID(NTL_TS_TG_ID_INVALID)
{

}

CTSAttr_Group::~CTSAttr_Group()
{
}

CString CTSAttr_Group::CollectAttrDataFromDlgItems( void )
{
	CTSAttr_Page::CollectAttrDataFromDlgItems();

	CString strData;

	strData += MakeAttrData( _T("gid"), m_tgID );

	return strData;
}

void CTSAttr_Group::SettingAttrDataToDlgItems( CString& strKey, CString& strValue )
{
	if ( _T("gid") == strKey )
	{
		m_tgID = atoi( strValue.GetBuffer() );
	}
}

void CTSAttr_Group::DoDataExchange(CDataExchange* pDX)
{
	CTSAttr_Page::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_TS_GROUP_ATTR_ID_EDITOR, m_tgID);
	DDV_MinMaxUInt(pDX, m_tgID, 0, NTL_TS_TG_ID_INVALID);
}


BEGIN_MESSAGE_MAP(CTSAttr_Group, CTSAttr_Page)
END_MESSAGE_MAP()


// CTSAttr_Group �޽��� ó�����Դϴ�.
