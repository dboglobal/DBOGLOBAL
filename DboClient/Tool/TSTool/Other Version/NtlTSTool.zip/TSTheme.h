#pragma once


//////////////////////////////////////////////////////////////////////////
//
//	CTSTheme
//
//////////////////////////////////////////////////////////////////////////


class CTSTheme
{

// Member variables
protected:

	// View

	double								m_fMinScale;
	double								m_fNormalScale;
	double								m_fMaxScale;

	CSize								m_Extent;

	COLORREF							m_ViewColor;

	// Grid
	CSize								m_GridSize;

	// Handler

	int									m_nHandlerRadius;

	// Linker

	int									m_nLinkerRadius;

	COLORREF							m_cLinkerBGColor[eLINKER_TYPE_MAX];

	CFont*								m_pLinkerStringFont;
	COLORREF							m_cLinkerStringColor[eLINKER_TYPE_MAX];
	CString								m_strLinkerString[eLINKER_TYPE_MAX];


	// Shape box

	int									m_nShapeBoxNameHeight;

	int									m_nShapeBoxIDHeight;

	int									m_nShapeBoxAttrNameHeight;
	int									m_nShapeBoxAttrHeight;
	int									m_nShapeBoxAttrNewHeight;

	int									m_nShapeBoxEntityNameHeight;
	int									m_nShapeBoxEntityHeight;
	int									m_nShapeBoxEntityNewHeight;

	COLORREF							m_cShapeBoxShadowColor;
	COLORREF							m_cShapeBoxShadowFillColor;

	COLORREF							m_cShapeBoxOutlineColor;
	COLORREF							m_cShapeBoxOutlineFillColor;

	CFont*								m_pShapeBoxNameFont;
	COLORREF							m_caShapeBoxNameColor;

	CFont*								m_pShapeBoxIDFont;
	COLORREF							m_cShapeBoxIDColor;

	CFont*								m_pShapeBoxAttrNameFont;
	COLORREF							m_cShapeBoxAttrNameColor;

	CFont*								m_pShapeBoxAttrFont;
	COLORREF							m_cShapeBoxAttrColor;

	CFont*								m_pShapeBoxEntityNameFont;
	COLORREF							m_cShapeBoxEntityNameColor;

	CFont*								m_pShapeBoxEntityFont;
	COLORREF							m_cShapeBoxEntityColor;

	// Link

	int									m_LinkerLineStyle[eLINKER_TYPE_MAX];
	COLORREF							m_LinkerLineColor[eLINKER_TYPE_MAX];

	CFont*								m_pLinkerNameFont;


// Constructions and Destructions
public:

	CTSTheme( void );
	virtual ~CTSTheme( void );


// Methods
public:

	static void							Create( void );
	static void							Delete( void );

	// View

	double								GetMinScale( void ) const { return m_fMinScale; }
	double								GetNormalScale( void ) const { return m_fNormalScale; }
	double								GetMaxScale( void ) const { return m_fMaxScale; }

	CSize								GetExtent( void ) const { return m_Extent; }

	COLORREF							GetViewColor( void ) const { return m_ViewColor; }

	// Grid

	CSize								GetGridSize( void ) const { return m_GridSize; }

	// Handler

	int									GetHandlerRadius( void ) const { return m_nHandlerRadius; }

	// Linker

	int									GetLinkerRadius( void ) const { return m_nLinkerRadius; }

	COLORREF							GetLinkerBGColor( eLINKER_TYPE eType ) const { return m_cLinkerBGColor[eType]; }

	CFont*								GetLinkerStringFont( void ) const { return m_pLinkerStringFont; }
	COLORREF							GetLinkerStringColor( eLINKER_TYPE eType ) const { return m_cLinkerStringColor[eType]; }
	CString								GetLinkerString( eLINKER_TYPE eType ) const { return m_strLinkerString[eType]; }

	// Shape box

	int									GetShapeBoxNameHeight( void ) const { return m_nShapeBoxNameHeight; }

	int									GetShapeBoxIDHeight( void ) const { return m_nShapeBoxIDHeight; }

	int									GetShapeBoxAttrNameHeight( void ) const { return m_nShapeBoxAttrNameHeight; }
	int									GetShapeBoxAttrHeight( void ) const { return m_nShapeBoxAttrHeight; }
	int									GetShapeBoxAttrNewHeight( void ) const { return m_nShapeBoxAttrNewHeight; }

	int									GetShapeBoxEntityNameHeight( void ) const { return m_nShapeBoxEntityNameHeight; }
	int									GetShapeBoxEntityHeight( void ) const { return m_nShapeBoxEntityHeight; }
	int									GetShapeBoxEntityNewHeight( void ) const { return m_nShapeBoxEntityNewHeight; }

	COLORREF							GetShapeBoxShadowColor( void ) const { return m_cShapeBoxShadowColor; }
	COLORREF							GetShapeBoxShadowFillColor( void ) const { return m_cShapeBoxShadowFillColor; }

	COLORREF							GetShapeBoxOutlineColor( void ) const { return m_cShapeBoxOutlineColor; }
	COLORREF							GetShapeBoxOutlineFillColor( void ) const { return m_cShapeBoxOutlineFillColor; }

	CFont*								GetShapeBoxNameFont( void ) const { return m_pShapeBoxNameFont; }
	COLORREF							GetShapeBoxNameColor( void ) const { return m_caShapeBoxNameColor; }

	CFont*								GetShapeBoxIDFont( void ) const { return m_pShapeBoxIDFont; }
	COLORREF							GetShapeBoxIDColor( void ) const { return m_cShapeBoxIDColor; }

	CFont*								GetShapeBoxAttrNameFont( void ) const { return m_pShapeBoxAttrNameFont; }
	COLORREF							GetShapeBoxAttrNameColor( void ) const { return m_cShapeBoxAttrNameColor; }

	CFont*								GetShapeBoxAttrFont( void ) const { return m_pShapeBoxAttrFont; }
	COLORREF							GetShapeBoxAttrColor( void ) const { return m_cShapeBoxAttrColor; }

	CFont*								GetShapeBoxEntityNameFont( void ) const { return m_pShapeBoxEntityNameFont; }
	COLORREF							GetShapeBoxEntityNameColor( void ) const { return m_cShapeBoxEntityNameColor; }

	CFont*								GetShapeBoxEntityFont( void ) const { return m_pShapeBoxEntityFont; }
	COLORREF							GetShapeBoxEntityColor( void ) const { return m_cShapeBoxEntityColor; }

	// Linker

	int									GetLinkerLineStyle( eLINKER_TYPE eType ) const { return m_LinkerLineStyle[eType]; }
	COLORREF							GetLinkerLineColor( eLINKER_TYPE eType ) const { return m_LinkerLineColor[eType]; }

	CFont*								GetLinkerNameFont( void ) const { return m_pLinkerNameFont; }
};


extern CTSTheme* g_pTSTheme;
