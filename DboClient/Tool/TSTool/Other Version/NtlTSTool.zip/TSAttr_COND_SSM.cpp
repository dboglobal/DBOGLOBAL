// TSAttr_COND_SSM.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "NtlTSTool.h"
#include "TSAttr_COND_SSM.h"


// CTSAttr_COND_SSM ��ȭ �����Դϴ�.

IMPLEMENT_SERIAL(CTSAttr_COND_SSM, CTSAttr_Page, 1)

CTSAttr_COND_SSM::CTSAttr_COND_SSM()
	: CTSAttr_Page(CTSAttr_COND_SSM::IDD)
	, m_dwValue(0xffffffff)
{

}

CTSAttr_COND_SSM::~CTSAttr_COND_SSM()
{
}

CString CTSAttr_COND_SSM::CollectAttrDataFromDlgItems( void )
{
	CTSAttr_Page::CollectAttrDataFromDlgItems();

	CString strData;

	strData += MakeAttrData( _T("op"), (int)m_ctrOPType.GetItemData( m_ctrOPType.GetCurSel() ) );
	strData += MakeAttrData( _T("ssmid"), (int)m_ctrSSMId.GetItemData( m_ctrSSMId.GetCurSel() ) );
	strData += MakeAttrData( _T("var"), m_dwValue );

	return strData;
}

void CTSAttr_COND_SSM::SettingAttrDataToDlgItems( CString& strKey, CString& strValue )
{
	if ( _T("op") == strKey )
	{
		int nValue = atoi( strValue.GetBuffer() );

		int nCnt = m_ctrOPType.GetCount();
		for ( int i = 0; i < nCnt; ++i )
		{
			if ( m_ctrOPType.GetItemData( i ) == nValue )
			{
				m_ctrOPType.SetCurSel( i );
				break;
			}
		}
	}
	else if ( _T("ssmid") == strKey )
	{
		int nValue = atoi( strValue.GetBuffer() );

		int nCnt = m_ctrSSMId.GetCount();
		for ( int i = 0; i < nCnt; ++i )
		{
			if ( m_ctrSSMId.GetItemData( i ) == nValue )
			{
				m_ctrSSMId.SetCurSel( i );
				break;
			}
		}
	}
	else if ( _T("var") == strKey )
	{
		m_dwValue = atoi( strValue.GetBuffer() );
	}
}

void CTSAttr_COND_SSM::DoDataExchange(CDataExchange* pDX)
{
	CTSAttr_Page::DoDataExchange(pDX);

	DDX_Control(pDX, IDC_TS_COND_ATTR_SSM_OPTYPE_COMBO, m_ctrOPType);
	DDX_Control(pDX, IDC_TS_COND_ATTR_SSM_SLOTID_COMBO, m_ctrSSMId);
	DDX_Text(pDX, IDC_TS_COND_ATTR_SSM_VARIABLE_EDITOR, m_dwValue);
}

BOOL CTSAttr_COND_SSM::OnInitDialog()
{
	CTSAttr_Page::OnInitDialog();

	// TODO:  ���⿡ �߰� �ʱ�ȭ �۾��� �߰��մϴ�.
	m_ctrOPType.SetItemData( m_ctrOPType.AddString( _T("Equal") ), eSSM_OP_TYPE_EQUAL );
	m_ctrOPType.SetItemData( m_ctrOPType.AddString( _T("Not equal") ), eSSM_OP_TYPE_NOT_EQUAL );
	m_ctrOPType.SetItemData( m_ctrOPType.AddString( _T("Less") ), eSSM_OP_TYPE_LESS );
	m_ctrOPType.SetItemData( m_ctrOPType.AddString( _T("Less equal") ), eSSM_OP_TYPE_LESS_EQUAL );
	m_ctrOPType.SetItemData( m_ctrOPType.AddString( _T("More") ), eSSM_OP_TYPE_MORE );
	m_ctrOPType.SetItemData( m_ctrOPType.AddString( _T("More equal") ), eSSM_OP_TYPE_MORE_EQUAL );
	int nIdx = m_ctrOPType.AddString( _T("Invalid") );
	m_ctrOPType.SetItemData(  nIdx, eSSM_ID_INVALID );
	m_ctrOPType.SetCurSel( nIdx );

	m_ctrSSMId.SetItemData( m_ctrSSMId.AddString( _T("Slot 0") ), eSSM_ID_0 );
	m_ctrSSMId.SetItemData( m_ctrSSMId.AddString( _T("Slot 1") ), eSSM_ID_1 );
	m_ctrSSMId.SetItemData( m_ctrSSMId.AddString( _T("Slot 2") ), eSSM_ID_2 );
	m_ctrSSMId.SetItemData( m_ctrSSMId.AddString( _T("Slot 3") ), eSSM_ID_3 );
	m_ctrSSMId.SetItemData( m_ctrSSMId.AddString( _T("Slot 4") ), eSSM_ID_4 );
	m_ctrSSMId.SetItemData( m_ctrSSMId.AddString( _T("Slot 5") ), eSSM_ID_5 );
	m_ctrSSMId.SetItemData( m_ctrSSMId.AddString( _T("Slot 6") ), eSSM_ID_6 );
	m_ctrSSMId.SetItemData( m_ctrSSMId.AddString( _T("Slot 7") ), eSSM_ID_7 );
	nIdx = m_ctrSSMId.AddString( _T("Invalid") );
	m_ctrSSMId.SetItemData(  nIdx, eSSM_ID_INVALID );
	m_ctrSSMId.SetCurSel( nIdx );

	if ( m_strAllAttrData.GetLength() > 0 )
	{
		CTSAttr_Page::SettingAttrDataToDlgItems( m_strAllAttrData );
	}

	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}


BEGIN_MESSAGE_MAP(CTSAttr_COND_SSM, CTSAttr_Page)
END_MESSAGE_MAP()


// CTSAttr_COND_SSM �޽��� ó�����Դϴ�.
