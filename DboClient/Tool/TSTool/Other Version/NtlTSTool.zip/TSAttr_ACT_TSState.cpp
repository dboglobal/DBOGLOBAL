// Attr_ACT_Cin.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "NtlTSTool.h"
#include "TSAttr_ACT_TSState.h"


// CTSAttr_ACT_TSState ��ȭ �����Դϴ�.

IMPLEMENT_SERIAL(CTSAttr_ACT_TSState, CTSAttr_Page, 1)

CTSAttr_ACT_TSState::CTSAttr_ACT_TSState()
	: CTSAttr_Page(CTSAttr_ACT_TSState::IDD)
	, m_taID(NTL_TS_TA_ID_INVALID)
{

}

CTSAttr_ACT_TSState::~CTSAttr_ACT_TSState()
{
}

CString CTSAttr_ACT_TSState::CollectAttrDataFromDlgItems( void )
{
	CTSAttr_Page::CollectAttrDataFromDlgItems();

	CString strData;

	strData += MakeAttrData( _T("taid"), m_taID );

	if ( m_ctrTypeAddBtn.GetCheck() == BST_CHECKED ) strData += MakeAttrData( _T("type"), eTSSTATE_TYPE_ADD );
	else strData += MakeAttrData( _T("type"), eTSSTATE_TYPE_REMOVE );

	DWORD dwState = 0;
	dwState |= (m_ctrTSFailed.GetCheck() == BST_CHECKED) ? eTS_SVR_STATE_FAILED : 0;
	strData += MakeAttrData( _T("state"), dwState );

	return strData;
}

void CTSAttr_ACT_TSState::SettingAttrDataToDlgItems( CString& strKey, CString& strValue )
{
	if ( _T("taid") == strKey )
	{
		m_taID = atoi( strValue.GetBuffer() );
	}

	if ( _T("type") == strKey )
	{
		DWORD dwType = atoi( strValue.GetBuffer() );

		if ( eTSSTATE_TYPE_ADD == dwType )
		{
			m_ctrTypeAddBtn.SetCheck( BST_CHECKED );
			m_ctrTypeRemoveBtn.SetCheck( BST_UNCHECKED );
		}
		else
		{
			m_ctrTypeAddBtn.SetCheck( BST_UNCHECKED );
			m_ctrTypeRemoveBtn.SetCheck( BST_CHECKED );
		}
	}

	if ( _T("state") == strKey )
	{
		DWORD dwState = atoi( strValue.GetBuffer() );

		if ( dwState & eTS_SVR_STATE_FAILED ) m_ctrTSFailed.SetCheck( BST_CHECKED );
	}
}

void CTSAttr_ACT_TSState::DoDataExchange(CDataExchange* pDX)
{
	CTSAttr_Page::DoDataExchange(pDX);

	DDX_Text(pDX, IDC_TS_ACT_ATTR_TSSTATE_ID_EDITOR, m_taID);
	DDV_MinMaxUInt(pDX, m_taID, 0, NTL_TS_TA_ID_INVALID);
	DDX_Control(pDX, IDC_TS_ACT_ATTR_TSSTATE_TYPE_ADD_CHECK, m_ctrTypeAddBtn);
	DDX_Control(pDX, IDC_TS_ACT_ATTR_TSSTATE_TYPE_REMOVE_CHECK, m_ctrTypeRemoveBtn);
	DDX_Control(pDX, IDC_TS_ACT_ATTR_TSSTATE_FAILED_CHECK, m_ctrTSFailed);
}

BOOL CTSAttr_ACT_TSState::OnInitDialog()
{
	CTSAttr_Page::OnInitDialog();

	// TODO:  ���⿡ �߰� �ʱ�ȭ �۾��� �߰��մϴ�.
	m_ctrTypeAddBtn.SetCheck( BST_CHECKED );
	m_ctrTypeRemoveBtn.SetCheck( BST_UNCHECKED );

	m_ctrTSFailed.SetCheck( BST_UNCHECKED );

	if ( m_strAllAttrData.GetLength() > 0 )
	{
		CTSAttr_Page::SettingAttrDataToDlgItems( m_strAllAttrData );
	}

	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}


BEGIN_MESSAGE_MAP(CTSAttr_ACT_TSState, CTSAttr_Page)
	ON_BN_CLICKED(IDC_TS_ACT_ATTR_TSSTATE_TYPE_ADD_CHECK, &CTSAttr_ACT_TSState::OnBnClickedTsActAttrTsstateTypeAddCheck)
	ON_BN_CLICKED(IDC_TS_ACT_ATTR_TSSTATE_TYPE_REMOVE_CHECK, &CTSAttr_ACT_TSState::OnBnClickedTsActAttrTsstateTypeRemoveCheck)
END_MESSAGE_MAP()


// CTSAttr_ACT_TSState �޽��� ó�����Դϴ�.

void CTSAttr_ACT_TSState::OnBnClickedTsActAttrTsstateTypeAddCheck()
{
	if ( m_ctrTypeAddBtn.GetCheck() == BST_CHECKED )
	{
		m_ctrTypeRemoveBtn.SetCheck( BST_UNCHECKED );
	}
}

void CTSAttr_ACT_TSState::OnBnClickedTsActAttrTsstateTypeRemoveCheck()
{
	if ( m_ctrTypeRemoveBtn.GetCheck() == BST_CHECKED )
	{
		m_ctrTypeAddBtn.SetCheck( BST_UNCHECKED );
	}
}
