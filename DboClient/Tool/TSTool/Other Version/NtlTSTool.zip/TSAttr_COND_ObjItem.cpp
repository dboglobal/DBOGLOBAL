// TSAttr_COND_ObjItem.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "NtlTSTool.h"
#include "TSAttr_COND_ObjItem.h"


// CTSAttr_COND_ObjItem ��ȭ �����Դϴ�.

IMPLEMENT_SERIAL(CTSAttr_COND_ObjItem, CTSAttr_Page, 1)

CTSAttr_COND_ObjItem::CTSAttr_COND_ObjItem()
	: CTSAttr_Page(CTSAttr_COND_ObjItem::IDD)
	, m_tcQuestId( NTL_TS_T_ID_INVALID )
{

}

CTSAttr_COND_ObjItem::~CTSAttr_COND_ObjItem()
{
}

CString CTSAttr_COND_ObjItem::CollectAttrDataFromDlgItems( void )
{
	CTSAttr_Page::CollectAttrDataFromDlgItems();

	CString strData;

	strData += MakeAttrData( _T("tid"), m_tcQuestId );

	return strData;
}

void CTSAttr_COND_ObjItem::SettingAttrDataToDlgItems( CString& strKey, CString& strValue )
{
	if ( _T("tid") == strKey )
	{
		m_tcQuestId = atoi( strValue.GetBuffer() );
	}
}

void CTSAttr_COND_ObjItem::DoDataExchange(CDataExchange* pDX)
{
	CTSAttr_Page::DoDataExchange(pDX);

	DDX_Text(pDX, IDC_TS_COND_ATTR_PROGQST_TID_EDITOR, m_tcQuestId);
	DDV_MinMaxUInt(pDX, m_tcQuestId, 0, NTL_TS_T_ID_INVALID);
}


BEGIN_MESSAGE_MAP(CTSAttr_COND_ObjItem, CTSAttr_Page)
END_MESSAGE_MAP()


// CTSAttr_COND_ObjItem �޽��� ó�����Դϴ�.
