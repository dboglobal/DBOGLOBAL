#include "stdafx.h"
#include "NtlTSTool.h"
#include "Shape_End.h"

#include "TSProjectEntity.h"


IMPLEMENT_SERIAL( CShape_End, CTSShapeBox, 1 )


CShape_End::CShape_End( void )
{
}


CShape_End::CShape_End( const CPoint& ptPos, CTSGroup* pParent )
: CTSShapeBox( ptPos, pParent )
{
	// Name

	sSHAPE_NAME sName;	sName.strShapeType = _T("cont_end");
	SetShapeName( sName );

	// Container attribute

	CString strTemp;
	strTemp.Format( _T("%d"), eEND_TYPE_NOT_PROGRESS );
	AddShapeAttr( _T("type"), strTemp );
}


CShape_End::~CShape_End( void )
{
}


void CShape_End::Serialize( CArchive &ar )
{
	CTSShapeBox::Serialize( ar );

	if ( ar.IsStoring() )
	{
		Save( ar );
	}
	else
	{
		// Name

		sSHAPE_NAME sName;	sName.strShapeType = _T("cont_end");
		SetShapeName( sName );

		switch ( m_pParent->GetParent()->GetParent()->GetProjectEntityVersion() )
		{
		case 0:
			if ( !Load_Trig_Ver_00000000( ar ) )
			{
				return;
			}
			break;

		case 1:
			if ( !Load_Trig_Ver_00000001( ar ) )
			{
				return;
			}
			break;

		default:
			ASSERT( !_T("The version of its project entity file is wrong.") );
			return;
		}
	}
}


void CShape_End::ShowContainerEntityAttributeAddDlg( int nGroupID )
{
	AfxMessageBox( _T("����� �� �ִ� ������ �����ϴ�") );
}


void CShape_End::Save( CArchive& ar )
{
}


bool CShape_End::Load_Trig_Ver_00000000( CArchive& ar )
{
	return true;
}


bool CShape_End::Load_Trig_Ver_00000001( CArchive& ar )
{
	return true;
}
