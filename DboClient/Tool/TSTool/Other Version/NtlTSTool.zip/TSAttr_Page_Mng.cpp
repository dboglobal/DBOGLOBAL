#include "stdafx.h"
#include "TSAttr_Page_Mng.h"
#include "TSAttr_Page.h"


IMPLEMENT_DYNAMIC( CTSAttr_Page_Mng, COptionSheet )


CTSAttr_Page_Mng::CTSAttr_Page_Mng( CWnd* pParent /*=NULL*/ )
: COptionSheet( _T("�Ӽ� â"), pParent )
{
	m_pActivatedPage = NULL;
}

CTSAttr_Page_Mng::~CTSAttr_Page_Mng( void )
{
}

CTSAttr_Page* CTSAttr_Page_Mng::GetActivatedPage( void )
{
	return m_pActivatedPage;
}

void CTSAttr_Page_Mng::AddTSAttrPage( CTSAttr_Page* pPage )
{
	AddGroup( pPage );
}

void CTSAttr_Page_Mng::ClearAllTSAttrPage( void )
{
	m_Pages.RemoveAll();
}

void CTSAttr_Page_Mng::DoDataExchange(CDataExchange* pDX)
{
	COptionSheet::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP( CTSAttr_Page_Mng, COptionSheet )
END_MESSAGE_MAP()


// CTSAttr_Page_Mng �޽��� ó�����Դϴ�.

BOOL CTSAttr_Page_Mng::OnCommand( WPARAM wParam, LPARAM lParam )
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.

	if ( IDOK == LOWORD( wParam ) && NULL != lParam )
	{
		m_pActivatedPage = DYNAMIC_DOWNCAST( CTSAttr_Page, GetActivePage() );
	}
	else
	{
		m_pActivatedPage = NULL;
	}

	return COptionSheet::OnCommand(wParam, lParam);
}
