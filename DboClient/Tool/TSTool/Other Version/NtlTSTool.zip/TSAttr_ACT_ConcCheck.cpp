// TSAttr_ACT_ConcCheck.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "NtlTSTool.h"
#include "TSAttr_ACT_ConcCheck.h"


// CTSAttr_ACT_ConcCheck ��ȭ �����Դϴ�.

IMPLEMENT_SERIAL(CTSAttr_ACT_ConcCheck, CTSAttr_Page, 1)

CTSAttr_ACT_ConcCheck::CTSAttr_ACT_ConcCheck()
	: CTSAttr_Page(CTSAttr_ACT_ConcCheck::IDD)
	, m_taID( NTL_TS_TA_ID_INVALID )
	, m_nConcCheckCnt( 2 )
	, m_dwResetTime( 0 )
	, m_dwObjIdx( 0xffffffff )
	, m_dwExcTID( NTL_TS_T_ID_INVALID )
{

}

CTSAttr_ACT_ConcCheck::~CTSAttr_ACT_ConcCheck()
{
}

CString CTSAttr_ACT_ConcCheck::CollectAttrDataFromDlgItems( void )
{
	CTSAttr_Page::CollectAttrDataFromDlgItems();

	CString strData;

	strData += MakeAttrData( _T("taid"), m_taID );
	strData += MakeAttrData( _T("ccnt"), m_nConcCheckCnt );
	strData += MakeAttrData( _T("rtime"), m_dwResetTime );
	strData += MakeAttrData( _T("eobjidx"), m_dwObjIdx );
	strData += MakeAttrData( _T("etsid"), m_dwExcTID );

	return strData;
}

void CTSAttr_ACT_ConcCheck::SettingAttrDataToDlgItems( CString& strKey, CString& strValue )
{
	if ( _T("taid") == strKey )
	{
		m_taID = atoi( strValue.GetBuffer() );
	}
	else if ( _T("ccnt") == strKey )
	{
		m_nConcCheckCnt = atoi( strValue.GetBuffer() );
	}
	else if ( _T("rtime") == strKey )
	{
		m_dwResetTime = atoi( strValue.GetBuffer() );
	}
	else if ( _T("eobjidx") == strKey )
	{
		m_dwObjIdx = atoi( strValue.GetBuffer() );
	}
	else if ( _T("etsid") == strKey )
	{
		m_dwExcTID = atoi( strValue.GetBuffer() );
	}
}

void CTSAttr_ACT_ConcCheck::DoDataExchange(CDataExchange* pDX)
{
	CTSAttr_Page::DoDataExchange(pDX);

	DDX_Text(pDX, IDC_TS_ACT_ATTR_CONC_CHECK_ID_EDITOR, m_taID);
	DDV_MinMaxUInt(pDX, m_taID, 0, NTL_TS_TA_ID_INVALID);
	DDX_Text(pDX, IDC_TS_ACT_ATTR_CONC_CHECK_CONCCHECK_CNT_EDITOR, m_nConcCheckCnt);
	DDV_MinMaxUInt(pDX, m_nConcCheckCnt, 1, 10);
	DDX_Text(pDX, IDC_TS_ACT_ATTR_CONC_CHECK_CONCCHECK_RESETTIME_EDITOR, m_dwResetTime);
	DDX_Text(pDX, IDC_TS_ACT_ATTR_CONC_CHECK_CONCCHECK_EXC_OBJIDX_EDITOR, m_dwObjIdx);
	DDX_Text(pDX, IDC_TS_ACT_ATTR_CONC_CHECK_CONCCHECK_EXC_TID_EDITOR, m_dwExcTID);
}

BOOL CTSAttr_ACT_ConcCheck::OnInitDialog()
{
	CTSAttr_Page::OnInitDialog();

	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}


BEGIN_MESSAGE_MAP(CTSAttr_ACT_ConcCheck, CTSAttr_Page)
END_MESSAGE_MAP()


// CTSAttr_ACT_ConcCheck �޽��� ó�����Դϴ�.
