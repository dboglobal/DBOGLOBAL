#pragma once


#include <map>


class CTSAttr_Page;


class CTSConverter
{

// Declarations
public:
	typedef std::map< CString, CString > defStringMap;
	typedef std::map< CString, defStringMap > defStringDoubleMap;
	typedef std::map< CString, CRuntimeClass* > mapdefPageMap;


// Member variables
public:
	defStringMap						m_defContainerTypeNameMap;
	defStringMap						m_defContainerNameTypeMap;

	defStringDoubleMap					m_defContainerAttrTypeNameMap;
	defStringDoubleMap					m_defContainerAttrNameTypeMap;

	defStringMap						m_defEntityTypeNameMap;
	defStringMap						m_defEntityNameTypeMap;

	defStringDoubleMap					m_defEntityAttrTypeNameMap;
	defStringDoubleMap					m_defEntityAttrNameTypeMap;

	mapdefPageMap						m_defPageMap;


// Constructions and Destructions
public:

	CTSConverter( void );
	~CTSConverter( void );


// Methods
public:

	static void							Create( void );
	static void							Delete( void );

	CString								GetContainerName( const CString& strType );
	CString								GetContainerType( const CString& strName );

	CString								GetContainerAttrName( const CString& strContType, const CString& strType );
	CString								GetContainerAttrType( const CString& strContType, const CString& strName );

	CString								GetEntityName( const CString& strType );
	CString								GetEntityType( const CString& strName );

	CString								GetEntityAttrName( const CString& strEntityType, const CString& strType );
	CString								GetEntityAttrType( const CString& strEntityType, const CString& strName );

	CTSAttr_Page*						GetAttrPage( const CString& strAttrTYpe );
};


extern CTSConverter* g_pTSConverter;