// TSAttr_ACT_InSSM.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "NtlTSTool.h"
#include "TSAttr_ACT_InSSM.h"


// CTSAttr_ACT_InSSM ��ȭ �����Դϴ�.

IMPLEMENT_SERIAL(CTSAttr_ACT_InSSM, CTSAttr_Page, 1)

CTSAttr_ACT_InSSM::CTSAttr_ACT_InSSM()
	: CTSAttr_Page(CTSAttr_ACT_InSSM::IDD)
	, m_taID(NTL_TS_TA_ID_INVALID)
	, m_dwValue(0xffffffff)
{

}

CTSAttr_ACT_InSSM::~CTSAttr_ACT_InSSM()
{
}

CString CTSAttr_ACT_InSSM::CollectAttrDataFromDlgItems( void )
{
	CTSAttr_Page::CollectAttrDataFromDlgItems();

	CString strData;

	strData += MakeAttrData( _T("taid"), m_taID );
	strData += MakeAttrData( _T("ssmid"), (int)m_ctrSSMId.GetItemData( m_ctrSSMId.GetCurSel() ) );
	strData += MakeAttrData( _T("val"), m_dwValue );

	return strData;
}

void CTSAttr_ACT_InSSM::SettingAttrDataToDlgItems( CString& strKey, CString& strValue )
{
	if ( _T("taid") == strKey )
	{
		m_taID = atoi( strValue.GetBuffer() );
	}
	else if ( _T("ssmid") == strKey )
	{
		int nValue = atoi( strValue.GetBuffer() );

		int nCnt = m_ctrSSMId.GetCount();
		for ( int i = 0; i < nCnt; ++i )
		{
			if ( m_ctrSSMId.GetItemData( i ) == nValue )
			{
				m_ctrSSMId.SetCurSel( i );
				break;
			}
		}
	}
	else if ( _T("val") == strKey )
	{
		m_dwValue = atoi( strValue.GetBuffer() );
	}
}

void CTSAttr_ACT_InSSM::DoDataExchange(CDataExchange* pDX)
{
	CTSAttr_Page::DoDataExchange(pDX);

	DDX_Text(pDX, IDC_TS_ACT_ATTR_INSSM_ID_EDITOR, m_taID);
	DDV_MinMaxUInt(pDX, m_taID, 0, NTL_TS_TA_ID_INVALID);
	DDX_Control(pDX, IDC_TS_ACT_ATTR_INSSM_SSMID_COMBO, m_ctrSSMId);
	DDX_Text(pDX, IDC_TS_ACT_ATTR_INSSM_VARIABLE_EDITOR, m_dwValue);
}

BOOL CTSAttr_ACT_InSSM::OnInitDialog()
{
	CTSAttr_Page::OnInitDialog();

	// TODO:  ���⿡ �߰� �ʱ�ȭ �۾��� �߰��մϴ�.
	m_ctrSSMId.SetItemData( m_ctrSSMId.AddString( _T("Slot 0") ), eSSM_ID_0 );
	m_ctrSSMId.SetItemData( m_ctrSSMId.AddString( _T("Slot 1") ), eSSM_ID_1 );
	m_ctrSSMId.SetItemData( m_ctrSSMId.AddString( _T("Slot 2") ), eSSM_ID_2 );
	m_ctrSSMId.SetItemData( m_ctrSSMId.AddString( _T("Slot 3") ), eSSM_ID_3 );
	m_ctrSSMId.SetItemData( m_ctrSSMId.AddString( _T("Slot 4") ), eSSM_ID_4 );
	m_ctrSSMId.SetItemData( m_ctrSSMId.AddString( _T("Slot 5") ), eSSM_ID_5 );
	m_ctrSSMId.SetItemData( m_ctrSSMId.AddString( _T("Slot 6") ), eSSM_ID_6 );
	m_ctrSSMId.SetItemData( m_ctrSSMId.AddString( _T("Slot 7") ), eSSM_ID_7 );
	int nIdx = m_ctrSSMId.AddString( _T("Invalid") );
	m_ctrSSMId.SetItemData( nIdx, eSSM_ID_INVALID );
	m_ctrSSMId.SetCurSel( nIdx );

	if ( m_strAllAttrData.GetLength() > 0 )
	{
		CTSAttr_Page::SettingAttrDataToDlgItems( m_strAllAttrData );
	}

	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}

BEGIN_MESSAGE_MAP(CTSAttr_ACT_InSSM, CTSAttr_Page)
END_MESSAGE_MAP()


// CTSAttr_ACT_InSSM �޽��� ó�����Դϴ�.
