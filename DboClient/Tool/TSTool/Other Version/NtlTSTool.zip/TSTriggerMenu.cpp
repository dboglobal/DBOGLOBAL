// TSTriggerMenu.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "NtlTSTool.h"
#include "TSTriggerMenu.h"
#include "MainFrm.h"
#include "NtlTSToolDoc.h"
#include "GroupIDInputBox.h"
#include "TSProjectEntity.h"


// CTSTriggerMenu

CTSTriggerMenu* g_pTrigerMenu = NULL;


IMPLEMENT_DYNCREATE(CTSTriggerMenu, CXTResizeFormView)

CTSTriggerMenu::CTSTriggerMenu()
	: CXTResizeFormView(CTSTriggerMenu::IDD)
{
	ASSERT( NULL == g_pTrigerMenu );
	g_pTrigerMenu = this;
}

CTSTriggerMenu::~CTSTriggerMenu()
{
	ASSERT( g_pTrigerMenu );
	g_pTrigerMenu = NULL;
}

void CTSTriggerMenu::DoDataExchange(CDataExchange* pDX)
{
	CXTResizeFormView::DoDataExchange(pDX);
	DDX_Control(pDX, IDD_TSTRIGGERMENU_MG_S, m_ctrMG_S);
	DDX_Control(pDX, IDD_TSTRIGGERMENU_CMG, m_ctrCMG);
	DDX_Control(pDX, IDD_TSTRIGGERMENU_SG_S, m_ctrSG_S);
	DDX_Control(pDX, IDD_TSTRIGGERMENU_CTL, m_ctrCTL);
	DDX_Control(pDX, IDD_TSTRIGGERMENU_CSVR, m_ctrCSVR);
	DDX_Control(pDX, IDD_TSTRIGGERMENU_CCLIENT, m_ctrCClient);
	DDX_Control(pDX, IDD_TSTRIGGERMENU_CGIVEUP, m_ctrCGiveUp);
	DDX_Control(pDX, IDD_TSTRIGGERMENU_DSG, m_ctrDSG);
	DDX_Control(pDX, IDD_TSTRIGGERMENU_GL_S, m_ctrGL_S);
	DDX_Control(pDX, IDD_TSTRIGGERMENU_GL, m_ctrGL);
}

BEGIN_MESSAGE_MAP(CTSTriggerMenu, CXTResizeFormView)
	ON_BN_CLICKED(IDD_TSTRIGGERMENU_CMG, &CTSTriggerMenu::OnBnClickedTstriggermenuCmg)
	ON_BN_CLICKED(IDD_TSTRIGGERMENU_CTL, &CTSTriggerMenu::OnBnClickedTstriggermenuCtl)
	ON_BN_CLICKED(IDD_TSTRIGGERMENU_CSVR, &CTSTriggerMenu::OnBnClickedTstriggermenuCsvr)
	ON_BN_CLICKED(IDD_TSTRIGGERMENU_CCLIENT, &CTSTriggerMenu::OnBnClickedTstriggermenuCclient)
	ON_BN_CLICKED(IDD_TSTRIGGERMENU_CGIVEUP, &CTSTriggerMenu::OnBnClickedTstriggermenuCgiveup)
	ON_BN_CLICKED(IDD_TSTRIGGERMENU_DSG, &CTSTriggerMenu::OnBnClickedTstriggermenuDsg)
	ON_NOTIFY(NM_CLICK, IDD_TSTRIGGERMENU_GL, &CTSTriggerMenu::OnNMClickTstriggermenuGl)
END_MESSAGE_MAP()


// CTSTriggerMenu �����Դϴ�.

#ifdef _DEBUG
void CTSTriggerMenu::AssertValid() const
{
	CXTResizeFormView::AssertValid();
}

#ifndef _WIN32_WCE
void CTSTriggerMenu::Dump(CDumpContext& dc) const
{
	CXTResizeFormView::Dump(dc);
}
#endif
#endif //_DEBUG


void CTSTriggerMenu::Update( void )
{
	CMainFrame* pFrame = DYNAMIC_DOWNCAST( CMainFrame, AfxGetMainWnd() );
	ASSERT( pFrame );

	CNtlTSToolDoc* pDoc = DYNAMIC_DOWNCAST( CNtlTSToolDoc, pFrame->GetActiveDocument() );
	ASSERT( pDoc );

	m_ctrGL.DeleteAllItems();

	if ( pDoc->GetTSProjectEntity() )
	{
		// Update entity group list

		CTSGroup* pGroup;
		CString strGroupID;

		for ( int i = 0; i < (int)pDoc->GetTSProjectEntity()->GetTrigger()->GetGroupList().GetCount(); ++i )
		{
			pGroup = pDoc->GetTSProjectEntity()->GetTrigger()->GetGroupList()[i];
			strGroupID.Format( _T("%d"), pGroup->GetGroupID() );
			m_ctrGL.InsertItem( i, strGroupID, 0 );
			m_ctrGL.SetItemData( i, pGroup->GetGroupID() );
		}
	}
}


// CTSTriggerMenu �޽��� ó�����Դϴ�.


void CTSTriggerMenu::OnInitialUpdate()
{
	CXTResizeFormView::OnInitialUpdate();

	RemoveResize( IDD_TSTRIGGERMENU_MG_S );
	SetResize( IDD_TSTRIGGERMENU_MG_S, SZ_TOP_LEFT, SZ_TOP_RIGHT );

	RemoveResize( IDD_TSTRIGGERMENU_CMG );
	SetResize( IDD_TSTRIGGERMENU_CMG, SZ_TOP_LEFT, SZ_TOP_RIGHT );

	RemoveResize( IDD_TSTRIGGERMENU_SG_S );
	SetResize( IDD_TSTRIGGERMENU_SG_S, SZ_TOP_LEFT, SZ_TOP_RIGHT );

	RemoveResize( IDD_TSTRIGGERMENU_CTL );
	SetResize( IDD_TSTRIGGERMENU_CTL, SZ_TOP_LEFT, SZ_TOP_RIGHT );

	RemoveResize( IDD_TSTRIGGERMENU_CSVR );
	SetResize( IDD_TSTRIGGERMENU_CSVR, SZ_TOP_LEFT, SZ_TOP_RIGHT );

	RemoveResize( IDD_TSTRIGGERMENU_CCLIENT );
	SetResize( IDD_TSTRIGGERMENU_CCLIENT, SZ_TOP_LEFT, SZ_TOP_RIGHT );

	RemoveResize( IDD_TSTRIGGERMENU_CGIVEUP );
	SetResize( IDD_TSTRIGGERMENU_CGIVEUP, SZ_TOP_LEFT, SZ_TOP_RIGHT );

	RemoveResize( IDD_TSTRIGGERMENU_DSG );
	SetResize( IDD_TSTRIGGERMENU_DSG, SZ_TOP_LEFT, SZ_TOP_RIGHT );

	RemoveResize( IDD_TSTRIGGERMENU_GL_S );
	SetResize( IDD_TSTRIGGERMENU_GL_S, SZ_TOP_LEFT, SZ_TOP_RIGHT );

	RemoveResize( IDD_TSTRIGGERMENU_GL );
	SetResize( IDD_TSTRIGGERMENU_GL, SZ_TOP_LEFT, SZ_BOTTOM_RIGHT );

	m_ctrCMG.SetXButtonStyle(BS_XT_SEMIFLAT | BS_XT_WINXP_COMPAT);
	m_ctrCTL.SetXButtonStyle(BS_XT_SEMIFLAT | BS_XT_WINXP_COMPAT);
	m_ctrCSVR.SetXButtonStyle(BS_XT_SEMIFLAT | BS_XT_WINXP_COMPAT);
	m_ctrCClient.SetXButtonStyle(BS_XT_SEMIFLAT | BS_XT_WINXP_COMPAT);
	m_ctrCGiveUp.SetXButtonStyle(BS_XT_SEMIFLAT | BS_XT_WINXP_COMPAT);
	m_ctrDSG.SetXButtonStyle(BS_XT_SEMIFLAT | BS_XT_WINXP_COMPAT);

	m_ctrGL.ModifyExtendedStyle(0, LVS_EX_FULLROWSELECT|LVS_EX_FULLROWSELECT);

	m_ctrGL.DeleteColumn( 0 );
	m_ctrGL.InsertColumn( 0, _T("Group id"), LVCFMT_LEFT, 200 );

	Update();

	SetScrollSizes( MM_TEXT, CSize( 111, 261 ) );
	Invalidate();
}

void CTSTriggerMenu::OnBnClickedTstriggermenuCmg()
{
	CMainFrame* pFrame = DYNAMIC_DOWNCAST( CMainFrame, AfxGetMainWnd() );
	ASSERT( pFrame );

	CNtlTSToolDoc* pDoc = DYNAMIC_DOWNCAST( CNtlTSToolDoc, pFrame->GetActiveDocument() );
	ASSERT( pDoc );

	pDoc->OnCreateMainGroup();

	Update();
}

void CTSTriggerMenu::OnBnClickedTstriggermenuCtl()
{
	CMainFrame* pFrame = DYNAMIC_DOWNCAST( CMainFrame, AfxGetMainWnd() );
	ASSERT( pFrame );

	CNtlTSToolDoc* pDoc = DYNAMIC_DOWNCAST( CNtlTSToolDoc, pFrame->GetActiveDocument() );
	ASSERT( pDoc );

	CGroupIDInputBox clDlg;
	if ( IDOK == clDlg.DoModal() )
	{
		pDoc->OnCreateTimeLimitGroup( clDlg.m_byGroupID );

		Update();
	}
}

void CTSTriggerMenu::OnBnClickedTstriggermenuCsvr()
{
	CMainFrame* pFrame = DYNAMIC_DOWNCAST( CMainFrame, AfxGetMainWnd() );
	ASSERT( pFrame );

	CNtlTSToolDoc* pDoc = DYNAMIC_DOWNCAST( CNtlTSToolDoc, pFrame->GetActiveDocument() );
	ASSERT( pDoc );

	CGroupIDInputBox clDlg;
	if ( IDOK == clDlg.DoModal() )
	{
		pDoc->OnCreateServerGroup( clDlg.m_byGroupID );

		Update();
	}
}

void CTSTriggerMenu::OnBnClickedTstriggermenuCclient()
{
	CMainFrame* pFrame = DYNAMIC_DOWNCAST( CMainFrame, AfxGetMainWnd() );
	ASSERT( pFrame );

	CNtlTSToolDoc* pDoc = DYNAMIC_DOWNCAST( CNtlTSToolDoc, pFrame->GetActiveDocument() );
	ASSERT( pDoc );

	CGroupIDInputBox clDlg;
	if ( IDOK == clDlg.DoModal() )
	{
		pDoc->OnCreateClientGroup( clDlg.m_byGroupID );

		Update();
	}
}

void CTSTriggerMenu::OnBnClickedTstriggermenuCgiveup()
{
	CMainFrame* pFrame = DYNAMIC_DOWNCAST( CMainFrame, AfxGetMainWnd() );
	ASSERT( pFrame );

	CNtlTSToolDoc* pDoc = DYNAMIC_DOWNCAST( CNtlTSToolDoc, pFrame->GetActiveDocument() );
	ASSERT( pDoc );

	CGroupIDInputBox clDlg;
	if ( IDOK == clDlg.DoModal() )
	{
		pDoc->OnCreateGiveUpGroup( clDlg.m_byGroupID );

		Update();
	}
}

void CTSTriggerMenu::OnBnClickedTstriggermenuDsg()
{
	CMainFrame* pFrame = DYNAMIC_DOWNCAST( CMainFrame, AfxGetMainWnd() );
	ASSERT( pFrame );

	CNtlTSToolDoc* pDoc = DYNAMIC_DOWNCAST( CNtlTSToolDoc, pFrame->GetActiveDocument() );
	ASSERT( pDoc );

	CGroupIDInputBox clDlg;
	if ( IDOK == clDlg.DoModal() )
	{
		pDoc->OnDeleteSubGroup( clDlg.m_byGroupID );

		Update();
	}
}

void CTSTriggerMenu::OnNMClickTstriggermenuGl(NMHDR *pNMHDR, LRESULT *pResult)
{
	CMainFrame* pFrame = DYNAMIC_DOWNCAST( CMainFrame, AfxGetMainWnd() );
	ASSERT( pFrame );

	CNtlTSToolDoc* pDoc = DYNAMIC_DOWNCAST( CNtlTSToolDoc, pFrame->GetActiveDocument() );
	ASSERT( pDoc );

	LPNMLISTVIEW pNMListView = (LPNMLISTVIEW)pNMHDR;

	if ( -1 != pNMListView->iItem )
	{
		BYTE byGroupID = (BYTE)m_ctrGL.GetItemData( pNMListView->iItem );

		if ( 0 == byGroupID )
		{
			pDoc->SelMainGroup();
		}
		else
		{
			pDoc->SelExceptGroup( byGroupID );
		}
	}
	else
	{
		pDoc->UnselectGroup();
	}

	*pResult = 0;
}
