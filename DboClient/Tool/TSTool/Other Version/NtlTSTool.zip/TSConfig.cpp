// MainFrm.cpp : implementation of the CMainFrame class
//


#include "stdafx.h"


CTSConfig* g_pTSConfig = NULL;

CString CTSConfig::s_strToolSkinStylePath;


CTSConfig::CTSConfig( void )
{
	s_strToolSkinStylePath = _T(".\\NtlTSToolData\\WinXP.Luna.cjstyles");
}


CTSConfig::~CTSConfig( void )
{
}


void CTSConfig::Create( void )
{
	ASSERT( NULL == g_pTSConfig );
	g_pTSConfig = new CTSConfig;
}


void CTSConfig::Delete( void )
{
	if ( g_pTSConfig )
	{
		delete g_pTSConfig;
		g_pTSConfig = NULL;
	}
}

