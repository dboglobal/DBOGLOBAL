#pragma once


#include "TSAttr_Page.h"
#include "afxwin.h"


// CTSAttr_COND_PCRace ��ȭ �����Դϴ�.

class CTSAttr_COND_PCRace : public CTSAttr_Page
{
	DECLARE_SERIAL(CTSAttr_COND_PCRace)

public:
	CTSAttr_COND_PCRace();
	virtual ~CTSAttr_COND_PCRace();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_TS_COND_PCRACE_ATTR_DIAG };

protected:
	virtual CString	CollectAttrDataFromDlgItems( void );
	virtual void	SettingAttrDataToDlgItems( CString& strKey, CString& strValue );

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()

public:
	CButton m_ctrAll;
	CButton m_ctrHuman;
	CButton m_ctrNamek;
	CButton m_ctrMain;

public:
	afx_msg void OnBnClickedTsCondAttrPcraceAllCheck();
	afx_msg void OnBnClickedTsCondAttrPcraceHumanCheck();
	afx_msg void OnBnClickedTsCondAttrPcraceNamekCheck();
	afx_msg void OnBnClickedTsCondAttrPcraceMainCheck();
};
