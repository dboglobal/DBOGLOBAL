// TSProjectInfo.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"

#include "NtlTSTool.h"
#include "MainFrm.h"
#include "NtlTSToolDoc.h"

#include "TSProject.h"
#include "TSProjectInfo.h"

#include "TSTriggerMenu.h"


// CTSProjectInfo


CTSProjectInfo* g_pProjectInfo = NULL;


IMPLEMENT_DYNCREATE(CTSProjectInfo, CXTResizeFormView)

CTSProjectInfo::CTSProjectInfo()
	: CXTResizeFormView(CTSProjectInfo::IDD)
{
	ASSERT( NULL == g_pProjectInfo );
	g_pProjectInfo = this;
}

CTSProjectInfo::~CTSProjectInfo()
{
	ASSERT( g_pProjectInfo );
	g_pProjectInfo = NULL;
}

void CTSProjectInfo::DoDataExchange(CDataExchange* pDX)
{
	CXTResizeFormView::DoDataExchange(pDX);

	DDX_Control(pDX, IDD_TSPROJECTINFO_PI_S, m_ctrPI_S);
	DDX_Control(pDX, IDD_TSPROJECTINFO_PT_S, m_ctrPT_S);
	DDX_Control(pDX, IDD_TSPROJECTINFO_PT, m_ctrPT);
	DDX_Control(pDX, IDD_TSPROJECTINFO_CT, m_ctrCT);
	DDX_Control(pDX, IDD_TSPROJECTINFO_DT, m_ctrDT);
	DDX_Control(pDX, IDD_TSPROJECTINFO_TL, m_ctrTL);
}

BEGIN_MESSAGE_MAP(CTSProjectInfo, CXTResizeFormView)
	ON_BN_CLICKED(IDD_TSPROJECTINFO_CT, &CTSProjectInfo::OnBnClickedTsprojectinfoCt)
	ON_BN_CLICKED(IDD_TSPROJECTINFO_DT, &CTSProjectInfo::OnBnClickedTsprojectinfoDt)
	ON_NOTIFY(NM_CLICK, IDD_TSPROJECTINFO_TL, &CTSProjectInfo::OnNMClickTsprojectinfoTl)
	ON_WM_CREATE()
END_MESSAGE_MAP()


// CTSProjectInfo �����Դϴ�.

#ifdef _DEBUG
void CTSProjectInfo::AssertValid() const
{
	CXTResizeFormView::AssertValid();
}

#ifndef _WIN32_WCE
void CTSProjectInfo::Dump(CDumpContext& dc) const
{
	CXTResizeFormView::Dump(dc);
}
#endif
#endif //_DEBUG


void CTSProjectInfo::Update( void )
{
	CMainFrame* pFrame = DYNAMIC_DOWNCAST( CMainFrame, AfxGetMainWnd() );
	ASSERT( pFrame );

	CNtlTSToolDoc* pDoc = DYNAMIC_DOWNCAST( CNtlTSToolDoc, pFrame->GetActiveDocument() );
	ASSERT( pDoc );

	m_ctrTL.DeleteAllItems();

	if ( pDoc->GetTSProject() )
	{
		// Project info

		CString strProjMode;
		strProjMode.Format( _T("%d"), pDoc->GetTSProject()->GetProjectType() );

		m_ctrPT.SetWindowText( strProjMode );

		// Update entity file list

		int nFileCnt = (int)pDoc->GetTSProject()->GetEntityFileList().GetCount();
		for ( int i = 0; i < nFileCnt; ++i )
		{
			CString strFileName = pDoc->GetTSProject()->GetEntityFileList()[i];

			m_ctrTL.InsertItem( i, strFileName, 0 );
		}
	}
}


// CTSProjectInfo �޽��� ó�����Դϴ�.


void CTSProjectInfo::OnInitialUpdate()
{
	CXTResizeFormView::OnInitialUpdate();

	RemoveResize( IDD_TSPROJECTINFO_PI_S );
	SetResize( IDD_TSPROJECTINFO_PI_S, SZ_TOP_LEFT, SZ_TOP_RIGHT );

	RemoveResize( IDD_TSPROJECTINFO_PT_S );
	SetResize( IDD_TSPROJECTINFO_PT_S, SZ_TOP_LEFT, SZ_TOP_RIGHT );

	RemoveResize( IDD_TSPROJECTINFO_PT );
	SetResize( IDD_TSPROJECTINFO_PT, SZ_TOP_LEFT, SZ_TOP_RIGHT );

	RemoveResize( IDD_TSPROJECTINFO_CT );
	SetResize( IDD_TSPROJECTINFO_CT, SZ_TOP_LEFT, SZ_TOP_RIGHT );

	RemoveResize( IDD_TSPROJECTINFO_DT );
	SetResize( IDD_TSPROJECTINFO_DT, SZ_TOP_LEFT, SZ_TOP_RIGHT );

	RemoveResize( IDD_TSPROJECTINFO_TL );
	SetResize( IDD_TSPROJECTINFO_TL, SZ_TOP_LEFT, SZ_BOTTOM_RIGHT );

	m_ctrCT.SetXButtonStyle(BS_XT_SEMIFLAT | BS_XT_WINXP_COMPAT);
	m_ctrDT.SetXButtonStyle(BS_XT_SEMIFLAT | BS_XT_WINXP_COMPAT);

	m_ctrTL.DeleteColumn( 0 );
	m_ctrTL.InsertColumn( 0, _T("File name"), LVCFMT_LEFT, 200 );

	m_ctrTL.ModifyExtendedStyle(0, LVS_EX_FULLROWSELECT|LVS_EX_FULLROWSELECT);

	Update();

	SetScrollSizes( MM_TEXT, CSize( 111, 213 ) );
	Invalidate();
}

void CTSProjectInfo::OnBnClickedTsprojectinfoCt()
{
	CMainFrame* pFrame = DYNAMIC_DOWNCAST( CMainFrame, AfxGetMainWnd() );
	ASSERT( pFrame );

	CNtlTSToolDoc* pDoc = DYNAMIC_DOWNCAST( CNtlTSToolDoc, pFrame->GetActiveDocument() );
	ASSERT( pDoc );

	CString strDir = pDoc->GetTSProject()->GetProjectDir();

	CFileDialog clDlg( TRUE, NULL, NULL, OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT, _T("Trigger files (*.ts)|*.ts||"), NULL, 0 );

	clDlg.GetOFN().lpstrInitialDir = strDir;

	if ( IDOK == clDlg.DoModal() )
	{
		pDoc->OnCreateProjectEntity( clDlg.GetPathName() );

		Update();

		if ( g_pTrigerMenu ) g_pTrigerMenu->Update();
	}
}

void CTSProjectInfo::OnBnClickedTsprojectinfoDt()
{
	CMainFrame* pFrame = DYNAMIC_DOWNCAST( CMainFrame, AfxGetMainWnd() );
	ASSERT( pFrame );

	CNtlTSToolDoc* pDoc = DYNAMIC_DOWNCAST( CNtlTSToolDoc, pFrame->GetActiveDocument() );
	ASSERT( pDoc );

	int nSelIdx = -1;
	POSITION pos = m_ctrTL.GetFirstSelectedItemPosition();
	while ( NULL != pos )
	{
		nSelIdx = m_ctrTL.GetNextSelectedItem( pos );
	}

	if ( -1 != nSelIdx )
	{
		CString strItem = m_ctrTL.GetItemText( nSelIdx, 0 );

		CString strMsg;
		strMsg.Format( _T("Do you really delete the file ?\n[%s]"), strItem );
		if ( IDOK != AfxMessageBox( strMsg, MB_OKCANCEL ) )
		{
			return;
		}

		pDoc->OnDeleteProjectEntity( strItem );

		Update();

		if ( g_pTrigerMenu ) g_pTrigerMenu->Update();
	}
}

void CTSProjectInfo::OnNMClickTsprojectinfoTl(NMHDR *pNMHDR, LRESULT *pResult)
{
	CMainFrame* pFrame = DYNAMIC_DOWNCAST( CMainFrame, AfxGetMainWnd() );
	ASSERT( pFrame );

	CNtlTSToolDoc* pDoc = DYNAMIC_DOWNCAST( CNtlTSToolDoc, pFrame->GetActiveDocument() );
	ASSERT( pDoc );

	LPNMLISTVIEW pNMListView = (LPNMLISTVIEW)pNMHDR;

	if ( -1 != pNMListView->iItem )
	{
		CString strLoadItem = m_ctrTL.GetItemText( pNMListView->iItem, 0 );

		if ( !pDoc->OnOpenProjectEntity( strLoadItem ) )
		{
			CString strMsg;
			strMsg.Format( _T("Can not open the file.\n[%s]"), strLoadItem );
			AfxMessageBox( strMsg );
		}
	}
	else
	{
		pDoc->OnClearProjectEntity();
	}

	if ( g_pTrigerMenu ) g_pTrigerMenu->Update();

	*pResult = 0;
}
