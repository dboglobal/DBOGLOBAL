// TSAttr_CONT_Start.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "NtlTSTool.h"
#include "TSAttr_CONT_Start.h"


// CTSAttr_CONT_Start ��ȭ �����Դϴ�.

IMPLEMENT_SERIAL(CTSAttr_CONT_Start, CTSAttr_Page, 1)

CTSAttr_CONT_Start::CTSAttr_CONT_Start()
	: CTSAttr_Page(CTSAttr_CONT_Start::IDD)
	, m_tcID(NTL_TS_TC_ID_INVALID)
	, m_dwToolTip( 0xffffffff )
{

}

CTSAttr_CONT_Start::~CTSAttr_CONT_Start()
{
}

CString CTSAttr_CONT_Start::CollectAttrDataFromDlgItems( void )
{
	CTSAttr_Page::CollectAttrDataFromDlgItems();

	CString strData;

	strData += MakeAttrData( _T("cid"), m_tcID );
	strData += MakeAttrData( _T("stdiag"), m_dwToolTip );

	return strData;
}

void CTSAttr_CONT_Start::SettingAttrDataToDlgItems( CString& strKey, CString& strValue )
{
	if ( _T("cid") == strKey )
	{
		m_tcID = atoi( strValue.GetBuffer() );
	}
	if ( _T("stdiag") == strKey )
	{
		m_dwToolTip = atoi( strValue.GetBuffer() );
	}
}

void CTSAttr_CONT_Start::DoDataExchange(CDataExchange* pDX)
{
	CTSAttr_Page::DoDataExchange(pDX);

	DDX_Text(pDX, IDC_TS_CONT_ATTR_START_ID_EDITOR, m_tcID);
	DDV_MinMaxUInt(pDX, m_tcID, 0, NTL_TS_TC_ID_INVALID);
	DDX_Text(pDX, IDC_TS_CONT_ATTR_START_TOOLTIP_EDITOR, m_dwToolTip);
}

BEGIN_MESSAGE_MAP(CTSAttr_CONT_Start, CTSAttr_Page)
END_MESSAGE_MAP()


// CTSAttr_CONT_Start �޽��� ó�����Դϴ�.
