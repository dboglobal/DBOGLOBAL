#pragma once



// CTSProjectInfo �� ���Դϴ�.

class CTSProjectInfo : public CXTResizeFormView
{
	DECLARE_DYNCREATE(CTSProjectInfo)

protected:
	CTSProjectInfo();           // ���� ����⿡ ���Ǵ� protected �������Դϴ�.
	virtual ~CTSProjectInfo();

public:
	enum { IDD = IDD_TSPROJECTINFO };
#ifdef _DEBUG
	virtual void AssertValid() const;
#ifndef _WIN32_WCE
	virtual void Dump(CDumpContext& dc) const;
#endif
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()

public:
	CStatic m_ctrPI_S;
	CStatic m_ctrPT_S;
	CEdit m_ctrPT;
	CXTButton m_ctrCT;
	CXTButton m_ctrDT;
	CXTListCtrl m_ctrTL;


public:

	void	Update( void );


public:

	virtual void OnInitialUpdate();

	afx_msg void OnBnClickedTsprojectinfoCt();
	afx_msg void OnBnClickedTsprojectinfoDt();
	afx_msg void OnNMClickTsprojectinfoTl(NMHDR *pNMHDR, LRESULT *pResult);
};


extern CTSProjectInfo* g_pProjectInfo;