#pragma once


#include "afxwin.h"
#include "TSAttr_Page.h"


// CTSAttr_ACT_ConcCheck ��ȭ �����Դϴ�.

class CTSAttr_ACT_ConcCheck : public CTSAttr_Page
{
	DECLARE_SERIAL(CTSAttr_ACT_ConcCheck)

public:
	CTSAttr_ACT_ConcCheck();
	virtual ~CTSAttr_ACT_ConcCheck();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_TS_ACT_CONC_CHECK_ATTR_DIAG };

protected:
	virtual CString	CollectAttrDataFromDlgItems( void );
	virtual void	SettingAttrDataToDlgItems( CString& strKey, CString& strValue );

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.
	virtual BOOL OnInitDialog();

	DECLARE_MESSAGE_MAP()

public:
	DWORD m_taID;
	int m_nConcCheckCnt;
	DWORD m_dwResetTime;
	DWORD m_dwObjIdx;
	DWORD m_dwExcTID;
};
