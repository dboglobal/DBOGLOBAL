#include "stdafx.h"
#include "SCtrl_GCond.h"
#include "Shape_GCond.h"

#include "NtlTSToolDoc.h"
#include "NtlTSToolView.h"


CSCtrl_GCond::CSCtrl_GCond( CNtlTSToolView* pParent )
: CTSShapeBoxCtrl( pParent )
{
}


CSCtrl_GCond::~CSCtrl_GCond( void )
{
}


CTSShapeBox* CSCtrl_GCond::New( const CPoint& ptPos )
{
	CTSGroup* pGroup = m_pParent->GetDocument()->GetSelGroup();

	if ( NULL == pGroup )
	{
		ASSERT( !_T("A group must be selected.") );
		return NULL;
	}

	return new CShape_GCond( ptPos, pGroup );
}
