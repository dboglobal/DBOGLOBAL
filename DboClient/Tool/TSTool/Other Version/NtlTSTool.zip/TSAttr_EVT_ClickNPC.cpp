// TSAttr_EVT_ClickNPC.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "NtlTSTool.h"
#include "TSAttr_EVT_ClickNPC.h"


// CTSAttr_EVT_ClickNPC ��ȭ �����Դϴ�.

IMPLEMENT_SERIAL(CTSAttr_EVT_ClickNPC, CTSAttr_Page, 1)

CTSAttr_EVT_ClickNPC::CTSAttr_EVT_ClickNPC(CWnd* pParent /*=NULL*/)
	: CTSAttr_Page(CTSAttr_EVT_ClickNPC::IDD)
	, m_dwNPCIdx(0xffffffff)
{

}

CTSAttr_EVT_ClickNPC::~CTSAttr_EVT_ClickNPC()
{
}

CString CTSAttr_EVT_ClickNPC::CollectAttrDataFromDlgItems( void )
{
	CTSAttr_Page::CollectAttrDataFromDlgItems();

	CString strData;

	strData += MakeAttrData( _T("npcidx"), m_dwNPCIdx );

	return strData;
}

void CTSAttr_EVT_ClickNPC::SettingAttrDataToDlgItems( CString& strKey, CString& strValue )
{
	if ( _T("npcidx") == strKey )
	{
		m_dwNPCIdx = atoi( strValue.GetBuffer() );
	}
}

void CTSAttr_EVT_ClickNPC::DoDataExchange(CDataExchange* pDX)
{
	CTSAttr_Page::DoDataExchange(pDX);

	DDX_Text(pDX, IDC_TS_EVT_ATTR_CLICK_NPCIDX_EDITOR, m_dwNPCIdx);
}


BEGIN_MESSAGE_MAP(CTSAttr_EVT_ClickNPC, CTSAttr_Page)
END_MESSAGE_MAP()


// CTSAttr_EVT_ClickNPC �޽��� ó�����Դϴ�.
