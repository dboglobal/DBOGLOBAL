#pragma once
#include "afxwin.h"
#include "afxcmn.h"



// CTSTriggerMenu �� ���Դϴ�.

class CTSTriggerMenu : public CXTResizeFormView
{
	DECLARE_DYNCREATE(CTSTriggerMenu)

protected:
	CTSTriggerMenu();           // ���� ����⿡ ���Ǵ� protected �������Դϴ�.
	virtual ~CTSTriggerMenu();

public:
	enum { IDD = IDD_TSTRIGGERMENU };
#ifdef _DEBUG
	virtual void AssertValid() const;
#ifndef _WIN32_WCE
	virtual void Dump(CDumpContext& dc) const;
#endif
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()

public:
	CStatic m_ctrMG_S;
	CXTButton m_ctrCMG;
	CStatic m_ctrSG_S;
	CXTButton m_ctrCTL;
	CXTButton m_ctrCSVR;
	CXTButton m_ctrCClient;
	CXTButton m_ctrCGiveUp;
	CXTButton m_ctrDSG;
	CStatic m_ctrGL_S;
	CXTListCtrl m_ctrGL;

public:
	void	Update( void );

public:
	virtual void OnInitialUpdate();

	afx_msg void OnBnClickedTstriggermenuCmg();

	afx_msg void OnBnClickedTstriggermenuCtl();
	afx_msg void OnBnClickedTstriggermenuCsvr();
	afx_msg void OnBnClickedTstriggermenuCclient();
	afx_msg void OnBnClickedTstriggermenuCgiveup();
	afx_msg void OnBnClickedTstriggermenuDsg();
	afx_msg void OnNMClickTstriggermenuGl(NMHDR *pNMHDR, LRESULT *pResult);
};


extern CTSTriggerMenu* g_pTrigerMenu;