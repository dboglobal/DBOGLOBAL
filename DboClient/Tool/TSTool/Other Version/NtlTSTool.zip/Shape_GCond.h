#pragma once


#include "TSShapeBox.h"


class CShape_GCond : public CTSShapeBox
{

	DECLARE_SERIAL( CShape_GCond )


// Member variables
protected:


// Constructions and Destructions
protected:
	CShape_GCond( void );

public:
	CShape_GCond( const CPoint& ptPos, CTSGroup* pParent );
	virtual ~CShape_GCond( void );


// Methods
public:

	// Serialize

	virtual void						Serialize( CArchive &ar );


// Implementations
protected:

	virtual	void						ShowContainerEntityAttributeAddDlg( int nGroupID );

	void								Save( CArchive& ar );

	bool								Load_Trig_Ver_00000000( CArchive& ar );
	bool								Load_Trig_Ver_00000001( CArchive& ar );

};