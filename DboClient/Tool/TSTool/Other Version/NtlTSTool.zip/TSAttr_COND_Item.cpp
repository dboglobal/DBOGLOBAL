// TSAttr_COND_Item.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "NtlTSTool.h"
#include "TSAttr_COND_Item.h"


// CTSAttr_COND_Item ��ȭ �����Դϴ�.

IMPLEMENT_SERIAL(CTSAttr_COND_Item, CTSAttr_Page, 1)

CTSAttr_COND_Item::CTSAttr_COND_Item()
	: CTSAttr_Page(CTSAttr_COND_Item::IDD)
	, m_dwItemIdx(0xffffffff)
	, m_nItemCnt(0)
{

}

CTSAttr_COND_Item::~CTSAttr_COND_Item()
{
}

CString CTSAttr_COND_Item::CollectAttrDataFromDlgItems( void )
{
	CTSAttr_Page::CollectAttrDataFromDlgItems();

	CString strData;

	strData += MakeAttrData( _T("iidx"), m_dwItemIdx );
	strData += MakeAttrData( _T("icnt"), m_nItemCnt );

	return strData;
}

void CTSAttr_COND_Item::SettingAttrDataToDlgItems( CString& strKey, CString& strValue )
{
	if ( _T("iidx") == strKey )
	{
		m_dwItemIdx = atoi( strValue.GetBuffer() );
	}
	else if ( _T("icnt") == strKey )
	{
		m_nItemCnt = atoi( strValue.GetBuffer() );
	}
}

void CTSAttr_COND_Item::DoDataExchange(CDataExchange* pDX)
{
	CTSAttr_Page::DoDataExchange(pDX);

	DDX_Text(pDX, IDC_TS_COND_ATTR_ITEM_ITEMIDX_EDITOR, m_dwItemIdx);
	DDX_Text(pDX, IDC_TS_COND_ATTR_ITEM_ITEMCNT_EDITOR, m_nItemCnt);
}


BEGIN_MESSAGE_MAP(CTSAttr_COND_Item, CTSAttr_Page)
END_MESSAGE_MAP()


// CTSAttr_COND_Item �޽��� ó�����Դϴ�.
