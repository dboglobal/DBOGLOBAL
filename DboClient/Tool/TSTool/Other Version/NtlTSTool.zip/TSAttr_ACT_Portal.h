#pragma once


#include "afxwin.h"
#include "TSAttr_Page.h"


// CTSAttr_ACT_Portal ��ȭ �����Դϴ�.

class CTSAttr_ACT_Portal : public CTSAttr_Page
{
	DECLARE_SERIAL(CTSAttr_ACT_Portal)

public:
	CTSAttr_ACT_Portal();
	virtual ~CTSAttr_ACT_Portal();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_TS_ACT_POTRAL_ATTR };

protected:
	virtual CString	CollectAttrDataFromDlgItems( void );
	virtual void	SettingAttrDataToDlgItems( CString& strKey, CString& strValue );

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.
	virtual BOOL OnInitDialog();

	DECLARE_MESSAGE_MAP()

public:
	DWORD m_taID;
	CComboBox m_ctrPortalType;
	DWORD m_dwWIdx;
	CString m_strPosX, m_strPosY, m_strPosZ;
	CString m_strDirX, m_strDirY, m_strDirZ;
};
