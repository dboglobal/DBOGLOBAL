#include "stdafx.h"
#include "Shape_Proposal.h"

#include "TSProjectEntity.h"


IMPLEMENT_SERIAL( CShape_Proposal, CTSShapeBox, 1 )


CShape_Proposal::CShape_Proposal( void )
{
}


CShape_Proposal::CShape_Proposal( const CPoint& ptPos, CTSGroup* pParent )
: CTSShapeBox( ptPos, pParent )
{
	// Name

	sSHAPE_NAME sName;	sName.strShapeType = _T("cont_proposal");
	SetShapeName( sName );

	// Container attributes

	AddShapeAttr( _T("title"), CString(_T("-1")) );
	AddShapeAttr( _T("area"), CString(_T("-1")) );
	AddShapeAttr( _T("goal"), CString(_T("-1")) );
	AddShapeAttr( _T("grade"), CString(_T("-1")) );
	AddShapeAttr( _T("gtype"), CString(_T("-1")) );
	AddShapeAttr( _T("sort"), CString(_T("-1")) );
	AddShapeAttr( _T("cont"), CString(_T("-1")) );

	CString strTemp;
	strTemp.Format( _T("%d"), NTL_TS_TC_ID_INVALID );
	AddShapeAttr( _T("rwd"), strTemp );

	// Linker 

	int nHeight = g_pTSTheme->GetLinkerRadius() + 20;
	AddLinker( eLINKER_TYPE_NEXT, nHeight );

	nHeight += g_pTSTheme->GetLinkerRadius() * 2 + 2;
	AddLinker( eLINKER_TYPE_CANCEL, nHeight );
}


CShape_Proposal::~CShape_Proposal( void )
{
}


void CShape_Proposal::Serialize( CArchive &ar )
{
	CTSShapeBox::Serialize( ar );

	if ( ar.IsStoring() )
	{
		Save( ar );
	}
	else
	{
		// Name

		sSHAPE_NAME sName;	sName.strShapeType = _T("cont_proposal");
		SetShapeName( sName );

		// Linker 

		int nHeight = g_pTSTheme->GetLinkerRadius() + 20;
		AddLinker( eLINKER_TYPE_NEXT, nHeight );

		nHeight += g_pTSTheme->GetLinkerRadius() * 2 + 2;
		AddLinker( eLINKER_TYPE_CANCEL, nHeight );

		switch ( m_pParent->GetParent()->GetParent()->GetProjectEntityVersion() )
		{
		case 0:
			if ( !Load_Trig_Ver_00000000( ar ) )
			{
				return;
			}
			break;

		case 1:
			if ( !Load_Trig_Ver_00000001( ar ) )
			{
				return;
			}
			break;

		default:
			ASSERT( !_T("The version of its project entity file is wrong.") );
			return;
		}
	}
}


void CShape_Proposal::ShowContainerEntityAttributeAddDlg( int nGroupID )
{
	AfxMessageBox( _T("����� �� �ִ� ������ �����ϴ�") );
}


void CShape_Proposal::Save( CArchive& ar )
{
}


bool CShape_Proposal::Load_Trig_Ver_00000000( CArchive& ar )
{
	return true;
}


bool CShape_Proposal::Load_Trig_Ver_00000001( CArchive& ar )
{
	return true;
}
