// TSAttr_COND_SToCEvt.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "NtlTSTool.h"
#include "TSAttr_COND_SToCEvt.h"


// CTSAttr_COND_SToCEvt ��ȭ �����Դϴ�.

IMPLEMENT_SERIAL(CTSAttr_COND_SToCEvt, CTSAttr_Page, 1)

CTSAttr_COND_SToCEvt::CTSAttr_COND_SToCEvt()
	: CTSAttr_Page(CTSAttr_COND_SToCEvt::IDD)
{

}

CTSAttr_COND_SToCEvt::~CTSAttr_COND_SToCEvt()
{
}

CString CTSAttr_COND_SToCEvt::CollectAttrDataFromDlgItems( void )
{
	CTSAttr_Page::CollectAttrDataFromDlgItems();

	CString strData;

	strData += MakeAttrData( _T("itype"), (int)m_ctrSvrEvtType.GetItemData( m_ctrSvrEvtType.GetCurSel() ) );

	return strData;
}

void CTSAttr_COND_SToCEvt::SettingAttrDataToDlgItems( CString& strKey, CString& strValue )
{
	if ( _T("itype") == strKey )
	{
		int nValue = atoi( strValue.GetBuffer() );

		int nCnt = m_ctrSvrEvtType.GetCount();
		for ( int i = 0; i < nCnt; ++i )
		{
			if ( m_ctrSvrEvtType.GetItemData( i ) == nValue )
			{
				m_ctrSvrEvtType.SetCurSel( i );
				break;
			}
		}
	}
}

void CTSAttr_COND_SToCEvt::DoDataExchange(CDataExchange* pDX)
{
	CTSAttr_Page::DoDataExchange(pDX);

	DDX_Control(pDX, IDC_TS_COND_ATTR_STOCEVT_EVTTYPE_COMBO, m_ctrSvrEvtType);
}

BOOL CTSAttr_COND_SToCEvt::OnInitDialog()
{
	CTSAttr_Page::OnInitDialog();

	// TODO:  ���⿡ �߰� �ʱ�ȭ �۾��� �߰��մϴ�.
	int nIdx = m_ctrSvrEvtType.AddString( _T("Invalid") );
	m_ctrSvrEvtType.SetItemData(  nIdx, eSTOCEVT_INFO_TYPE_INVALID );
	m_ctrSvrEvtType.SetItemData( m_ctrSvrEvtType.AddString( _T("Mob kill") ), eSTOCEVT_INFO_TYPE_MOB_KILL_CNT );
	m_ctrSvrEvtType.SetItemData( m_ctrSvrEvtType.AddString( _T("Mob item") ), eSTOCEVT_INFO_TYPE_MOB_KILL_ITEM_CNT );
	m_ctrSvrEvtType.SetItemData( m_ctrSvrEvtType.AddString( _T("Item delivery") ), eSTOCEVT_INFO_TYPE_DELIVERY_ITEM );
	m_ctrSvrEvtType.SetItemData( m_ctrSvrEvtType.AddString( _T("Object item") ), eSTOCEVT_INFO_TYPE_OBJECT_ITEM );
	m_ctrSvrEvtType.SetCurSel( nIdx );

	if ( m_strAllAttrData.GetLength() > 0 )
	{
		CTSAttr_Page::SettingAttrDataToDlgItems( m_strAllAttrData );
	}

	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}


BEGIN_MESSAGE_MAP(CTSAttr_COND_SToCEvt, CTSAttr_Page)
END_MESSAGE_MAP()


// CTSAttr_COND_SToCEvt �޽��� ó�����Դϴ�.
