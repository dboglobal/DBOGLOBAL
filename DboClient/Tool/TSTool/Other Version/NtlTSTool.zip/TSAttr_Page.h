#pragma once


#include "OptionPage.h"


class CTSAttr_Page : public COptionPage
{

	DECLARE_DYNAMIC( CTSAttr_Page )


// Member variables
protected:

	CString			m_strAllAttrData;


// Constructions and Destructions
public:

	CTSAttr_Page( unsigned int uiIDD );
	virtual ~CTSAttr_Page( void );


// Methods
public:

	static CString	MakeAttrData( const CString& strAttrKey, const CString& strAttrValue );
	static CString	MakeAttrData( const CString& strAttrKey, DWORD dwAttrValue );
	static CString	MakeAttrData( const CString& strAttrKey, int nAttrValue );
	static CString	MakeAttrData( const CString& strAttrKey, unsigned int uiAttrValue );
	static CString	MakeAttrData( const CString& strAttrKey, float fAttrValue );
	static CString	GetAttrValue( const CString& strAttrData, const CString& strAttrKey );

	const CString&	GetAllAttrData( void ) const;
	void			SetAllAttrData( const CString& strAllAttrData );
	void			ClearAllAttrData( void );

	CString			GetAttr( const CString& strKey );
	void			AddAttr( const CString& strData );
	void			AddAttr( const CString& strKey, const CString& strValue );
	void			AddAttr( const CString& strKey, int nValue );


// Implementations
protected:

	virtual CString	CollectAttrDataFromDlgItems( void );

	virtual void	SettingAttrDataToDlgItems( const CString& strData );
	virtual void	SettingAttrDataToDlgItems( CString& strKey, CString& strValue );


protected:

	virtual void	DoDataExchange( CDataExchange* pDX );    // DDX/DDV �����Դϴ�.
	virtual BOOL	OnInitDialog();
	virtual void	OnOK();


	DECLARE_MESSAGE_MAP()
};
