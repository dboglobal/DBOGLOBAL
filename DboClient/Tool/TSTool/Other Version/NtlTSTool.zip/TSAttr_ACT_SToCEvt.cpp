// TSAttr_ACT_SToCEvt.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "NtlTSTool.h"
#include "TSAttr_ACT_SToCEvt.h"


// CTSAttr_ACT_SToCEvt ��ȭ �����Դϴ�.

IMPLEMENT_SERIAL(CTSAttr_ACT_SToCEvt, CTSAttr_Page, 1)

CTSAttr_ACT_SToCEvt::CTSAttr_ACT_SToCEvt()
	: CTSAttr_Page(CTSAttr_ACT_SToCEvt::IDD)
	, m_taID(NTL_TS_TA_ID_INVALID)
	, m_dwIndex1(0xffffffff)
	, m_nCount1(0)
	, m_dwIndex2(0xffffffff)
	, m_nCount2(0)
	, m_dwIndex3(0xffffffff)
	, m_nCount3(0)
{

}

CTSAttr_ACT_SToCEvt::~CTSAttr_ACT_SToCEvt()
{
}

CString CTSAttr_ACT_SToCEvt::CollectAttrDataFromDlgItems( void )
{
	CTSAttr_Page::CollectAttrDataFromDlgItems();

	CString strData;

	strData += MakeAttrData( _T("taid"), m_taID );

	if ( m_ctrStartBtn.GetCheck() == BST_CHECKED )		strData += MakeAttrData( _T("etype"), eSTOCEVT_TYPE_START );
	else if ( m_ctrEndBtn.GetCheck() == BST_CHECKED )	strData += MakeAttrData( _T("etype"), eSTOCEVT_TYPE_END );

	strData += MakeAttrData( _T("eitype"), (int)m_ctrSvrEvtType.GetItemData( m_ctrSvrEvtType.GetCurSel() ) );

	strData += MakeAttrData( _T("idx0"), m_dwIndex1 );
	strData += MakeAttrData( _T("cnt0"), m_nCount1 );
	strData += MakeAttrData( _T("idx1"), m_dwIndex2 );
	strData += MakeAttrData( _T("cnt1"), m_nCount2 );
	strData += MakeAttrData( _T("idx2"), m_dwIndex3 );
	strData += MakeAttrData( _T("cnt2"), m_nCount3 );

	return strData;
}

void CTSAttr_ACT_SToCEvt::SettingAttrDataToDlgItems( CString& strKey, CString& strValue )
{
	if ( _T("taid") == strKey )
	{
		m_taID = atoi( strValue.GetBuffer() );
	}
	else if ( _T("etype") == strKey )
	{
		eSTOCEVT_TYPE eType = (eSTOCEVT_TYPE)atoi( strValue.GetBuffer() );

		if ( eSTOCEVT_TYPE_START == eType )	m_ctrStartBtn.SetCheck( BST_CHECKED );
		else if ( eSTOCEVT_TYPE_END == eType )	m_ctrEndBtn.SetCheck( BST_CHECKED );
	}
	else if ( _T("eitype") == strKey )
	{
		int nValue = atoi( strValue.GetBuffer() );

		int nCnt = m_ctrSvrEvtType.GetCount();
		for ( int i = 0; i < nCnt; ++i )
		{
			if ( m_ctrSvrEvtType.GetItemData( i ) == nValue )
			{
				m_ctrSvrEvtType.SetCurSel( i );
				break;
			}
		}
	}
	else if ( _T("idx0") == strKey )
	{
		m_dwIndex1 = atoi( strValue.GetBuffer() );
	}
	else if ( _T("cnt0") == strKey )
	{
		m_nCount1 = atoi( strValue.GetBuffer() );
	}
	else if ( _T("idx1") == strKey )
	{
		m_dwIndex2 = atoi( strValue.GetBuffer() );
	}
	else if ( _T("cnt1") == strKey )
	{
		m_nCount2 = atoi( strValue.GetBuffer() );
	}
	else if ( _T("idx2") == strKey )
	{
		m_dwIndex3 = atoi( strValue.GetBuffer() );
	}
	else if ( _T("cnt2") == strKey )
	{
		m_nCount3 = atoi( strValue.GetBuffer() );
	}
}

void CTSAttr_ACT_SToCEvt::DoDataExchange(CDataExchange* pDX)
{
	CTSAttr_Page::DoDataExchange(pDX);

	DDX_Text(pDX, IDC_TS_ACT_ATTR_STOCEVT_ID_EDITOR, m_taID);
	DDV_MinMaxUInt(pDX, m_taID, 0, NTL_TS_TA_ID_INVALID);
	DDX_Control(pDX, IDC_TS_ACT_ATTR_STOCEVT_START_CHECK, m_ctrStartBtn);
	DDX_Control(pDX, IDC_TS_ACT_ATTR_STOCEVT_END_CHECK, m_ctrEndBtn);
	DDX_Control(pDX, IDC_TS_ACT_ATTR_STOCEVT_SVREVTTYPE_COMBO, m_ctrSvrEvtType);
	DDX_Text(pDX, IDC_TS_ACT_ATTR_STOCEVT_INDEX1_EDITOR, m_dwIndex1);
	DDV_MinMaxUInt(pDX, m_dwIndex1, 0, 0xffffffff);
	DDX_Text(pDX, IDC_TS_ACT_ATTR_STOCEVT_COUNTER1_EDITOR, m_nCount1);
	DDX_Text(pDX, IDC_TS_ACT_ATTR_STOCEVT_INDEX2_EDITOR, m_dwIndex2);
	DDV_MinMaxUInt(pDX, m_dwIndex2, 0, 0xffffffff);
	DDX_Text(pDX, IDC_TS_ACT_ATTR_STOCEVT_COUNTER2_EDITOR, m_nCount2);
	DDX_Text(pDX, IDC_TS_ACT_ATTR_STOCEVT_INDEX3_EDITOR, m_dwIndex3);
	DDV_MinMaxUInt(pDX, m_dwIndex3, 0, 0xffffffff);
	DDX_Text(pDX, IDC_TS_ACT_ATTR_STOCEVT_COUNTER3_EDITOR, m_nCount3);
}

BOOL CTSAttr_ACT_SToCEvt::OnInitDialog()
{
	CTSAttr_Page::OnInitDialog();

	// TODO:  ���⿡ �߰� �ʱ�ȭ �۾��� �߰��մϴ�.
	m_ctrStartBtn.SetCheck( BST_UNCHECKED );
	m_ctrEndBtn.SetCheck( BST_UNCHECKED );

	int nIdx = m_ctrSvrEvtType.AddString( _T("Invalid") );
	m_ctrSvrEvtType.SetItemData( nIdx, eSTOCEVT_INFO_TYPE_INVALID );
	m_ctrSvrEvtType.SetItemData( m_ctrSvrEvtType.AddString( _T("Mob kill") ), eSTOCEVT_INFO_TYPE_MOB_KILL_CNT );
	m_ctrSvrEvtType.SetItemData( m_ctrSvrEvtType.AddString( _T("Mob item") ), eSTOCEVT_INFO_TYPE_MOB_KILL_ITEM_CNT );
	m_ctrSvrEvtType.SetItemData( m_ctrSvrEvtType.AddString( _T("Delivery item") ), eSTOCEVT_INFO_TYPE_DELIVERY_ITEM );
	m_ctrSvrEvtType.SetItemData( m_ctrSvrEvtType.AddString( _T("Object item") ), eSTOCEVT_INFO_TYPE_OBJECT_ITEM );
	m_ctrSvrEvtType.SetCurSel( nIdx );

	if ( m_strAllAttrData.GetLength() > 0 )
	{
		CTSAttr_Page::SettingAttrDataToDlgItems( m_strAllAttrData );
	}

	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}


BEGIN_MESSAGE_MAP(CTSAttr_ACT_SToCEvt, CTSAttr_Page)
	ON_BN_CLICKED(IDC_TS_ACT_ATTR_STOCEVT_START_CHECK, &CTSAttr_ACT_SToCEvt::OnBnClickedTsActAttrStocevtStartCheck)
	ON_BN_CLICKED(IDC_TS_ACT_ATTR_STOCEVT_END_CHECK, &CTSAttr_ACT_SToCEvt::OnBnClickedTsActAttrStocevtEndCheck)
END_MESSAGE_MAP()


// CTSAttr_ACT_SToCEvt �޽��� ó�����Դϴ�.

void CTSAttr_ACT_SToCEvt::OnBnClickedTsActAttrStocevtStartCheck()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	if ( m_ctrStartBtn.GetCheck() == BST_CHECKED )
	{
		m_ctrEndBtn.SetCheck( BST_UNCHECKED );
	}
	else
	{
		m_ctrEndBtn.SetCheck( BST_CHECKED );
	}
}

void CTSAttr_ACT_SToCEvt::OnBnClickedTsActAttrStocevtEndCheck()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	if ( m_ctrEndBtn.GetCheck() == BST_CHECKED )
	{
		m_ctrStartBtn.SetCheck( BST_UNCHECKED );
	}
	else
	{
		m_ctrStartBtn.SetCheck( BST_CHECKED );
	}
}
