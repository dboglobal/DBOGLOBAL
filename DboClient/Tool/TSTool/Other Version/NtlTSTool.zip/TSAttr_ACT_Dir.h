#pragma once


#include "afxwin.h"
#include "TSAttr_Page.h"


// CTSAttr_ACT_Dir ��ȭ �����Դϴ�.

class CTSAttr_ACT_Dir : public CTSAttr_Page
{
	DECLARE_SERIAL(CTSAttr_ACT_Dir)

public:
	CTSAttr_ACT_Dir();
	virtual ~CTSAttr_ACT_Dir();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_TS_ACT_DIR_ATTR_DIAG };

protected:
	virtual CString	CollectAttrDataFromDlgItems( void );
	virtual void	SettingAttrDataToDlgItems( CString& strKey, CString& strValue );

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.
	virtual BOOL OnInitDialog();

	DECLARE_MESSAGE_MAP()

public:
	DWORD m_taID;
	CButton m_ctrStartBtn;
	CButton m_ctrEndBtn;
	DWORD m_tcJumpID;

public:
	afx_msg void OnBnClickedTsActAttrDirDirStartCheck();
	afx_msg void OnBnClickedTsActAttrDirDirEndCheck();
};
