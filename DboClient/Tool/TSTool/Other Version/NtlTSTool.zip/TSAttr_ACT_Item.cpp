// TSAttr_ACT_Item.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "NtlTSTool.h"
#include "TSAttr_ACT_Item.h"


// CTSAttr_ACT_Item ��ȭ �����Դϴ�.

IMPLEMENT_SERIAL(CTSAttr_ACT_Item, CTSAttr_Page, 1)

CTSAttr_ACT_Item::CTSAttr_ACT_Item()
	: CTSAttr_Page(CTSAttr_ACT_Item::IDD)
	, m_taID(NTL_TS_TA_ID_INVALID)
	, m_dwItemIdx0(0xffffffff)
	, m_dwItemIdx1(0xffffffff)
	, m_dwItemIdx2(0xffffffff)
{

}

CTSAttr_ACT_Item::~CTSAttr_ACT_Item()
{
}

CString	CTSAttr_ACT_Item::CollectAttrDataFromDlgItems( void )
{
	CTSAttr_Page::CollectAttrDataFromDlgItems();

	CString strData;

	strData += MakeAttrData( _T("taid"), m_taID );

	if ( m_ctrCreateBtn.GetCheck() == BST_CHECKED )			strData += MakeAttrData( _T("type"), eTSITEM_TYPE_CREATE );
	else if ( m_ctrDeleteBtn.GetCheck() == BST_CHECKED )	strData += MakeAttrData( _T("type"), eTSITEM_TYPE_DELETE );

	if ( 0xffffffff != m_dwItemIdx0 )
	{
		strData += MakeAttrData( _T("stype0"), (int)m_ctrSType0.GetItemData( m_ctrSType0.GetCurSel() ) );
		strData += MakeAttrData( _T("iidx0"), m_dwItemIdx0 );
	}
	if ( 0xffffffff != m_dwItemIdx1 )
	{
		strData += MakeAttrData( _T("stype1"), (int)m_ctrSType1.GetItemData( m_ctrSType1.GetCurSel() ) );
		strData += MakeAttrData( _T("iidx1"), m_dwItemIdx1 );
	}
	if ( 0xffffffff != m_dwItemIdx2 )
	{
		strData += MakeAttrData( _T("stype2"), (int)m_ctrSType2.GetItemData( m_ctrSType2.GetCurSel() ) );
		strData += MakeAttrData( _T("iidx2"), m_dwItemIdx2 );
	}

	return strData;
}

void CTSAttr_ACT_Item::SettingAttrDataToDlgItems( CString& strKey, CString& strValue )
{
	if ( _T("taid") == strKey )
	{
		m_taID = atoi( strValue.GetBuffer() );
	}
	else if ( _T("type") == strKey )
	{
		eTSITEM_TYPE eType = (eTSITEM_TYPE)atoi( strValue.GetBuffer() );

		if ( eTSITEM_TYPE_CREATE == eType )
		{
			m_ctrCreateBtn.SetCheck( BST_CHECKED );
			m_ctrDeleteBtn.SetCheck( BST_UNCHECKED );
		}
		else if ( eTSITEM_TYPE_DELETE == eType )
		{
			m_ctrCreateBtn.SetCheck( BST_UNCHECKED );
			m_ctrDeleteBtn.SetCheck( BST_CHECKED );
		}
	}
	else if ( _T("stype0") == strKey )
	{
		int nValue = atoi( strValue.GetBuffer() );

		int nCnt = m_ctrSType0.GetCount();
		for ( int i = 0; i < nCnt; ++i )
		{
			if ( m_ctrSType0.GetItemData( i ) == nValue )
			{
				m_ctrSType0.SetCurSel( i );
				break;
			}
		}
	}
	else if ( _T("iidx0") == strKey )
	{
		m_dwItemIdx0 = atoi( strValue.GetBuffer() );
	}
	else if ( _T("stype1") == strKey )
	{
		int nValue = atoi( strValue.GetBuffer() );

		int nCnt = m_ctrSType1.GetCount();
		for ( int i = 0; i < nCnt; ++i )
		{
			if ( m_ctrSType1.GetItemData( i ) == nValue )
			{
				m_ctrSType1.SetCurSel( i );
				break;
			}
		}
	}
	else if ( _T("iidx1") == strKey )
	{
		m_dwItemIdx1 = atoi( strValue.GetBuffer() );
	}
	else if ( _T("stype2") == strKey )
	{
		int nValue = atoi( strValue.GetBuffer() );

		int nCnt = m_ctrSType2.GetCount();
		for ( int i = 0; i < nCnt; ++i )
		{
			if ( m_ctrSType2.GetItemData( i ) == nValue )
			{
				m_ctrSType2.SetCurSel( i );
				break;
			}
		}
	}
	else if ( _T("iidx2") == strKey )
	{
		m_dwItemIdx2 = atoi( strValue.GetBuffer() );
	}
}

void CTSAttr_ACT_Item::DoDataExchange(CDataExchange* pDX)
{
	CTSAttr_Page::DoDataExchange(pDX);

	DDX_Text(pDX, IDC_TS_ACT_ATTR_ITEM_ID_EDITOR, m_taID);
	DDV_MinMaxUInt(pDX, m_taID, 0, NTL_TS_TA_ID_INVALID);
	DDX_Control(pDX, IDC_TS_ACT_ATTR_ITEM_CREATE_CHECK, m_ctrCreateBtn);
	DDX_Control(pDX, IDC_TS_ACT_ATTR_ITEM_DELETE_CHECK, m_ctrDeleteBtn);
	DDX_Control(pDX, IDC_TS_ACT_ATTR_ITEM_0_ITEMSLOTTYPE_COMBO, m_ctrSType0);
	DDX_Text(pDX, IDC_TS_ACT_ATTR_ITEM_0_ITEMIDX_EDITOR, m_dwItemIdx0);
	DDX_Control(pDX, IDC_TS_ACT_ATTR_ITEM_1_ITEMSLOTTYPE_COMBO, m_ctrSType1);
	DDX_Text(pDX, IDC_TS_ACT_ATTR_ITEM_1_ITEMIDX_EDITOR, m_dwItemIdx1);
	DDX_Control(pDX, IDC_TS_ACT_ATTR_ITEM_2_ITEMSLOTTYPE_COMBO, m_ctrSType2);
	DDX_Text(pDX, IDC_TS_ACT_ATTR_ITEM_2_ITEMIDX_EDITOR, m_dwItemIdx2);
}

BOOL CTSAttr_ACT_Item::OnInitDialog()
{
	CTSAttr_Page::OnInitDialog();

	// TODO:  ���⿡ �߰� �ʱ�ȭ �۾��� �߰��մϴ�.
	m_ctrCreateBtn.SetCheck( BST_CHECKED );
	m_ctrDeleteBtn.SetCheck( BST_UNCHECKED );

	int nIdx;

	m_ctrSType0.SetItemData( m_ctrSType0.AddString( _T("Equip") ), eTSITEM_SLOT_TYPE_EQUIP );
	m_ctrSType0.SetItemData( m_ctrSType0.AddString( _T("Parts") ), eTSITEM_SLOT_TYPE_PARTS );
	nIdx = m_ctrSType0.AddString( _T("Bag") ); m_ctrSType0.SetItemData( nIdx, eTSITEM_SLOT_TYPE_BAG );
	m_ctrSType0.SetCurSel( nIdx );

	m_ctrSType1.SetItemData( m_ctrSType1.AddString( _T("Equip") ), eTSITEM_SLOT_TYPE_EQUIP );
	m_ctrSType1.SetItemData( m_ctrSType1.AddString( _T("Parts") ), eTSITEM_SLOT_TYPE_PARTS );
	nIdx = m_ctrSType1.AddString( _T("Bag") ); m_ctrSType1.SetItemData( nIdx, eTSITEM_SLOT_TYPE_BAG );
	m_ctrSType1.SetCurSel( nIdx );

	m_ctrSType2.SetItemData( m_ctrSType2.AddString( _T("Equip") ), eTSITEM_SLOT_TYPE_EQUIP );
	m_ctrSType2.SetItemData( m_ctrSType2.AddString( _T("Parts") ), eTSITEM_SLOT_TYPE_PARTS );
	nIdx = m_ctrSType2.AddString( _T("Bag") ); m_ctrSType2.SetItemData( nIdx, eTSITEM_SLOT_TYPE_BAG );
	m_ctrSType2.SetCurSel( nIdx );

	if ( m_strAllAttrData.GetLength() > 0 )
	{
		CTSAttr_Page::SettingAttrDataToDlgItems( m_strAllAttrData );
	}

	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}

BEGIN_MESSAGE_MAP(CTSAttr_ACT_Item, CTSAttr_Page)
	ON_BN_CLICKED(IDC_TS_ACT_ATTR_ITEM_CREATE_CHECK, &CTSAttr_ACT_Item::OnBnClickedTsActAttrItemCreateCheck)
	ON_BN_CLICKED(IDC_TS_ACT_ATTR_ITEM_DELETE_CHECK, &CTSAttr_ACT_Item::OnBnClickedTsActAttrItemDeleteCheck)
END_MESSAGE_MAP()


// CTSAttr_ACT_Item �޽��� ó�����Դϴ�.

void CTSAttr_ACT_Item::OnBnClickedTsActAttrItemCreateCheck()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	if ( BST_CHECKED == m_ctrCreateBtn.GetCheck() )
	{
		m_ctrDeleteBtn.SetCheck( BST_UNCHECKED );
	}
	else
	{
		m_ctrDeleteBtn.SetCheck( BST_CHECKED );
	}
}

void CTSAttr_ACT_Item::OnBnClickedTsActAttrItemDeleteCheck()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	if ( BST_CHECKED == m_ctrDeleteBtn.GetCheck() )
	{
		m_ctrCreateBtn.SetCheck( BST_UNCHECKED );
	}
	else
	{
		m_ctrCreateBtn.SetCheck( BST_CHECKED );
	}
}
