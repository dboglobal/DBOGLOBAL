#include "stdafx.h"
#include "SCtrl_Switch.h"
#include "Shape_Switch.h"

#include "NtlTSToolDoc.h"
#include "NtlTSToolView.h"


CSCtrl_Switch::CSCtrl_Switch( CNtlTSToolView* pParent )
: CTSShapeBoxCtrl( pParent )
{
}


CSCtrl_Switch::~CSCtrl_Switch( void )
{
}


CTSShapeBox* CSCtrl_Switch::New( const CPoint& ptPos )
{
	CTSGroup* pGroup = m_pParent->GetDocument()->GetSelGroup();

	if ( NULL == pGroup )
	{
		ASSERT( !_T("A group must be selected.") );
		return NULL;
	}

	return new CShape_Switch( ptPos, pGroup );
}
