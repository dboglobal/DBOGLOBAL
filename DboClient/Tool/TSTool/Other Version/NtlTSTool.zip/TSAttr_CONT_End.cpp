// TSAttr_CONT_End.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "NtlTSTool.h"
#include "TSAttr_CONT_End.h"


// CTSAttr_CONT_End ��ȭ �����Դϴ�.

IMPLEMENT_SERIAL(CTSAttr_CONT_End, CTSAttr_Page, 1)

CTSAttr_CONT_End::CTSAttr_CONT_End()
	: CTSAttr_Page(CTSAttr_CONT_End::IDD)
	, m_tcID(NTL_TS_TC_ID_INVALID)
{
}

CTSAttr_CONT_End::~CTSAttr_CONT_End()
{
}

CString CTSAttr_CONT_End::CollectAttrDataFromDlgItems( void )
{
	CTSAttr_Page::CollectAttrDataFromDlgItems();

	CString strData;

	strData += MakeAttrData( _T("cid"), m_tcID );
	strData += MakeAttrData( _T("type"), (int)m_ctlEndType.GetItemData( m_ctlEndType.GetCurSel() ) );

	return strData;
}

void CTSAttr_CONT_End::SettingAttrDataToDlgItems( CString& strKey, CString& strValue )
{
	if ( _T("cid") == strKey )
	{
		m_tcID = atoi( strValue.GetBuffer() );
	}
	else if ( _T("type") == strKey )
	{
		int nValue = atoi( strValue.GetBuffer() );

		int nCnt = m_ctlEndType.GetCount();
		for ( int i = 0; i < nCnt; ++i )
		{
			if ( m_ctlEndType.GetItemData( i ) == nValue )
			{
				m_ctlEndType.SetCurSel( i );
				break;
			}
		}
	}
}

void CTSAttr_CONT_End::DoDataExchange(CDataExchange* pDX)
{
	CTSAttr_Page::DoDataExchange(pDX);

	DDX_Text(pDX, IDC_TS_CONT_ATTR_END_ID_EDITOR, m_tcID);
	DDV_MinMaxUInt(pDX, m_tcID, 0, NTL_TS_TC_ID_INVALID);
	DDX_Control(pDX, IDC_TS_CONT_ATTR_END_ENDTYPE_COMBO, m_ctlEndType);
}

BOOL CTSAttr_CONT_End::OnInitDialog()
{
	CTSAttr_Page::OnInitDialog();

	// TODO:  ���⿡ �߰� �ʱ�ȭ �۾��� �߰��մϴ�.
	m_ctlEndType.SetItemData( m_ctlEndType.AddString( _T("Complete") ), eEND_TYPE_COMPLETE );
	int nSel = m_ctlEndType.AddString( _T("Not progress") );
	m_ctlEndType.SetItemData( nSel, eEND_TYPE_NOT_PROGRESS );
	m_ctlEndType.SetCurSel( nSel );

	if ( m_strAllAttrData.GetLength() > 0 )
	{
		CTSAttr_Page::SettingAttrDataToDlgItems( m_strAllAttrData );
	}

	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}


BEGIN_MESSAGE_MAP(CTSAttr_CONT_End, CTSAttr_Page)
END_MESSAGE_MAP()


// CTSAttr_CONT_End �޽��� ó�����Դϴ�.

