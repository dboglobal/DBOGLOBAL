// TSAttr_COND_PCRace.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "NtlTSTool.h"
#include "TSAttr_COND_PCRace.h"


// CTSAttr_COND_PCRace ��ȭ �����Դϴ�.

IMPLEMENT_SERIAL(CTSAttr_COND_PCRace, CTSAttr_Page, 1)

CTSAttr_COND_PCRace::CTSAttr_COND_PCRace()
	: CTSAttr_Page(CTSAttr_COND_PCRace::IDD)
{

}

CTSAttr_COND_PCRace::~CTSAttr_COND_PCRace()
{
}

CString CTSAttr_COND_PCRace::CollectAttrDataFromDlgItems( void )
{
	CTSAttr_Page::CollectAttrDataFromDlgItems();

	CString strData;

	DWORD dwCheckFlag = 0;
	if ( m_ctrHuman.GetCheck() == BST_CHECKED ) dwCheckFlag |= (1<<RACE_HUMAN);
	if ( m_ctrNamek.GetCheck() == BST_CHECKED ) dwCheckFlag |= (1<<RACE_NAMEK);
	if ( m_ctrMain.GetCheck() == BST_CHECKED ) dwCheckFlag |= (1<<RACE_MAJIN);

	strData += MakeAttrData( _T("raceflg"), dwCheckFlag );

	return strData;
}

void CTSAttr_COND_PCRace::SettingAttrDataToDlgItems( CString& strKey, CString& strValue )
{
	if ( _T("raceflg") == strKey )
	{
		DWORD dwCheckFlag = atoi( strValue.GetBuffer() );

		if ( dwCheckFlag & (1<<RACE_HUMAN) ) m_ctrHuman.SetCheck( BST_CHECKED );
		if ( dwCheckFlag & (1<<RACE_NAMEK) ) m_ctrNamek.SetCheck( BST_CHECKED );
		if ( dwCheckFlag & (1<<RACE_MAJIN) ) m_ctrMain.SetCheck( BST_CHECKED );
	}
}

void CTSAttr_COND_PCRace::DoDataExchange(CDataExchange* pDX)
{
	CTSAttr_Page::DoDataExchange(pDX);

	DDX_Control(pDX, IDC_TS_COND_ATTR_PCRACE_ALL_CHECK, m_ctrAll);
	DDX_Control(pDX, IDC_TS_COND_ATTR_PCRACE_HUMAN_CHECK, m_ctrHuman);
	DDX_Control(pDX, IDC_TS_COND_ATTR_PCRACE_NAMEK_CHECK, m_ctrNamek);
	DDX_Control(pDX, IDC_TS_COND_ATTR_PCRACE_MAIN_CHECK, m_ctrMain);
}


BEGIN_MESSAGE_MAP(CTSAttr_COND_PCRace, CTSAttr_Page)
	ON_BN_CLICKED(IDC_TS_COND_ATTR_PCRACE_ALL_CHECK, &CTSAttr_COND_PCRace::OnBnClickedTsCondAttrPcraceAllCheck)
	ON_BN_CLICKED(IDC_TS_COND_ATTR_PCRACE_HUMAN_CHECK, &CTSAttr_COND_PCRace::OnBnClickedTsCondAttrPcraceHumanCheck)
	ON_BN_CLICKED(IDC_TS_COND_ATTR_PCRACE_NAMEK_CHECK, &CTSAttr_COND_PCRace::OnBnClickedTsCondAttrPcraceNamekCheck)
	ON_BN_CLICKED(IDC_TS_COND_ATTR_PCRACE_MAIN_CHECK, &CTSAttr_COND_PCRace::OnBnClickedTsCondAttrPcraceMainCheck)
END_MESSAGE_MAP()


// CTSAttr_COND_PCRace �޽��� ó�����Դϴ�.

void CTSAttr_COND_PCRace::OnBnClickedTsCondAttrPcraceAllCheck()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	int nRet = m_ctrAll.GetCheck();
	m_ctrHuman.SetCheck( nRet );
	m_ctrNamek.SetCheck( nRet );
	m_ctrMain.SetCheck( nRet );
}

void CTSAttr_COND_PCRace::OnBnClickedTsCondAttrPcraceHumanCheck()
{
	if ( m_ctrHuman.GetCheck() == BST_CHECKED ) m_ctrAll.SetCheck( BST_UNCHECKED );
}

void CTSAttr_COND_PCRace::OnBnClickedTsCondAttrPcraceNamekCheck()
{
	if ( m_ctrNamek.GetCheck() == BST_CHECKED ) m_ctrAll.SetCheck( BST_UNCHECKED );
}

void CTSAttr_COND_PCRace::OnBnClickedTsCondAttrPcraceMainCheck()
{
	if ( m_ctrMain.GetCheck() == BST_CHECKED ) m_ctrAll.SetCheck( BST_UNCHECKED );
}
