// TSAttr_ACT_Portal.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "NtlTSTool.h"
#include "TSAttr_ACT_Portal.h"


// CTSAttr_ACT_Portal ��ȭ �����Դϴ�.

IMPLEMENT_SERIAL(CTSAttr_ACT_Portal, CTSAttr_Page, 1)

CTSAttr_ACT_Portal::CTSAttr_ACT_Portal()
	: CTSAttr_Page(CTSAttr_ACT_Portal::IDD)
	, m_taID(NTL_TS_TA_ID_INVALID)
	, m_dwWIdx( 0xffffffff )
{

}

CTSAttr_ACT_Portal::~CTSAttr_ACT_Portal()
{
}

CString CTSAttr_ACT_Portal::CollectAttrDataFromDlgItems( void )
{
	CTSAttr_Page::CollectAttrDataFromDlgItems();

	CString strData;

	strData += MakeAttrData( _T("taid"), m_taID );
	strData += MakeAttrData( _T("type"), (int)m_ctrPortalType.GetItemData( m_ctrPortalType.GetCurSel() ) );
	strData += MakeAttrData( _T("widx"), m_dwWIdx );
	strData += MakeAttrData( _T("px"), m_strPosX );
	strData += MakeAttrData( _T("py"), m_strPosY );
	strData += MakeAttrData( _T("pz"), m_strPosZ );
	strData += MakeAttrData( _T("dx"), m_strDirX );
	strData += MakeAttrData( _T("dy"), m_strDirY );
	strData += MakeAttrData( _T("dz"), m_strDirZ );

	return strData;
}

void CTSAttr_ACT_Portal::SettingAttrDataToDlgItems( CString& strKey, CString& strValue )
{
	if ( _T("taid") == strKey )
	{
		m_taID = atoi( strValue.GetBuffer() );
	}
	else if ( _T("type") == strKey )
	{
		int nValue = atoi( strValue.GetBuffer() );

		int nCnt = m_ctrPortalType.GetCount();
		for ( int i = 0; i < nCnt; ++i )
		{
			if ( m_ctrPortalType.GetItemData( i ) == nValue )
			{
				m_ctrPortalType.SetCurSel( i );
				break;
			}
		}
	}
	else if ( _T("widx") == strKey )
	{
		m_dwWIdx = atoi( strValue.GetBuffer() );
	}
	else if ( _T("px") == strKey )
	{
		m_strPosX = strValue;
	}
	else if ( _T("py") == strKey )
	{
		m_strPosY = strValue;
	}
	else if ( _T("pz") == strKey )
	{
		m_strPosZ = strValue;
	}
	else if ( _T("dx") == strKey )
	{
		m_strDirX = strValue;
	}
	else if ( _T("dy") == strKey )
	{
		m_strDirY = strValue;
	}
	else if ( _T("dz") == strKey )
	{
		m_strDirZ = strValue;
	}
}

void CTSAttr_ACT_Portal::DoDataExchange(CDataExchange* pDX)
{
	CTSAttr_Page::DoDataExchange(pDX);

	DDX_Text(pDX, IDC_TS_ACT_ATTR_PORTAL_ID_EDITOR, m_taID);
	DDV_MinMaxUInt(pDX, m_taID, 0, NTL_TS_TA_ID_INVALID);
	DDX_Control(pDX, IDC_TS_ACT_ATTR_PORTAL_TYPE_COMBO, m_ctrPortalType);
	DDX_Text(pDX, IDC_TS_ACT_ATTR_PORTAL_WORLD_INDEX_EDITOR, m_dwWIdx);
	DDX_Text(pDX, IDC_TS_ACT_ATTR_PORTAL_POSITION_X_EDITOR, m_strPosX);
	DDX_Text(pDX, IDC_TS_ACT_ATTR_PORTAL_POSITION_Y_EDITOR, m_strPosY);
	DDX_Text(pDX, IDC_TS_ACT_ATTR_PORTAL_POSITION_Z_EDITOR, m_strPosZ);
	DDX_Text(pDX, IDC_TS_ACT_ATTR_PORTAL_DIR_X_EDITOR, m_strDirX);
	DDX_Text(pDX, IDC_TS_ACT_ATTR_PORTAL_DIR_Y_EDITOR, m_strDirY);
	DDX_Text(pDX, IDC_TS_ACT_ATTR_PORTAL_DIR_Z_EDITOR, m_strDirZ);
}

BOOL CTSAttr_ACT_Portal::OnInitDialog()
{
	CTSAttr_Page::OnInitDialog();

	// TODO:  ���⿡ �߰� �ʱ�ȭ �۾��� �߰��մϴ�.
	m_ctrPortalType.SetItemData( m_ctrPortalType.AddString( _T("Teleport") ), ePORTAL_TYPE_TELEPORT );
	int nIdx = m_ctrPortalType.AddString( _T("Gateway") );
	m_ctrPortalType.SetItemData( nIdx, ePORTAL_TYPE_GATEWAY );
	m_ctrPortalType.SetCurSel( nIdx );

	if ( m_strAllAttrData.GetLength() > 0 )
	{
		CTSAttr_Page::SettingAttrDataToDlgItems( m_strAllAttrData );
	}

	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}


BEGIN_MESSAGE_MAP(CTSAttr_ACT_Portal, CTSAttr_Page)
END_MESSAGE_MAP()


// CTSAttr_ACT_Portal �޽��� ó�����Դϴ�.
