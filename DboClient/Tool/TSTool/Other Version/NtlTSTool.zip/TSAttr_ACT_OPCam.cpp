// TSAttr_ACT_OPCam.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "NtlTSTool.h"
#include "TSAttr_ACT_OPCam.h"


// CTSAttr_ACT_OPCam ��ȭ �����Դϴ�.

IMPLEMENT_SERIAL(CTSAttr_ACT_OPCam, CTSAttr_Page, 1)

CTSAttr_ACT_OPCam::CTSAttr_ACT_OPCam()
	: CTSAttr_Page(CTSAttr_ACT_OPCam::IDD)
	, m_taID(NTL_TS_TA_ID_INVALID)
	, m_strFuncName(_T(""))
{

}

CTSAttr_ACT_OPCam::~CTSAttr_ACT_OPCam()
{
}

CString CTSAttr_ACT_OPCam::CollectAttrDataFromDlgItems( void )
{
	CTSAttr_Page::CollectAttrDataFromDlgItems();

	CString strData;

	strData += MakeAttrData( _T("taid"), m_taID );
	strData += MakeAttrData( _T("fname"), m_strFuncName );

	return strData;
}

void CTSAttr_ACT_OPCam::SettingAttrDataToDlgItems( CString& strKey, CString& strValue )
{
	if ( _T("taid") == strKey )
	{
		m_taID = atoi( strValue.GetBuffer() );
	}
	else if ( _T("fname") == strKey )
	{
		m_strFuncName = strValue.GetBuffer();
	}
}

void CTSAttr_ACT_OPCam::DoDataExchange(CDataExchange* pDX)
{
	CTSAttr_Page::DoDataExchange(pDX);

	DDX_Text(pDX, IDC_TS_ACT_ATTR_OPCAM_ID_EDITOR, m_taID);
	DDV_MinMaxUInt(pDX, m_taID, 0, NTL_TS_TA_ID_INVALID);
	DDX_Text(pDX, IDC_TS_ACT_ATTR_OPCAM_SCRIPT_INDEX_EDITOR, m_strFuncName);
}


BEGIN_MESSAGE_MAP(CTSAttr_ACT_OPCam, CTSAttr_Page)
END_MESSAGE_MAP()


// CTSAttr_ACT_OPCam �޽��� ó�����Դϴ�.
