#include "stdafx.h"
#include "SCtrl_End.h"
#include "Shape_End.h"

#include "NtlTSToolDoc.h"
#include "NtlTSToolView.h"


CSCtrl_End::CSCtrl_End( CNtlTSToolView* pParent )
: CTSShapeBoxCtrl( pParent )
{
}


CSCtrl_End::~CSCtrl_End( void )
{
}


CTSShapeBox* CSCtrl_End::New( const CPoint& ptPos )
{
	CTSGroup* pGroup = m_pParent->GetDocument()->GetSelGroup();

	if ( NULL == pGroup )
	{
		ASSERT( !_T("A group must be selected.") );
		return NULL;
	}

	return new CShape_End( ptPos, pGroup );
}
