#include "stdafx.h"
#include "SCtrl_UsrSel.h"
#include "Shape_UsrSel.h"

#include "NtlTSToolDoc.h"
#include "NtlTSToolView.h"


CSCtrl_UsrSel::CSCtrl_UsrSel( CNtlTSToolView* pParent )
: CTSShapeBoxCtrl( pParent )
{
}


CSCtrl_UsrSel::~CSCtrl_UsrSel( void )
{
}


CTSShapeBox* CSCtrl_UsrSel::New( const CPoint& ptPos )
{
	CTSGroup* pGroup = m_pParent->GetDocument()->GetSelGroup();

	if ( NULL == pGroup )
	{
		ASSERT( !_T("A group must be selected.") );
		return NULL;
	}

	return new CShape_UsrSel( ptPos, pGroup );
}
