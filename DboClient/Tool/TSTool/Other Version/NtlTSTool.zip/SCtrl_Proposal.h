#pragma once


#include "TSShapeBoxCtrl.h"


class CSCtrl_Proposal : public CTSShapeBoxCtrl
{

	// Constructions and Destructions
public:

	CSCtrl_Proposal( CNtlTSToolView* pParent );
	virtual ~CSCtrl_Proposal( void );


	// Methods
public:

	virtual CTSShapeBox*				New( const CPoint& ptPos );
};
