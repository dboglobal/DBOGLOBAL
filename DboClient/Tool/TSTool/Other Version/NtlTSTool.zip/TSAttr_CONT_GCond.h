#pragma once


#include "TSAttr_Page.h"


// CTSAttr_CONT_GCond ��ȭ �����Դϴ�.

class CTSAttr_CONT_GCond : public CTSAttr_Page
{
	DECLARE_SERIAL(CTSAttr_CONT_GCond)

public:
	CTSAttr_CONT_GCond();
	virtual ~CTSAttr_CONT_GCond();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_TS_CONT_GCOND_ATTR_DIAG };

protected:
	virtual CString	CollectAttrDataFromDlgItems( void );
	virtual void	SettingAttrDataToDlgItems( CString& strKey, CString& strValue );

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	DWORD m_tcID;
};
