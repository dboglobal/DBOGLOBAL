// NtlTSToolView.cpp : implementation of the CNtlTSToolView class
//

#include "stdafx.h"
#include "NtlTSTool.h"

#include "NtlTSToolDoc.h"
#include "NtlTSToolView.h"
#include "MainFrm.h"

#include "TSShapeCtrl.h"
#include "TSShapeSelectCtrl.h"
#include "SCtrl_Start.h"
#include "SCtrl_End.h"
#include "SCtrl_GAct.h"
#include "SCtrl_GCond.h"
#include "SCtrl_Proposal.h"
#include "SCtrl_Narration.h"
#include "SCtrl_Reward.h"
#include "SCtrl_UsrSel.h"
#include "SCtrl_Switch.h"

#include "TSProjectInfo.h"
#include "TSTriggerMenu.h"

#include "TSProjectEntity.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#endif


CLIPFORMAT CNtlTSToolView::s_clClipFmt = ::RegisterClipboardFormat( "TS" );


// CNtlTSToolView

IMPLEMENT_DYNCREATE(CNtlTSToolView, CScrollView)

BEGIN_MESSAGE_MAP(CNtlTSToolView, CScrollView)
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, &CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CScrollView::OnFilePrintPreview)
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_LBUTTONDBLCLK()
	ON_WM_RBUTTONDBLCLK()
	ON_WM_MOUSEMOVE()
	ON_WM_CONTEXTMENU()
	ON_COMMAND(ID_FILE_CREATEPROJECT, OnCreateTSProject)
	ON_COMMAND(ID_FILE_OPENTSPROJECT, OnOpenTSProject)
	ON_COMMAND(ID_FILE_CLOSETSPROJECT, OnCloseTSProject)
	ON_WM_MOUSEWHEEL()
	ON_WM_KEYDOWN()
	ON_WM_ERASEBKGND()
	ON_COMMAND(ID_CONTAINER_SELECT, &CNtlTSToolView::OnContainerSelect)
	ON_UPDATE_COMMAND_UI(ID_CONTAINER_SELECT, &CNtlTSToolView::OnUpdateContainerSelect)
	ON_COMMAND(ID_CONTAINER_STARTCONTAINER, &CNtlTSToolView::OnContainerStartcontainer)
	ON_UPDATE_COMMAND_UI(ID_CONTAINER_STARTCONTAINER, &CNtlTSToolView::OnUpdateContainerStartcontainer)
	ON_COMMAND(ID_CONTAINER_ENDCONTAINER, &CNtlTSToolView::OnContainerEndcontainer)
	ON_UPDATE_COMMAND_UI(ID_CONTAINER_ENDCONTAINER, &CNtlTSToolView::OnUpdateContainerEndcontainer)
	ON_COMMAND(ID_CONTAINER_GACTIONCONTAINER, &CNtlTSToolView::OnContainerGactcontainer)
	ON_UPDATE_COMMAND_UI(ID_CONTAINER_GACTIONCONTAINER, &CNtlTSToolView::OnUpdateContainerGactcontainer)
	ON_COMMAND(ID_CONTAINER_GCONDITIONCONTAINER, &CNtlTSToolView::OnContainerGcondcontainer)
	ON_UPDATE_COMMAND_UI(ID_CONTAINER_GCONDITIONCONTAINER, &CNtlTSToolView::OnUpdateContainerGcondcontainer)
	ON_COMMAND(ID_CONTAINER_PROPOSALCONTAINER, &CNtlTSToolView::OnContainerProposalcontainer)
	ON_UPDATE_COMMAND_UI(ID_CONTAINER_PROPOSALCONTAINER, &CNtlTSToolView::OnUpdateContainerProposalcontainer)
	ON_COMMAND(ID_CONTAINER_REWARDCONTAINER, &CNtlTSToolView::OnContainerRewardcontainer)
	ON_UPDATE_COMMAND_UI(ID_CONTAINER_REWARDCONTAINER, &CNtlTSToolView::OnUpdateContainerRewardcontainer)
	ON_COMMAND(ID_CONTAINER_NARRATIONCONTAINER, &CNtlTSToolView::OnContainerNarrationcontainer)
	ON_UPDATE_COMMAND_UI(ID_CONTAINER_NARRATIONCONTAINER, &CNtlTSToolView::OnUpdateContainerNarrationcontainer)
	ON_COMMAND(ID_CONTAINER_SWITCHCONTAINER, &CNtlTSToolView::OnContainerSwitchcontainer)
	ON_UPDATE_COMMAND_UI(ID_CONTAINER_SWITCHCONTAINER, &CNtlTSToolView::OnUpdateContainerSwitchcontainer)
	ON_COMMAND(ID_CONTAINER_USERSELECTCONTAINER, &CNtlTSToolView::OnContainerUserselectcontainer)
	ON_UPDATE_COMMAND_UI(ID_CONTAINER_USERSELECTCONTAINER, &CNtlTSToolView::OnUpdateContainerUserselectcontainer)
	ON_COMMAND(ID_CONTAINER_NOTECONTAINER, &CNtlTSToolView::OnContainerNotecontainer)
	ON_UPDATE_COMMAND_UI(ID_CONTAINER_NOTECONTAINER, &CNtlTSToolView::OnUpdateContainerNotecontainer)
	ON_COMMAND(ID_EDIT_COPY, &CNtlTSToolView::OnEditCopy)
	ON_UPDATE_COMMAND_UI(ID_EDIT_COPY, &CNtlTSToolView::OnUpdateEditCopy)
	ON_COMMAND(ID_EDIT_PASTE, &CNtlTSToolView::OnEditPaste)
	ON_UPDATE_COMMAND_UI(ID_EDIT_PASTE, &CNtlTSToolView::OnUpdateEditPaste)
	ON_COMMAND(ID_EDIT_CUT, &CNtlTSToolView::OnEditCut)
	ON_UPDATE_COMMAND_UI(ID_EDIT_CUT, &CNtlTSToolView::OnUpdateEditCut)
END_MESSAGE_MAP()

// CNtlTSToolView construction/destruction


CNtlTSToolView::CNtlTSToolView()
{
	m_pShapeSelectCtrl	= new CTSShapeSelectCtrl( this );

	m_pCtrlStart		= new CSCtrl_Start( this );
	m_pCtrlEnd			= new CSCtrl_End( this );
	m_pCtrlGAct			= new CSCtrl_GAct( this );
	m_pCtrlGCond		= new CSCtrl_GCond( this );
	m_pCtrlProposal		= new CSCtrl_Proposal( this );
	m_pCtrlNarration	= new CSCtrl_Narration( this );
	m_pCtrlReward		= new CSCtrl_Reward( this );
	m_pCtrlUsrSel		= new CSCtrl_UsrSel( this );
	m_pCtrlSwitch		= new CSCtrl_Switch( this );

	m_pCurrentShapeCtrl = m_pShapeSelectCtrl;
}

CNtlTSToolView::~CNtlTSToolView()
{
	if ( m_pShapeSelectCtrl )
	{
		delete m_pShapeSelectCtrl;
		m_pShapeSelectCtrl = NULL;
	}

	if ( m_pCtrlStart )
	{
		delete m_pCtrlStart;
		m_pCtrlStart = NULL;
	}

	if ( m_pCtrlEnd )
	{
		delete m_pCtrlEnd;
		m_pCtrlEnd = NULL;
	}

	if ( m_pCtrlGAct )
	{
		delete m_pCtrlGAct;
		m_pCtrlGAct = NULL;
	}

	if ( m_pCtrlGCond )
	{
		delete m_pCtrlGCond;
		m_pCtrlGCond = NULL;
	}

	if ( m_pCtrlProposal )
	{
		delete m_pCtrlProposal;
		m_pCtrlProposal = NULL;
	}

	if ( m_pCtrlNarration )
	{
		delete m_pCtrlNarration;
		m_pCtrlNarration = NULL;
	}

	if ( m_pCtrlReward )
	{
		delete m_pCtrlReward;
		m_pCtrlReward = NULL;
	}

	if ( m_pCtrlUsrSel )
	{
		delete m_pCtrlUsrSel;
		m_pCtrlUsrSel = NULL;
	}

	if ( m_pCtrlSwitch )
	{
		delete m_pCtrlSwitch;
		m_pCtrlSwitch = NULL;
	}
}

BOOL CNtlTSToolView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CScrollView::PreCreateWindow(cs);
}

// CNtlTSToolView drawing

void CNtlTSToolView::OnPrepareDC(CDC* pDC, CPrintInfo* pInfo /*= NULL*/)
{
	CScrollView::OnPrepareDC(pDC, pInfo);

	CSize LogicalExtent, DeviceExtent;
	LogicalExtent = g_pTSTheme->GetExtent();
	DeviceExtent.cx = (int)(g_pTSTheme->GetExtent().cx * m_dScale );
	DeviceExtent.cy = (int)(g_pTSTheme->GetExtent().cx * m_dScale );

	pDC->SetMapMode( MM_ANISOTROPIC );
	pDC->SetWindowExt( LogicalExtent );
	pDC->SetViewportExt( DeviceExtent );
}

void CNtlTSToolView::OnDraw(CDC* pDC)
{
	CNtlTSToolDoc* pDoc = GetDocument();
	ASSERT_VALID( pDoc );
	if ( !pDoc ) return;

	CDC OffScreenDC, *pDrawDC = pDC;
	CBitmap OffscreenBitmap, *pOldBitmap = NULL;

	CRect rtDocClipBox;
	pDC->GetClipBox( rtDocClipBox );
	rtDocClipBox.InflateRect( 1, 1 );
	CRect rtDeviceClipBox = Doc2Device( rtDocClipBox );

	if ( !pDC->IsPrinting() )
	{
		VERIFY( OffScreenDC.CreateCompatibleDC( pDC ) );
		VERIFY( OffscreenBitmap.CreateCompatibleBitmap( pDC, rtDeviceClipBox.Width(), rtDeviceClipBox.Height() ) );
		pDrawDC = &OffScreenDC;
		OnPrepareDC( pDrawDC, NULL );

		OffScreenDC.OffsetViewportOrg( -rtDeviceClipBox.left, -rtDeviceClipBox.top );

		pOldBitmap = OffScreenDC.SelectObject( &OffscreenBitmap );

		OffScreenDC.SetBrushOrg( rtDeviceClipBox.left % 8, rtDeviceClipBox.top % 8 );
		OffScreenDC.IntersectClipRect( rtDocClipBox );
	}

	if ( !pDC->IsPrinting() )
	{
		pDrawDC->FillSolidRect( rtDocClipBox, g_pTSTheme->GetViewColor() );
	}

	GetDocument()->RenderShapes( pDrawDC );

	GetDocument()->RenderLinkTrace( pDrawDC );

	GetDocument()->RenderSelectShapes( pDrawDC );

	if ( pDrawDC != pDC )
	{
		pDC->SetViewportOrg( 0, 0 );
		pDC->SetWindowOrg( 0, 0 );
		pDC->SetMapMode( MM_TEXT );
		OffScreenDC.SetViewportOrg( 0, 0 );
		OffScreenDC.SetWindowOrg( 0, 0 );
		OffScreenDC.SetMapMode( MM_TEXT );
		pDC->BitBlt( rtDeviceClipBox.left, rtDeviceClipBox.top, rtDeviceClipBox.Width(), rtDeviceClipBox.Height(), &OffScreenDC, 0, 0, SRCCOPY );
		OffScreenDC.SelectObject( pOldBitmap );
	}
}


// CNtlTSToolView printing

BOOL CNtlTSToolView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CNtlTSToolView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CNtlTSToolView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}


// CNtlTSToolView diagnostics

#ifdef _DEBUG
void CNtlTSToolView::AssertValid() const
{
	CScrollView::AssertValid();
}

void CNtlTSToolView::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}

CNtlTSToolDoc* CNtlTSToolView::GetDocument() const // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CNtlTSToolDoc)));
	return (CNtlTSToolDoc*)m_pDocument;
}
#endif //_DEBUG


CPoint CNtlTSToolView::Device2Doc( const CPoint& p )
{
	CPoint point = p;
	CClientDC dc( this );
	OnPrepareDC( &dc, NULL );
	dc.DPtoLP( &point );
	return point;
}


CRect CNtlTSToolView::Device2Doc( const CRect& r )
{
	CRect rect = r;
	CClientDC dc( this );
	OnPrepareDC( &dc, NULL );
	dc.DPtoLP( &rect );
	rect.NormalizeRect();
	return rect;
}


CPoint CNtlTSToolView::Doc2Device( const CPoint& p )
{
	CPoint point = p;
	CClientDC dc( this );
	OnPrepareDC( &dc, NULL );
	dc.LPtoDP( &point );
	return point;
}


CRect CNtlTSToolView::Doc2Device( const CRect& r )
{
	CRect rect = r;
	CClientDC dc( this );
	OnPrepareDC( &dc, NULL );
	dc.LPtoDP( &rect );
	rect.NormalizeRect();
	return rect;
}


CPoint CNtlTSToolView::Align2Grid( const CPoint& p ) const
{
	CPoint ptGridPoint( p.x / m_GridSize.cx * m_GridSize.cx, p.y / m_GridSize.cy * m_GridSize.cy );

	if ( p.x % m_GridSize.cx > m_GridSize.cx / 2 ) ptGridPoint.x += m_GridSize.cx;
	if ( p.y % m_GridSize.cy > m_GridSize.cy / 2 ) ptGridPoint.y += m_GridSize.cy;

	return m_bGrid ? ptGridPoint : p;
}


CRect CNtlTSToolView::Align2Grid( const CRect& r ) const
{
	return CRect( Align2Grid(r.TopLeft()), Align2Grid(r.BottomRight()) );
}


void CNtlTSToolView::SetScale( double dScale )
{
	CString PercentSign;
	CString ScaleText;

	ASSERT( dScale > 0 );

	if ( dScale > 0 )
	{
		m_dScale = dScale;

		CSize size;
		size.cx = (int)( g_pTSTheme->GetExtent().cx * m_dScale );
		size.cy = (int)( g_pTSTheme->GetExtent().cy * m_dScale );

		SetScrollSizes( MM_TEXT, size );
		Invalidate();
	}
}


void CNtlTSToolView::OnInitialUpdate( void )
{
	CScrollView::OnInitialUpdate();

	m_bGrid = true;
	m_GridSize = g_pTSTheme->GetGridSize();

	m_dScale = g_pTSTheme->GetNormalScale();
	SetScale( m_dScale );

	((CMainFrame*)AfxGetMainWnd())->GetPaneManager()->FindPane( IDD_TSPROJECTINFO )->SetEnabled( xtpPaneDisabled );
	((CMainFrame*)AfxGetMainWnd())->GetPaneManager()->FindPane( IDD_TSTRIGGERMENU )->SetEnabled( xtpPaneDisabled );
}


void CNtlTSToolView::OnActivateView(BOOL bActivate, CView* pActivateView, CView* pDeactiveView)
{
	CScrollView::OnActivateView( bActivate, pActivateView, pDeactiveView );

	m_pCurrentShapeCtrl->OnDeactivate();
	m_pCurrentShapeCtrl = m_pShapeSelectCtrl;
}


// CNtlTSToolView message handlers

void CNtlTSToolView::OnLButtonDown(UINT nFlags, CPoint point)
{
	m_pCurrentShapeCtrl->OnMouseLButtonDown( Device2Doc( point ), nFlags );

	SetCapture();
}

void CNtlTSToolView::OnLButtonUp(UINT nFlags, CPoint point)
{
	ReleaseCapture();

	m_pCurrentShapeCtrl->OnMouseLButtonUp( Device2Doc( point ), nFlags );

	m_pCurrentShapeCtrl = m_pShapeSelectCtrl;
}

void CNtlTSToolView::OnLButtonDblClk(UINT nFlags, CPoint point)
{
	m_pCurrentShapeCtrl->OnMouseLButtonDoubleClick( Device2Doc( point ), nFlags );
}

void CNtlTSToolView::OnRButtonDblClk(UINT nFlags, CPoint point)
{
	m_pCurrentShapeCtrl->OnMouseRButtonDoubleClick( Device2Doc( point ), nFlags );
}

void CNtlTSToolView::OnMouseMove(UINT nFlags, CPoint point)
{
	m_pCurrentShapeCtrl->OnMouseMove( Device2Doc( point ), nFlags );
}

BOOL CNtlTSToolView::OnMouseWheel(UINT nFlags, short zDelta, CPoint pt)
{
	if ( nFlags & MK_CONTROL )
	{
		double dScale = GetScale();

		if ( zDelta > 0 )
		{
			SetScale( dScale + 0.1f );
		}
		else
		{
			if ( dScale - 0.1 > 0.0 )
			{
				SetScale( dScale - 0.1f );
			}
		}
	}

	return CScrollView::OnMouseWheel(nFlags, zDelta, pt);
}

void CNtlTSToolView::OnContextMenu(CWnd* pWnd, CPoint point)
{
	m_pCurrentShapeCtrl->OnContextMenu( Device2Doc( point ) );
}

void CNtlTSToolView::OnCreateTSProject()
{
	if ( !GetDocument()->OnCreateProject() )
	{
		return;
	}

	((CMainFrame*)AfxGetMainWnd())->GetPaneManager()->FindPane( IDD_TSPROJECTINFO )->SetEnabled( xtpPaneEnabled );
	((CMainFrame*)AfxGetMainWnd())->GetPaneManager()->FindPane( IDD_TSTRIGGERMENU )->SetEnabled( xtpPaneEnabled );	

	if ( g_pProjectInfo ) g_pProjectInfo->Update();
	if ( g_pTrigerMenu ) g_pTrigerMenu->Update();
}


void CNtlTSToolView::OnOpenTSProject()
{
	((CMainFrame*)AfxGetMainWnd())->GetPaneManager()->FindPane( IDD_TSPROJECTINFO )->SetEnabled( xtpPaneEnabled );
	((CMainFrame*)AfxGetMainWnd())->GetPaneManager()->FindPane( IDD_TSTRIGGERMENU )->SetEnabled( xtpPaneEnabled );

	if ( !GetDocument()->OnOpenProject() )
	{
		return;
	}

	if ( g_pProjectInfo ) g_pProjectInfo->Update();
	if ( g_pTrigerMenu ) g_pTrigerMenu->Update();
}


void CNtlTSToolView::OnCloseTSProject()
{
	((CMainFrame*)AfxGetMainWnd())->GetPaneManager()->FindPane( IDD_TSPROJECTINFO )->SetEnabled( xtpPaneDisabled );
	((CMainFrame*)AfxGetMainWnd())->GetPaneManager()->FindPane( IDD_TSTRIGGERMENU )->SetEnabled( xtpPaneDisabled );

	GetDocument()->OnCloseProject();

	if ( g_pProjectInfo ) g_pProjectInfo->Update();
	if ( g_pTrigerMenu ) g_pTrigerMenu->Update();
}


void CNtlTSToolView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	if ( VK_ESCAPE == nChar ) SendMessage( WM_COMMAND, ID_CONTAINER_SELECT );
	if ( '1' == nChar ) SendMessage( WM_COMMAND, ID_CONTAINER_STARTCONTAINER );
	if ( '2' == nChar ) SendMessage( WM_COMMAND, ID_CONTAINER_ENDCONTAINER );
	if ( '3' == nChar ) SendMessage( WM_COMMAND, ID_CONTAINER_GCONDITIONCONTAINER );
	if ( '4' == nChar ) SendMessage( WM_COMMAND, ID_CONTAINER_GACTIONCONTAINER );
	if ( '5' == nChar ) SendMessage( WM_COMMAND, ID_CONTAINER_PROPOSALCONTAINER );
	if ( '6' == nChar ) SendMessage( WM_COMMAND, ID_CONTAINER_REWARDCONTAINER );
	if ( '7' == nChar ) SendMessage( WM_COMMAND, ID_CONTAINER_NARRATIONCONTAINER );
	if ( '8' == nChar ) SendMessage( WM_COMMAND, ID_CONTAINER_SWITCHCONTAINER );
	if ( '9' == nChar ) SendMessage( WM_COMMAND, ID_CONTAINER_USERSELECTCONTAINER );
	if ( '0' == nChar ) SendMessage( WM_COMMAND, ID_CONTAINER_NOTECONTAINER );

	if ( VK_DELETE == nChar && !GetDocument()->GetSelectShape().IsEmpty() )
	{
		CString strMessage;
		strMessage.Format( _T("%d���� ��ü�� ���õǾ����ϴ�.\n������ ����ðڽ��ϱ�?"), GetDocument()->GetSelectShape().GetSize() );
		int nRet = AfxMessageBox( strMessage, MB_OKCANCEL );
		if ( IDOK == nRet )
		{
			while ( !GetDocument()->GetSelectShape().IsEmpty() )
			{
				GetDocument()->RemoveShape( GetDocument()->GetSelectShape().RemoveTail() );
			}
		}
	}

	CScrollView::OnKeyDown(nChar, nRepCnt, nFlags);
}

BOOL CNtlTSToolView::OnEraseBkgnd(CDC* pDC)
{
	return TRUE;
}

void CNtlTSToolView::OnContainerSelect()
{
	m_pCurrentShapeCtrl = m_pShapeSelectCtrl;
}

void CNtlTSToolView::OnUpdateContainerSelect(CCmdUI *pCmdUI)
{
	if ( !GetDocument()->IsValidDocument() ) { pCmdUI->Enable( FALSE ); return; }
	pCmdUI->SetRadio( m_pCurrentShapeCtrl == m_pShapeSelectCtrl );
}

void CNtlTSToolView::OnContainerStartcontainer()
{
	m_pCurrentShapeCtrl = m_pCtrlStart;
}

void CNtlTSToolView::OnUpdateContainerStartcontainer(CCmdUI *pCmdUI)
{
	if ( !GetDocument()->IsValidDocument() ) { pCmdUI->Enable( FALSE ); return; }
	pCmdUI->SetRadio( m_pCurrentShapeCtrl == m_pCtrlStart );
}

void CNtlTSToolView::OnContainerEndcontainer()
{
	m_pCurrentShapeCtrl = m_pCtrlEnd;
}

void CNtlTSToolView::OnUpdateContainerEndcontainer(CCmdUI *pCmdUI)
{
	if ( !GetDocument()->IsValidDocument() ) { pCmdUI->Enable( FALSE ); return; }
	pCmdUI->SetRadio( m_pCurrentShapeCtrl == m_pCtrlEnd );
}

void CNtlTSToolView::OnContainerGactcontainer()
{
	m_pCurrentShapeCtrl = m_pCtrlGAct;
}

void CNtlTSToolView::OnUpdateContainerGactcontainer(CCmdUI *pCmdUI)
{
	if ( !GetDocument()->IsValidDocument() ) { pCmdUI->Enable( FALSE ); return; }
	pCmdUI->SetRadio( m_pCurrentShapeCtrl == m_pCtrlGAct );
}

void CNtlTSToolView::OnContainerGcondcontainer()
{
	m_pCurrentShapeCtrl = m_pCtrlGCond;
}

void CNtlTSToolView::OnUpdateContainerGcondcontainer(CCmdUI *pCmdUI)
{
	if ( !GetDocument()->IsValidDocument() ) { pCmdUI->Enable( FALSE ); return; }
	pCmdUI->SetRadio( m_pCurrentShapeCtrl == m_pCtrlGCond );
}

void CNtlTSToolView::OnContainerProposalcontainer()
{
	m_pCurrentShapeCtrl = m_pCtrlProposal;
}

void CNtlTSToolView::OnUpdateContainerProposalcontainer(CCmdUI *pCmdUI)
{
	if ( !GetDocument()->IsValidDocument() ) { pCmdUI->Enable( FALSE ); return; }
	pCmdUI->SetRadio( m_pCurrentShapeCtrl == m_pCtrlProposal );
}

void CNtlTSToolView::OnContainerRewardcontainer()
{
	m_pCurrentShapeCtrl = m_pCtrlReward;
}

void CNtlTSToolView::OnUpdateContainerRewardcontainer(CCmdUI *pCmdUI)
{
	if ( !GetDocument()->IsValidDocument() ) { pCmdUI->Enable( FALSE ); return; }
	pCmdUI->SetRadio( m_pCurrentShapeCtrl == m_pCtrlReward );
}

void CNtlTSToolView::OnContainerNarrationcontainer()
{
	m_pCurrentShapeCtrl = m_pCtrlNarration;
}

void CNtlTSToolView::OnUpdateContainerNarrationcontainer(CCmdUI *pCmdUI)
{
	if ( !GetDocument()->IsValidDocument() ) { pCmdUI->Enable( FALSE ); return; }
	pCmdUI->SetRadio( m_pCurrentShapeCtrl == m_pCtrlNarration );
}

void CNtlTSToolView::OnContainerSwitchcontainer()
{
	m_pCurrentShapeCtrl = m_pCtrlSwitch;
}

void CNtlTSToolView::OnUpdateContainerSwitchcontainer(CCmdUI *pCmdUI)
{
	if ( !GetDocument()->IsValidDocument() ) { pCmdUI->Enable( FALSE ); return; }
	pCmdUI->SetRadio( m_pCurrentShapeCtrl == m_pCtrlSwitch );
}

void CNtlTSToolView::OnContainerUserselectcontainer()
{
	m_pCurrentShapeCtrl = m_pCtrlUsrSel;
}

void CNtlTSToolView::OnUpdateContainerUserselectcontainer(CCmdUI *pCmdUI)
{
	if ( !GetDocument()->IsValidDocument() ) { pCmdUI->Enable( FALSE ); return; }
	pCmdUI->SetRadio( m_pCurrentShapeCtrl == m_pCtrlUsrSel );
}

void CNtlTSToolView::OnContainerNotecontainer()
{
}

void CNtlTSToolView::OnUpdateContainerNotecontainer(CCmdUI *pCmdUI)
{
	pCmdUI->SetRadio( FALSE );
//	if ( !GetDocument()->IsValidDocument() ) { pCmdUI->Enable( FALSE ); return; }
//	pCmdUI->SetRadio( m_pCurrentShapeCtrl == m_pShapeSelectCtrl );
}

void CNtlTSToolView::OnEditCopy( void )
{
	CSharedFile clShareFile;
	CArchive ar( &clShareFile, CArchive::store );

	GetDocument()->GetSelectShape().Serialize( ar );
	ar.Close();

	CMetaFileDC mfDC;
	mfDC.CreateEnhanced( NULL, NULL, NULL, NULL );

	CSize logicalExtent, deviceExtent;
	logicalExtent = g_pTSTheme->GetExtent();
	deviceExtent.cx = (int)(g_pTSTheme->GetExtent().cx * 0.65f);
	deviceExtent.cy = (int)(g_pTSTheme->GetExtent().cy * 0.65f);
	mfDC.SetMapMode( MM_ANISOTROPIC );
	mfDC.SetWindowExt( logicalExtent );
	mfDC.SetViewportExt( deviceExtent );

	for ( POSITION pos = GetDocument()->GetSelectShape().GetTailPosition(); pos != NULL; )
	{
		GetDocument()->GetSelectShape().GetPrev( pos )->RenderShape( &mfDC );
	}

	STGMEDIUM stgMedium;
	stgMedium.hEnhMetaFile = mfDC.CloseEnhanced();
	stgMedium.tymed = TYMED_ENHMF;
	stgMedium.pUnkForRelease = NULL;

	COleDataSource* pDataSource = new COleDataSource;
	pDataSource->CacheGlobalData( s_clClipFmt, clShareFile.Detach() );
	pDataSource->CacheData( CF_ENHMETAFILE, &stgMedium );
	pDataSource->SetClipboard();
}

void CNtlTSToolView::OnUpdateEditCopy( CCmdUI *pCmdUI )
{
	pCmdUI->Enable( !GetDocument()->GetSelectShape().IsEmpty() );
}

void CNtlTSToolView::OnEditPaste( void )
{
	if ( NULL == GetDocument()->GetSelGroup() ) return;

	COleDataObject clDataObject;
	VERIFY( clDataObject.AttachClipboard() );

	if ( clDataObject.IsDataAvailable( s_clClipFmt ) )
	{
		GetDocument()->UnselectShape();

		CFile* pFile = clDataObject.GetFileData( s_clClipFmt );
		ASSERT( pFile );

		CTSGroup::s_pTempLoadGroup = GetDocument()->GetSelGroup();

		CArchive ar( pFile, CArchive::load );
		ar.m_pDocument = GetDocument();
		GetDocument()->GetSelectShape().Serialize( ar );
		ar.Close();

		CTSGroup::s_pTempLoadGroup = NULL;

		delete pFile;

		for ( POSITION pos = GetDocument()->GetSelectShape().GetHeadPosition(); pos != NULL; )
		{
			GetDocument()->AddShape( GetDocument()->GetSelectShape().GetNext( pos ) );
		}
	}
}

void CNtlTSToolView::OnUpdateEditPaste( CCmdUI *pCmdUI )
{
	COleDataObject clDataObject;
	pCmdUI->Enable( clDataObject.AttachClipboard() && clDataObject.IsDataAvailable( s_clClipFmt ) );
}

void CNtlTSToolView::OnEditCut( void )
{
	OnEditCopy();

	while ( !GetDocument()->GetSelectShape().IsEmpty() )
	{
		GetDocument()->RemoveShape( GetDocument()->GetSelectShape().RemoveTail() );
	}
}

void CNtlTSToolView::OnUpdateEditCut( CCmdUI *pCmdUI )
{
	pCmdUI->Enable( !GetDocument()->GetSelectShape().IsEmpty() );
}

