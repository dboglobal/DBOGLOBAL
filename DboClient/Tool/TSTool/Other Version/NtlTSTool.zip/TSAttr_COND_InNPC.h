#pragma once


#include "TSAttr_Page.h"
#include "afxwin.h"


// CTSAttr_COND_InNPC ��ȭ �����Դϴ�.

class CTSAttr_COND_InNPC : public CTSAttr_Page
{
	DECLARE_SERIAL(CTSAttr_COND_InNPC)

public:
	CTSAttr_COND_InNPC();
	virtual ~CTSAttr_COND_InNPC();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_TS_COND_INNPC_ATTR_DIAG };

protected:
	virtual CString	CollectAttrDataFromDlgItems( void );
	virtual void	SettingAttrDataToDlgItems( CString& strKey, CString& strValue );

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()

public:
	DWORD m_dwIndex;
	int m_nRadius;
};
