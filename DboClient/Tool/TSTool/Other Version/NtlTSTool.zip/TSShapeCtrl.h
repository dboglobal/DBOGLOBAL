#pragma once


class CNtlTSToolView;
class CTSGroup;


class CTSShapeCtrl : public CObject
{

// Member variables
protected:

	CNtlTSToolView*						m_pParent;


// Constructions and Destructions
public:

	CTSShapeCtrl( CNtlTSToolView* pParent )	{ m_pParent = pParent; }
	virtual ~CTSShapeCtrl( void )		{ return; }


// Methods
public:

	CNtlTSToolView*						GetParent( void ) const { return m_pParent; }
	void								SetParent( CNtlTSToolView* pParent ) { m_pParent = pParent; }

	virtual void						OnMouseLButtonDown( const CPoint& ptPos, UINT nFlags ) { return; }
	virtual void						OnMouseLButtonUp( const CPoint &point, UINT nFlags ) { return; }
	virtual void						OnMouseLButtonDoubleClick( const CPoint &point, UINT nFlags ) { return; }
	virtual void						OnMouseRButtonDoubleClick( const CPoint &point, UINT nFlags ) { return; }
	virtual void						OnMouseMove( const CPoint &point, UINT nFlags ) { return; }

	virtual void						OnContextMenu( const CPoint &point ) { return; }
	virtual void						OnDeactivate( void ) { return; }

};
