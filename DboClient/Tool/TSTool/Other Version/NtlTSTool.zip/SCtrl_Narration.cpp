#include "stdafx.h"
#include "SCtrl_Narration.h"
#include "Shape_Narration.h"

#include "NtlTSToolDoc.h"
#include "NtlTSToolView.h"


CSCtrl_Narration::CSCtrl_Narration( CNtlTSToolView* pParent )
: CTSShapeBoxCtrl( pParent )
{
}


CSCtrl_Narration::~CSCtrl_Narration( void )
{
}


CTSShapeBox* CSCtrl_Narration::New( const CPoint& ptPos )
{
	CTSGroup* pGroup = m_pParent->GetDocument()->GetSelGroup();

	if ( NULL == pGroup )
	{
		ASSERT( !_T("A group must be selected.") );
		return NULL;
	}

	return new CShape_Narration( ptPos, pGroup );
}
