// TSAttr_CONT_Reward.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "NtlTSTool.h"
#include "TSAttr_CONT_Reward.h"


// CTSAttr_CONT_Reward ��ȭ �����Դϴ�.

IMPLEMENT_SERIAL(CTSAttr_CONT_Reward, CTSAttr_Page, 1)

CTSAttr_CONT_Reward::CTSAttr_CONT_Reward()
	: CTSAttr_Page(CTSAttr_CONT_Reward::IDD)
	, m_tcID(NTL_TS_TC_ID_INVALID)
	, m_uiDesc(0xffffffff)
	, m_dwDefIndex0(0xffffffff)
	, m_nDefValue0(0)
	, m_dwDefIndex1(0xffffffff)
	, m_nDefValue1(0)
	, m_dwDefIndex2(0xffffffff)
	, m_nDefValue2(0)
	, m_dwDefIndex3(0xffffffff)
	, m_nDefValue3(0)
	, m_dwSelIndex0(0xffffffff)
	, m_nSelValue0(0)
	, m_dwSelIndex1(0xffffffff)
	, m_nSelValue1(0)
	, m_dwSelIndex2(0xffffffff)
	, m_nSelValue2(0)
	, m_dwSelIndex3(0xffffffff)
	, m_nSelValue3(0)
{

}

CTSAttr_CONT_Reward::~CTSAttr_CONT_Reward()
{
}

CString CTSAttr_CONT_Reward::CollectAttrDataFromDlgItems( void )
{
	CTSAttr_Page::CollectAttrDataFromDlgItems();

	CString strData;

	strData += MakeAttrData( _T("cid"), m_tcID );
	strData += MakeAttrData( _T("desc"), m_uiDesc );

	eREWARD_TYPE eType;

	// �⺻ ����
	eType = (eREWARD_TYPE)m_ctrDefRwdType0.GetItemData( m_ctrDefRwdType0.GetCurSel() );
	if ( eREWARD_TYPE_INVALID != eType )
	{
		strData += MakeAttrData( _T("dtype0"), (int)eType );
		strData += MakeAttrData( _T("didx0"), m_dwDefIndex0 );
		strData += MakeAttrData( _T("dval0"), m_nDefValue0 );
	}
	eType = (eREWARD_TYPE)m_ctrDefRwdType1.GetItemData( m_ctrDefRwdType1.GetCurSel() );
	if ( eREWARD_TYPE_INVALID != eType )
	{
		strData += MakeAttrData( _T("dtype1"), (int)eType );
		strData += MakeAttrData( _T("didx1"), m_dwDefIndex1 );
		strData += MakeAttrData( _T("dval1"), m_nDefValue1 );
	}
	eType = (eREWARD_TYPE)m_ctrDefRwdType2.GetItemData( m_ctrDefRwdType2.GetCurSel() );
	if ( eREWARD_TYPE_INVALID != eType )
	{
		strData += MakeAttrData( _T("dtype2"), (int)eType );
		strData += MakeAttrData( _T("didx2"), m_dwDefIndex2 );
		strData += MakeAttrData( _T("dval2"), m_nDefValue2 );
	}
	eType = (eREWARD_TYPE)m_ctrDefRwdType3.GetItemData( m_ctrDefRwdType3.GetCurSel() );
	if ( eREWARD_TYPE_INVALID != eType )
	{
		strData += MakeAttrData( _T("dtype3"), (int)eType );
		strData += MakeAttrData( _T("didx3"), m_dwDefIndex3 );
		strData += MakeAttrData( _T("dval3"), m_nDefValue3 );
	}

	// ���� ����
	eType = (eREWARD_TYPE)m_ctrSelRwdType0.GetItemData( m_ctrSelRwdType0.GetCurSel() );
	if ( eREWARD_TYPE_INVALID != eType )
	{
		strData += MakeAttrData( _T("stype0"), (int)eType );
		strData += MakeAttrData( _T("sidx0"), m_dwSelIndex0 );
		strData += MakeAttrData( _T("sval0"), m_nSelValue0 );
	}
	eType = (eREWARD_TYPE)m_ctrSelRwdType1.GetItemData( m_ctrSelRwdType1.GetCurSel() );
	if ( eREWARD_TYPE_INVALID != eType )
	{
		strData += MakeAttrData( _T("stype1"), (int)eType );
		strData += MakeAttrData( _T("sidx1"), m_dwSelIndex1 );
		strData += MakeAttrData( _T("sval1"), m_nSelValue1 );
	}
	eType = (eREWARD_TYPE)m_ctrSelRwdType2.GetItemData( m_ctrSelRwdType2.GetCurSel() );
	if ( eREWARD_TYPE_INVALID != eType )
	{
		strData += MakeAttrData( _T("stype2"), (int)eType );
		strData += MakeAttrData( _T("sidx2"), m_dwSelIndex2 );
		strData += MakeAttrData( _T("sval2"), m_nSelValue2 );
	}
	eType = (eREWARD_TYPE)m_ctrSelRwdType3.GetItemData( m_ctrSelRwdType3.GetCurSel() );
	if ( eREWARD_TYPE_INVALID != eType )
	{
		strData += MakeAttrData( _T("stype3"), (int)eType );
		strData += MakeAttrData( _T("sidx3"), m_dwSelIndex3 );
		strData += MakeAttrData( _T("sval3"), m_nSelValue3 );
	}

	return strData;
}

void CTSAttr_CONT_Reward::SettingAttrDataToDlgItems( CString& strKey, CString& strValue )
{
	if ( _T("cid") == strKey )
	{
		m_tcID = atoi( strValue.GetBuffer() );
	}
	if ( _T("desc") == strKey )
	{
		m_uiDesc = atoi( strValue.GetBuffer() );
	}

	// �⺻ ����
	if ( _T("dtype0") == strKey )
	{
		int nValue = atoi( strValue.GetBuffer() );

		for ( int i = 0; i < m_ctrDefRwdType0.GetCount(); ++i )
		{
			if ( m_ctrDefRwdType0.GetItemData( i ) == nValue )
			{
				m_ctrDefRwdType0.SetCurSel( i );
				break;
			}
		}
	}
	else if ( _T("didx0") == strKey )
	{
		m_dwDefIndex0 = atoi( strValue.GetBuffer() );
	}
	else if ( _T("dval0") == strKey )
	{
		m_nDefValue0 = atoi( strValue.GetBuffer() );
	}
	else if ( _T("dtype1") == strKey )
	{
		int nValue = atoi( strValue.GetBuffer() );

		for ( int i = 0; i < m_ctrDefRwdType1.GetCount(); ++i )
		{
			if ( m_ctrDefRwdType1.GetItemData( i ) == nValue )
			{
				m_ctrDefRwdType1.SetCurSel( i );
				break;
			}
		}
	}
	else if ( _T("didx1") == strKey )
	{
		m_dwDefIndex1 = atoi( strValue.GetBuffer() );
	}
	else if ( _T("dval1") == strKey )
	{
		m_nDefValue1 = atoi( strValue.GetBuffer() );
	}
	else if ( _T("dtype2") == strKey )
	{
		int nValue = atoi( strValue.GetBuffer() );

		for ( int i = 0; i < m_ctrDefRwdType2.GetCount(); ++i )
		{
			if ( m_ctrDefRwdType2.GetItemData( i ) == nValue )
			{
				m_ctrDefRwdType2.SetCurSel( i );
				break;
			}
		}
	}
	else if ( _T("didx2") == strKey )
	{
		m_dwDefIndex2 = atoi( strValue.GetBuffer() );
	}
	else if ( _T("dval2") == strKey )
	{
		m_nDefValue2 = atoi( strValue.GetBuffer() );
	}
	else if ( _T("dtype3") == strKey )
	{
		int nValue = atoi( strValue.GetBuffer() );

		for ( int i = 0; i < m_ctrDefRwdType3.GetCount(); ++i )
		{
			if ( m_ctrDefRwdType3.GetItemData( i ) == nValue )
			{
				m_ctrDefRwdType3.SetCurSel( i );
				break;
			}
		}
	}
	else if ( _T("didx3") == strKey )
	{
		m_dwDefIndex3 = atoi( strValue.GetBuffer() );
	}
	else if ( _T("dval3") == strKey )
	{
		m_nDefValue3 = atoi( strValue.GetBuffer() );
	}

	// ���� ����
	if ( _T("stype0") == strKey )
	{
		int nValue = atoi( strValue.GetBuffer() );

		for ( int i = 0; i < m_ctrSelRwdType0.GetCount(); ++i )
		{
			if ( m_ctrSelRwdType0.GetItemData( i ) == nValue )
			{
				m_ctrSelRwdType0.SetCurSel( i );
				break;
			}
		}
	}
	else if ( _T("sidx0") == strKey )
	{
		m_dwSelIndex0 = atoi( strValue.GetBuffer() );
	}
	else if ( _T("sval0") == strKey )
	{
		m_nSelValue0 = atoi( strValue.GetBuffer() );
	}
	if ( _T("stype1") == strKey )
	{
		int nValue = atoi( strValue.GetBuffer() );

		for ( int i = 0; i < m_ctrSelRwdType1.GetCount(); ++i )
		{
			if ( m_ctrSelRwdType1.GetItemData( i ) == nValue )
			{
				m_ctrSelRwdType1.SetCurSel( i );
				break;
			}
		}
	}
	else if ( _T("sidx1") == strKey )
	{
		m_dwSelIndex1 = atoi( strValue.GetBuffer() );
	}
	else if ( _T("sval1") == strKey )
	{
		m_nSelValue1 = atoi( strValue.GetBuffer() );
	}
	if ( _T("stype2") == strKey )
	{
		int nValue = atoi( strValue.GetBuffer() );

		for ( int i = 0; i < m_ctrSelRwdType2.GetCount(); ++i )
		{
			if ( m_ctrSelRwdType2.GetItemData( i ) == nValue )
			{
				m_ctrSelRwdType2.SetCurSel( i );
				break;
			}
		}
	}
	else if ( _T("sidx2") == strKey )
	{
		m_dwSelIndex2 = atoi( strValue.GetBuffer() );
	}
	else if ( _T("sval2") == strKey )
	{
		m_nSelValue2 = atoi( strValue.GetBuffer() );
	}
	if ( _T("stype3") == strKey )
	{
		int nValue = atoi( strValue.GetBuffer() );

		for ( int i = 0; i < m_ctrSelRwdType3.GetCount(); ++i )
		{
			if ( m_ctrSelRwdType3.GetItemData( i ) == nValue )
			{
				m_ctrSelRwdType3.SetCurSel( i );
				break;
			}
		}
	}
	else if ( _T("sidx3") == strKey )
	{
		m_dwSelIndex3 = atoi( strValue.GetBuffer() );
	}
	else if ( _T("sval3") == strKey )
	{
		m_nSelValue3 = atoi( strValue.GetBuffer() );
	}
}

void CTSAttr_CONT_Reward::DoDataExchange(CDataExchange* pDX)
{
	CTSAttr_Page::DoDataExchange(pDX);

	DDX_Text(pDX, IDC_TS_CONT_ATTR_REWARD_ID_EDITOR, m_tcID);
	DDV_MinMaxUInt(pDX, m_tcID, 0, NTL_TS_TC_ID_INVALID);
	DDX_Text(pDX, IDC_TS_CONT_ATTR_REWARD_DESC_EDITOR, m_uiDesc);
	DDV_MinMaxUInt(pDX, m_uiDesc, 0, 0xffffffff);

	DDX_Control(pDX, IDC_TS_CONT_ATTR_REWARD_DEF_1_TYPE_COMBO, m_ctrDefRwdType0);
	DDX_Text(pDX, IDC_TS_CONT_ATTR_REWARD_DEF_1_INDEX_EDITOR, m_dwDefIndex0);
	DDX_Text(pDX, IDC_TS_CONT_ATTR_REWARD_DEF_1_VARIABLE_EDITOR, m_nDefValue0);

	DDX_Control(pDX, IDC_TS_CONT_ATTR_REWARD_DEF_2_TYPE_COMBO, m_ctrDefRwdType1);
	DDX_Text(pDX, IDC_TS_CONT_ATTR_REWARD_DEF_2_INDEX_EDITOR, m_dwDefIndex1);
	DDX_Text(pDX, IDC_TS_CONT_ATTR_REWARD_DEF_2_VARIABLE_EDITOR, m_nDefValue1);

	DDX_Control(pDX, IDC_TS_CONT_ATTR_REWARD_DEF_3_TYPE_COMBO, m_ctrDefRwdType2);
	DDX_Text(pDX, IDC_TS_CONT_ATTR_REWARD_DEF_3_INDEX_EDITOR, m_dwDefIndex2);
	DDX_Text(pDX, IDC_TS_CONT_ATTR_REWARD_DEF_3_VARIABLE_EDITOR, m_nDefValue2);

	DDX_Control(pDX, IDC_TS_CONT_ATTR_REWARD_DEF_4_TYPE_COMBO, m_ctrDefRwdType3);
	DDX_Text(pDX, IDC_TS_CONT_ATTR_REWARD_DEF_4_INDEX_EDITOR, m_dwDefIndex3);
	DDX_Text(pDX, IDC_TS_CONT_ATTR_REWARD_DEF_4_VARIABLE_EDITOR, m_nDefValue3);

	DDX_Control(pDX, IDC_TS_CONT_ATTR_REWARD_SEL_1_TYPE_COMBO, m_ctrSelRwdType0);
	DDX_Text(pDX, IDC_TS_CONT_ATTR_REWARD_SEL_1_INDEX_EDITOR, m_dwSelIndex0);
	DDX_Text(pDX, IDC_TS_CONT_ATTR_REWARD_SEL_1_VARIABLE_EDITOR, m_nSelValue0);

	DDX_Control(pDX, IDC_TS_CONT_ATTR_REWARD_SEL_2_TYPE_COMBO, m_ctrSelRwdType1);
	DDX_Text(pDX, IDC_TS_CONT_ATTR_REWARD_SEL_2_INDEX_EDITOR, m_dwSelIndex1);
	DDX_Text(pDX, IDC_TS_CONT_ATTR_REWARD_SEL_2_VARIABLE_EDITOR, m_nSelValue1);

	DDX_Control(pDX, IDC_TS_CONT_ATTR_REWARD_SEL_3_TYPE_COMBO, m_ctrSelRwdType2);
	DDX_Text(pDX, IDC_TS_CONT_ATTR_REWARD_SEL_3_INDEX_EDITOR, m_dwSelIndex2);
	DDX_Text(pDX, IDC_TS_CONT_ATTR_REWARD_SEL_3_VARIABLE_EDITOR, m_nSelValue2);

	DDX_Control(pDX, IDC_TS_CONT_ATTR_REWARD_SEL_4_TYPE_COMBO, m_ctrSelRwdType3);
	DDX_Text(pDX, IDC_TS_CONT_ATTR_REWARD_SEL_4_INDEX_EDITOR, m_dwSelIndex3);
	DDX_Text(pDX, IDC_TS_CONT_ATTR_REWARD_SEL_4_VARIABLE_EDITOR, m_nSelValue3);
}

BOOL CTSAttr_CONT_Reward::OnInitDialog()
{
	CTSAttr_Page::OnInitDialog();

	int nIdx;

	// �⺻ ����
	m_ctrDefRwdType0.SetItemData( m_ctrDefRwdType0.AddString( _T("Normal item") ), eREWARD_TYPE_NORMAL_ITEM );
	m_ctrDefRwdType0.SetItemData( m_ctrDefRwdType0.AddString( _T("Quest item") ), eREWARD_TYPE_QUEST_ITEM );
	m_ctrDefRwdType0.SetItemData( m_ctrDefRwdType0.AddString( _T("Exp") ), eREWARD_TYPE_EXP );
	m_ctrDefRwdType0.SetItemData( m_ctrDefRwdType0.AddString( _T("Skill") ), eREWARD_TYPE_SKILL );
	m_ctrDefRwdType0.SetItemData( m_ctrDefRwdType0.AddString( _T("Zeny") ), eREWARD_TYPE_ZENY );
	m_ctrDefRwdType0.SetItemData( m_ctrDefRwdType0.AddString( _T("Change class") ), eREWARD_TYPE_CHANGE_CLASS );
	m_ctrDefRwdType0.SetItemData( m_ctrDefRwdType0.AddString( _T("Buff") ), eREWARD_TYPE_BUFF );
	m_ctrDefRwdType0.SetItemData( m_ctrDefRwdType0.AddString( _T("Probability") ), eREWARD_TYPE_PROBABILITY );
	nIdx = m_ctrDefRwdType0.AddString( _T(" Invalid") );
	m_ctrDefRwdType0.SetItemData( nIdx, eREWARD_TYPE_INVALID );
	m_ctrDefRwdType0.SetCurSel( nIdx );

	m_ctrDefRwdType1.SetItemData( m_ctrDefRwdType1.AddString( _T("Normal item") ), eREWARD_TYPE_NORMAL_ITEM );
	m_ctrDefRwdType1.SetItemData( m_ctrDefRwdType1.AddString( _T("Quest item") ), eREWARD_TYPE_QUEST_ITEM );
	m_ctrDefRwdType1.SetItemData( m_ctrDefRwdType1.AddString( _T("Exp") ), eREWARD_TYPE_EXP );
	m_ctrDefRwdType1.SetItemData( m_ctrDefRwdType1.AddString( _T("Skill") ), eREWARD_TYPE_SKILL );
	m_ctrDefRwdType1.SetItemData( m_ctrDefRwdType1.AddString( _T("Zeny") ), eREWARD_TYPE_ZENY );
	m_ctrDefRwdType1.SetItemData( m_ctrDefRwdType1.AddString( _T("Change class") ), eREWARD_TYPE_CHANGE_CLASS );
	m_ctrDefRwdType1.SetItemData( m_ctrDefRwdType1.AddString( _T("Buff") ), eREWARD_TYPE_BUFF );
	m_ctrDefRwdType1.SetItemData( m_ctrDefRwdType1.AddString( _T("Probability") ), eREWARD_TYPE_PROBABILITY );
	nIdx = m_ctrDefRwdType1.AddString( _T(" Invalid") );
	m_ctrDefRwdType1.SetItemData( nIdx, eREWARD_TYPE_INVALID );
	m_ctrDefRwdType1.SetCurSel( nIdx );

	m_ctrDefRwdType2.SetItemData( m_ctrDefRwdType2.AddString( _T("Normal item") ), eREWARD_TYPE_NORMAL_ITEM );
	m_ctrDefRwdType2.SetItemData( m_ctrDefRwdType2.AddString( _T("Quest item") ), eREWARD_TYPE_QUEST_ITEM );
	m_ctrDefRwdType2.SetItemData( m_ctrDefRwdType2.AddString( _T("Exp") ), eREWARD_TYPE_EXP );
	m_ctrDefRwdType2.SetItemData( m_ctrDefRwdType2.AddString( _T("Skill") ), eREWARD_TYPE_SKILL );
	m_ctrDefRwdType2.SetItemData( m_ctrDefRwdType2.AddString( _T("Zeny") ), eREWARD_TYPE_ZENY );
	m_ctrDefRwdType2.SetItemData( m_ctrDefRwdType2.AddString( _T("Change class") ), eREWARD_TYPE_CHANGE_CLASS );
	m_ctrDefRwdType2.SetItemData( m_ctrDefRwdType2.AddString( _T("Buff") ), eREWARD_TYPE_BUFF );
	m_ctrDefRwdType2.SetItemData( m_ctrDefRwdType2.AddString( _T("Probability") ), eREWARD_TYPE_PROBABILITY );
	nIdx = m_ctrDefRwdType2.AddString( _T(" Invalid") );
	m_ctrDefRwdType2.SetItemData( nIdx, eREWARD_TYPE_INVALID );
	m_ctrDefRwdType2.SetCurSel( nIdx );

	m_ctrDefRwdType3.SetItemData( m_ctrDefRwdType3.AddString( _T("Normal item") ), eREWARD_TYPE_NORMAL_ITEM );
	m_ctrDefRwdType3.SetItemData( m_ctrDefRwdType3.AddString( _T("Quest item") ), eREWARD_TYPE_QUEST_ITEM );
	m_ctrDefRwdType3.SetItemData( m_ctrDefRwdType3.AddString( _T("Exp") ), eREWARD_TYPE_EXP );
	m_ctrDefRwdType3.SetItemData( m_ctrDefRwdType3.AddString( _T("Skill") ), eREWARD_TYPE_SKILL );
	m_ctrDefRwdType3.SetItemData( m_ctrDefRwdType3.AddString( _T("Zeny") ), eREWARD_TYPE_ZENY );
	m_ctrDefRwdType3.SetItemData( m_ctrDefRwdType3.AddString( _T("Change class") ), eREWARD_TYPE_CHANGE_CLASS );
	m_ctrDefRwdType3.SetItemData( m_ctrDefRwdType3.AddString( _T("Buff") ), eREWARD_TYPE_BUFF );
	m_ctrDefRwdType3.SetItemData( m_ctrDefRwdType3.AddString( _T("Probability") ), eREWARD_TYPE_PROBABILITY );
	nIdx = m_ctrDefRwdType3.AddString( _T(" Invalid") );
	m_ctrDefRwdType3.SetItemData( nIdx, eREWARD_TYPE_INVALID );
	m_ctrDefRwdType3.SetCurSel( nIdx );

	// ���� ����
	m_ctrSelRwdType0.SetItemData( m_ctrSelRwdType0.AddString( _T("Normal item") ), eREWARD_TYPE_NORMAL_ITEM );
	m_ctrSelRwdType0.SetItemData( m_ctrSelRwdType0.AddString( _T("Quest item") ), eREWARD_TYPE_QUEST_ITEM );
	m_ctrSelRwdType0.SetItemData( m_ctrSelRwdType0.AddString( _T("Exp") ), eREWARD_TYPE_EXP );
	m_ctrSelRwdType0.SetItemData( m_ctrSelRwdType0.AddString( _T("Skill") ), eREWARD_TYPE_SKILL );
	m_ctrSelRwdType0.SetItemData( m_ctrSelRwdType0.AddString( _T("Zeny") ), eREWARD_TYPE_ZENY );
	m_ctrSelRwdType0.SetItemData( m_ctrSelRwdType0.AddString( _T("Change class") ), eREWARD_TYPE_CHANGE_CLASS );
	m_ctrSelRwdType0.SetItemData( m_ctrSelRwdType0.AddString( _T("Buff") ), eREWARD_TYPE_BUFF );
	m_ctrSelRwdType0.SetItemData( m_ctrSelRwdType0.AddString( _T("Probability") ), eREWARD_TYPE_PROBABILITY );
	nIdx = m_ctrSelRwdType0.AddString( _T(" Invalid") );
	m_ctrSelRwdType0.SetItemData( nIdx, eREWARD_TYPE_INVALID );
	m_ctrSelRwdType0.SetCurSel( nIdx );

	m_ctrSelRwdType1.SetItemData( m_ctrSelRwdType1.AddString( _T("Normal item") ), eREWARD_TYPE_NORMAL_ITEM );
	m_ctrSelRwdType1.SetItemData( m_ctrSelRwdType1.AddString( _T("Quest item") ), eREWARD_TYPE_QUEST_ITEM );
	m_ctrSelRwdType1.SetItemData( m_ctrSelRwdType1.AddString( _T("Exp") ), eREWARD_TYPE_EXP );
	m_ctrSelRwdType1.SetItemData( m_ctrSelRwdType1.AddString( _T("Skill") ), eREWARD_TYPE_SKILL );
	m_ctrSelRwdType1.SetItemData( m_ctrSelRwdType1.AddString( _T("Zeny") ), eREWARD_TYPE_ZENY );
	m_ctrSelRwdType1.SetItemData( m_ctrSelRwdType1.AddString( _T("Change class") ), eREWARD_TYPE_CHANGE_CLASS );
	m_ctrSelRwdType1.SetItemData( m_ctrSelRwdType1.AddString( _T("Buff") ), eREWARD_TYPE_BUFF );
	m_ctrSelRwdType1.SetItemData( m_ctrSelRwdType1.AddString( _T("Probability") ), eREWARD_TYPE_PROBABILITY );
	nIdx = m_ctrSelRwdType1.AddString( _T(" Invalid") );
	m_ctrSelRwdType1.SetItemData( nIdx, eREWARD_TYPE_INVALID );
	m_ctrSelRwdType1.SetCurSel( nIdx );

	m_ctrSelRwdType2.SetItemData( m_ctrSelRwdType2.AddString( _T("Normal item") ), eREWARD_TYPE_NORMAL_ITEM );
	m_ctrSelRwdType2.SetItemData( m_ctrSelRwdType2.AddString( _T("Quest item") ), eREWARD_TYPE_QUEST_ITEM );
	m_ctrSelRwdType2.SetItemData( m_ctrSelRwdType2.AddString( _T("Exp") ), eREWARD_TYPE_EXP );
	m_ctrSelRwdType2.SetItemData( m_ctrSelRwdType2.AddString( _T("Skill") ), eREWARD_TYPE_SKILL );
	m_ctrSelRwdType2.SetItemData( m_ctrSelRwdType2.AddString( _T("Zeny") ), eREWARD_TYPE_ZENY );
	m_ctrSelRwdType2.SetItemData( m_ctrSelRwdType2.AddString( _T("Change class") ), eREWARD_TYPE_CHANGE_CLASS );
	m_ctrSelRwdType2.SetItemData( m_ctrSelRwdType2.AddString( _T("Buff") ), eREWARD_TYPE_BUFF );
	m_ctrSelRwdType2.SetItemData( m_ctrSelRwdType2.AddString( _T("Probability") ), eREWARD_TYPE_PROBABILITY );
	nIdx = m_ctrSelRwdType2.AddString( _T(" Invalid") );
	m_ctrSelRwdType2.SetItemData( nIdx, eREWARD_TYPE_INVALID );
	m_ctrSelRwdType2.SetCurSel( nIdx );

	m_ctrSelRwdType3.SetItemData( m_ctrSelRwdType3.AddString( _T("Normal item") ), eREWARD_TYPE_NORMAL_ITEM );
	m_ctrSelRwdType3.SetItemData( m_ctrSelRwdType3.AddString( _T("Quest item") ), eREWARD_TYPE_QUEST_ITEM );
	m_ctrSelRwdType3.SetItemData( m_ctrSelRwdType3.AddString( _T("Exp") ), eREWARD_TYPE_EXP );
	m_ctrSelRwdType3.SetItemData( m_ctrSelRwdType3.AddString( _T("Skill") ), eREWARD_TYPE_SKILL );
	m_ctrSelRwdType3.SetItemData( m_ctrSelRwdType3.AddString( _T("Zeny") ), eREWARD_TYPE_ZENY );
	m_ctrSelRwdType3.SetItemData( m_ctrSelRwdType3.AddString( _T("Change class") ), eREWARD_TYPE_CHANGE_CLASS );
	m_ctrSelRwdType3.SetItemData( m_ctrSelRwdType3.AddString( _T("Buff") ), eREWARD_TYPE_BUFF );
	m_ctrSelRwdType3.SetItemData( m_ctrSelRwdType3.AddString( _T("Probability") ), eREWARD_TYPE_PROBABILITY );
	nIdx = m_ctrSelRwdType3.AddString( _T(" Invalid") );
	m_ctrSelRwdType3.SetItemData( nIdx, eREWARD_TYPE_INVALID );
	m_ctrSelRwdType3.SetCurSel( nIdx );

	if ( m_strAllAttrData.GetLength() > 0 )
	{
		CTSAttr_Page::SettingAttrDataToDlgItems( m_strAllAttrData );
	}

	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}


BEGIN_MESSAGE_MAP(CTSAttr_CONT_Reward, CTSAttr_Page)
END_MESSAGE_MAP()


// CTSAttr_CONT_Reward �޽��� ó�����Դϴ�.
