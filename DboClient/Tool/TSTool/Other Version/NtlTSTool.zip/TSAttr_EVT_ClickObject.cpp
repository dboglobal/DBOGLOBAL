// TSAttr_EVT_ClickObject.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "NtlTSTool.h"
#include "TSAttr_EVT_ClickObject.h"


// CTSAttr_EVT_ClickObject ��ȭ �����Դϴ�.

IMPLEMENT_SERIAL(CTSAttr_EVT_ClickObject, CTSAttr_Page, 1)

CTSAttr_EVT_ClickObject::CTSAttr_EVT_ClickObject(CWnd* pParent /*=NULL*/)
	: CTSAttr_Page(CTSAttr_EVT_ClickObject::IDD)
	, m_dwWorldIdx(0xffffffff)
{

}

CTSAttr_EVT_ClickObject::~CTSAttr_EVT_ClickObject()
{
}

CString CTSAttr_EVT_ClickObject::CollectAttrDataFromDlgItems( void )
{
	CTSAttr_Page::CollectAttrDataFromDlgItems();

	CString strData;

	strData += MakeAttrData( _T("widx"), m_dwWorldIdx );
	strData += MakeAttrData( _T("objidx"), m_strObjectIdx );

	return strData;
}

void CTSAttr_EVT_ClickObject::SettingAttrDataToDlgItems( CString& strKey, CString& strValue )
{
	if ( _T("widx") == strKey )
	{
		m_dwWorldIdx = atoi( strValue.GetBuffer() );
	}

	if ( _T("objidx") == strKey )
	{
		m_strObjectIdx = strValue;
	}
}

void CTSAttr_EVT_ClickObject::DoDataExchange(CDataExchange* pDX)
{
	CTSAttr_Page::DoDataExchange(pDX);

	DDX_Text(pDX, IDC_TS_EVT_ATTR_CLICK_OBJIDX_EDITOR, m_strObjectIdx);
	DDX_Text(pDX, IDC_TS_EVT_ATTR_CLICK_WORLDIDX_EDITOR, m_dwWorldIdx);
}


BEGIN_MESSAGE_MAP(CTSAttr_EVT_ClickObject, CTSAttr_Page)
END_MESSAGE_MAP()


// CTSAttr_EVT_ClickObject �޽��� ó�����Դϴ�.
