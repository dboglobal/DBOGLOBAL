// TSAttr_COND_InNPC.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "NtlTSTool.h"
#include "TSAttr_COND_InNPC.h"


// CTSAttr_COND_InNPC ��ȭ �����Դϴ�.

IMPLEMENT_SERIAL(CTSAttr_COND_InNPC, CTSAttr_Page, 1)

CTSAttr_COND_InNPC::CTSAttr_COND_InNPC()
	: CTSAttr_Page(CTSAttr_COND_InNPC::IDD)
	, m_dwIndex( 0xffffffff )
	, m_nRadius( 15 )
{

}

CTSAttr_COND_InNPC::~CTSAttr_COND_InNPC()
{
}

CString CTSAttr_COND_InNPC::CollectAttrDataFromDlgItems( void )
{
	CTSAttr_Page::CollectAttrDataFromDlgItems();

	CString strData;

	strData += MakeAttrData( _T("idx"), m_dwIndex );
	strData += MakeAttrData( _T("rad"), m_nRadius );

	return strData;
}

void CTSAttr_COND_InNPC::SettingAttrDataToDlgItems( CString& strKey, CString& strValue )
{
	if ( _T("idx") == strKey )
	{
		m_dwIndex = atoi( strValue.GetBuffer() );
	}
	else if ( _T("rad") == strKey )
	{
		m_nRadius = atoi( strValue.GetBuffer() );
	}
}

void CTSAttr_COND_InNPC::DoDataExchange(CDataExchange* pDX)
{
	CTSAttr_Page::DoDataExchange(pDX);

	DDX_Text(pDX, IDC_TS_COND_ATTR_INNPC_ITEMIDX_EDITOR, m_dwIndex);
	DDX_Text(pDX, IDC_TS_COND_ATTR_INNPC_RADIUS_EDITOR, m_nRadius);
}


BEGIN_MESSAGE_MAP(CTSAttr_COND_InNPC, CTSAttr_Page)
END_MESSAGE_MAP()


// CTSAttr_COND_InNPC �޽��� ó�����Դϴ�.
