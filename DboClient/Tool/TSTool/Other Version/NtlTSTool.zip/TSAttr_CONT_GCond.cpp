// TSAttr_CONT_GCond.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "NtlTSTool.h"
#include "TSAttr_CONT_GCond.h"


// CTSAttr_CONT_GCond ��ȭ �����Դϴ�.

IMPLEMENT_SERIAL(CTSAttr_CONT_GCond, CTSAttr_Page, 1)

CTSAttr_CONT_GCond::CTSAttr_CONT_GCond()
	: CTSAttr_Page(CTSAttr_CONT_GCond::IDD)
	, m_tcID(NTL_TS_TC_ID_INVALID)
{

}

CTSAttr_CONT_GCond::~CTSAttr_CONT_GCond()
{
}

CString CTSAttr_CONT_GCond::CollectAttrDataFromDlgItems( void )
{
	CTSAttr_Page::CollectAttrDataFromDlgItems();

	CString strData;

	strData += MakeAttrData( _T("cid"), m_tcID );

	return strData;
}

void CTSAttr_CONT_GCond::SettingAttrDataToDlgItems( CString& strKey, CString& strValue )
{
	if ( _T("cid") == strKey )
	{
		m_tcID = atoi( strValue.GetBuffer() );
	}
}

void CTSAttr_CONT_GCond::DoDataExchange(CDataExchange* pDX)
{
	CTSAttr_Page::DoDataExchange(pDX);

	DDX_Text(pDX, IDC_TS_CONT_ATTR_GCOND_ID_EDITOR, m_tcID);
	DDV_MinMaxUInt(pDX, m_tcID, 0, NTL_TS_TC_ID_INVALID);
}


BEGIN_MESSAGE_MAP(CTSAttr_CONT_GCond, CTSAttr_Page)
END_MESSAGE_MAP()


// CTSAttr_CONT_GCond �޽��� ó�����Դϴ�.
