#pragma once


#include "TSShapeBox.h"


class CShape_Start : public CTSShapeBox
{

	DECLARE_SERIAL( CShape_Start )


// Member variables
protected:


// Constructions and Destructions
protected:
	CShape_Start( void );

public:
	CShape_Start( const CPoint& ptPos, CTSGroup* pParent );
	virtual ~CShape_Start( void );


// Methods
public:

	// Serialize

	virtual void						Serialize( CArchive &ar );


// Implementations
protected:

	virtual	void						ShowContainerEntityAttributeAddDlg( int nGroupID );

	void								Save( CArchive& ar );

	bool								Load_Trig_Ver_00000000( CArchive& ar );
	bool								Load_Trig_Ver_00000001( CArchive& ar );

};